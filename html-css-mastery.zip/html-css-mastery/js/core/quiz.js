/* =========================================================
   HTML & CSS MASTERY — quiz.js
   Renders and runs quizzes with scoring, explanation and
   result screen. Saves best scores to localStorage.
   ========================================================= */

const QuizApp = (function () {

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function renderQuestion(q) {
    let html = '<div class="quiz-q" style="white-space:pre-wrap">' + (q.q || '') + '</div>';
    if (q.code) {
      html += '<div class="codeblock" style="margin-bottom:16px"><button class="copy-code" data-copy="next" data-label="Code">Copy</button><pre><code>' + esc(q.code) + '</code></pre></div>';
    }

    if (q.type === 'blank') {
      html += '<div class="quiz-options"><div style="margin:8px 0"><input type="text" class="quiz-blank" placeholder="Type your answer" style="width:100%;padding:12px 14px;border:2px solid var(--border);border-radius:10px;font-size:1rem;background:var(--surface);color:var(--text)"></div></div>';
      return html;
    }

    let opts = q.options;
    if (q.type === 'tf') opts = ['True', 'False'];

    html += '<div class="quiz-options">';
    opts.forEach((o, i) => {
      html += '<button class="quiz-opt" data-value="' + i + '"><span class="letter">' + 'ABCD'.charAt(i) + '</span><span>' + esc(o) + '</span></button>';
    });
    html += '</div>';
    return html;
  }

  function isAnswerCorrect(q, value) {
    if (q.type === 'tf') {
      return (q.answer === true && value === 0) || (q.answer === false && value === 1);
    }
    if (q.type === 'blank') {
      const given = String(value).trim().toLowerCase();
      const answers = (Array.isArray(q.answer) ? q.answer : [q.answer]).map(a => String(a).trim().toLowerCase());
      return answers.includes(given);
    }
    return q.answer === value;
  }

  function correctValueDisplay(q) {
    if (q.type === 'tf') return q.answer === true ? 'True' : 'False';
    if (q.type === 'blank') return (Array.isArray(q.answer) ? q.answer[0] : q.answer);
    return 'ABCD'.charAt(q.answer);
  }

  function start(quiz, container) {
    let index = 0;
    let score = 0;
    const results = [];

    container.innerHTML = '';

    const header = document.createElement('div');
    header.className = 'quiz-header';
    header.innerHTML = '<div><strong>' + esc(quiz.title) + '</strong><br><span class="text-muted text-small" id="quizCounter">Question 1 of ' + quiz.questions.length + '</span></div>' +
      '<div class="chip" id="quizScoreChip">Score: 0</div>';
    const progressTrack = document.createElement('div');
    progressTrack.className = 'quiz-progress-track';
    progressTrack.innerHTML = '<div class="quiz-progress-fill" id="quizProgress"></div>';
    const qWrap = document.createElement('div');
    const actionRow = document.createElement('div');

    container.appendChild(header);
    container.appendChild(progressTrack);
    container.appendChild(qWrap);
    container.appendChild(actionRow);

    function updateHeader() {
      header.querySelector('#quizCounter').textContent = 'Question ' + (index + 1) + ' of ' + quiz.questions.length;
      header.querySelector('#quizScoreChip').textContent = 'Score: ' + score;
      progressTrack.querySelector('#quizProgress').style.width = ((index / quiz.questions.length) * 100) + '%';
    }

    function render() {
      updateHeader();
      const q = quiz.questions[index];
      qWrap.innerHTML = renderQuestion(q);

      if (q.type === 'blank') {
        const input = qWrap.querySelector('.quiz-blank');
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(input.value); });
        actionRow.innerHTML = '<button class="btn btn-primary" id="quizSubmitBlank">Check Answer</button>';
        actionRow.querySelector('#quizSubmitBlank').addEventListener('click', () => submit(input.value));
      } else {
        qWrap.querySelectorAll('.quiz-opt').forEach(btn => {
          btn.addEventListener('click', () => {
            const val = parseInt(btn.getAttribute('data-value'), 10);
            submit(val);
          });
        });
        actionRow.innerHTML = '';
      }
    }

    function submit(value) {
      const q = quiz.questions[index];
      const correct = isAnswerCorrect(q, value);
      if (correct) score++;
      results.push({ q, given: value, correct });

      qWrap.querySelectorAll('.quiz-opt').forEach(btn => btn.disabled = true);
      const explanation = document.createElement('div');
      explanation.className = 'quiz-explanation show ' + (correct ? 'good' : 'bad');
      explanation.innerHTML = (correct ? '✅ <strong>Correct!</strong> ' : '❌ <strong>Not quite.</strong> ') +
        (correct ? '' : 'The correct answer is <b>' + esc(correctValueDisplay(q)) + '</b>. ') +
        '<br><span style="font-weight:400">' + esc(q.explanation) + '</span>';
      qWrap.appendChild(explanation);

      if (q.type !== 'blank') {
        qWrap.querySelectorAll('.quiz-opt').forEach(btn => {
          const val = parseInt(btn.getAttribute('data-value'), 10);
          if (val === q.answer) btn.classList.add('correct');
          else if (val === value) btn.classList.add('wrong');
        });
      }

      actionRow.innerHTML = '<button class="btn btn-primary" id="quizNext">Next Question →</button>';
      actionRow.querySelector('#quizNext').addEventListener('click', () => {
        index++;
        if (index < quiz.questions.length) {
          render();
        } else {
          showResult();
        }
      });
    }

    function showResult() {
      const total = quiz.questions.length;
      const pct = Math.round((score / total) * 100);
      Store.saveQuizScore(quiz.id, score, total);

      const r = 2 * Math.PI * 60;
      const offset = r - (pct / 100) * r;
      qWrap.innerHTML = '';
      actionRow.innerHTML = '';
      container.querySelector('.quiz-progress-fill').style.width = '100%';

      let resultHtml = '<div class="quiz-result">';
      resultHtml += '<h2>Quiz Complete</h2>';
      resultHtml += '<svg class="result-circle" viewBox="0 0 140 140">' +
        '<circle cx="70" cy="70" r="60" fill="none" stroke="var(--surface-2)" stroke-width="14"></circle>' +
        '<circle cx="70" cy="70" r="60" fill="none" stroke="var(--primary)" stroke-width="14" stroke-linecap="round" stroke-dasharray="' + r + '" stroke-dashoffset="' + offset + '" transform="rotate(-90 70 70)"></circle>' +
        '<text x="70" y="78" text-anchor="middle" font-size="26" font-weight="800" fill="var(--text)">' + pct + '%</text></svg>';
      resultHtml += '<div class="score">' + score + ' / ' + total + '</div>';
      resultHtml += '<div class="pct">Percentage: ' + pct + '%</div>';
      const msg = pct >= 90 ? 'Outstanding! 🎉' : pct >= 70 ? 'Great work! 🎉' : pct >= 50 ? 'Good effort — keep practicing!' : 'Keep learning — review the lesson and try again!';
      resultHtml += '<p class="mt-2">' + msg + '</p>';
      resultHtml += '</div>';
      qWrap.innerHTML = resultHtml;

      actionRow.className = 'quiz-actions';
      actionRow.innerHTML = '<button class="btn btn-outline" id="quizRetry">↻ Retry Quiz</button>' +
        '<button class="btn btn-outline" id="quizReview">Review Answers</button>' +
        '<a class="btn btn-primary" href="quizzes.html">Continue Learning</a>';
      actionRow.querySelector('#quizRetry').addEventListener('click', () => start(quiz, container));
      actionRow.querySelector('#quizReview').addEventListener('click', () => {
        qWrap.innerHTML = '<h2>Review Answers</h2>';
        results.forEach((res, i) => {
          const ok = res.correct;
          qWrap.innerHTML += '<div class="callout ' + (ok ? 'callout-good' : 'callout-warn') + '" style="margin:10px 0">' +
            '<strong>' + (i + 1) + '. ' + esc(res.q.q) + (ok ? ' — ✅ Correct' : ' — ❌ Wrong') + '</strong>' +
            (res.q.code ? '<pre style="margin-top:6px"><code>' + esc(res.q.code) + '</code></pre>' : '') +
            '<p style="margin-top:6px">Correct answer: <b>' + esc(correctValueDisplay(res.q)) + '</b></p>' +
            '<p style="margin:4px 0 0">' + esc(res.q.explanation) + '</p></div>';
        });
        actionRow.innerHTML = '<button class="btn btn-primary" id="quizBack">Back to Result</button>';
        actionRow.querySelector('#quizBack').addEventListener('click', showResult);
      });
    }

    render();
  }

  return { start };
})();
