/* =========================================================
   HTML & CSS MASTERY — achievements.js
   Unlock simple achievements as the learner progresses.
   ========================================================= */

const ACHIEVEMENT_DEFS = [
  { id: 'first_lesson', emoji: '🏆', title: 'First Lesson Completed', desc: 'Complete your very first lesson.', cat: 'lessons' },
  { id: 'html_beginner', emoji: '🏆', title: 'HTML Beginner', desc: 'Complete all Module 1 lessons.', cat: 'lessons' },
  { id: 'css_beginner', emoji: '🏆', title: 'CSS Beginner', desc: 'Complete all Module 5 lessons.', cat: 'lessons' },
  { id: 'ten_lessons', emoji: '🏆', title: '10 Lessons Completed', desc: 'Complete 10 lessons in total.', cat: 'lessons' },
  { id: 'twenty_lessons', emoji: '🏆', title: '20 Lessons Completed', desc: 'Complete 20 lessons in total.', cat: 'lessons' },
  { id: 'course_completed', emoji: '🏆', title: 'Course Completed', desc: 'Complete every lesson in the course.', cat: 'lessons' },
  { id: 'first_quiz', emoji: '🏆', title: 'First Quiz Passed', desc: 'Score at least 70% on any quiz.', cat: 'quiz' },
  { id: 'quiz_streak', emoji: '🏆', title: 'Quiz Whiz', desc: 'Score 90% or higher on any quiz.', cat: 'quiz' },
  { id: 'first_project', emoji: '🏆', title: 'First Project Completed', desc: 'Complete your first project.', cat: 'project' },
  { id: 'flexbox_master', emoji: '🏆', title: 'Flexbox Master', desc: 'Complete the Flexbox module lessons.', cat: 'lessons' },
  { id: 'grid_master', emoji: '🏆', title: 'Grid Master', desc: 'Complete the CSS Grid module lessons.', cat: 'lessons' },
  { id: 'responsive_beginner', emoji: '🏆', title: 'Responsive Design Beginner', desc: 'Complete the Responsive Design module lessons.', cat: 'lessons' },
  { id: 'three_day_streak', emoji: '🏆', title: '3-Day Streak', desc: 'Learn on 3 different days in a row.', cat: 'activity' },
];

const Achievements = (function () {
  function check() {
    const state = Store.load();
    const lessons = Curriculum.getAllLessons();
    const completed = state.completedLessons;

    const moduleLessons = (moduleName) => lessons.filter(l => l.module === moduleName);

    const hasAll = (lessonList) => lessonList.every(l => completed.includes(l.id));

    const conditions = {
      first_lesson: () => completed.length >= 1,
      html_beginner: () => hasAll(moduleLessons('Module 1 — Introduction')),
      css_beginner: () => hasAll(moduleLessons('Module 5 — CSS Fundamentals')),
      ten_lessons: () => completed.length >= 10,
      twenty_lessons: () => completed.length >= 20,
      course_completed: () => lessons.length > 0 && completed.length >= lessons.length,
      first_quiz: () => Object.values(state.quizScores).some(s => s.pct >= 70),
      quiz_streak: () => Object.values(state.quizScores).some(s => s.pct >= 90),
      first_project: () => state.projectsCompleted.length >= 1,
      flexbox_master: () => hasAll(moduleLessons('Module 7 — Layout').filter(l => l.flexbox)),
      grid_master: () => hasAll(moduleLessons('Module 7 — Layout').filter(l => l.grid)),
      responsive_beginner: () => hasAll(moduleLessons('Module 8 — Responsive Design')),
      three_day_streak: () => streak() >= 3,
    };

    const newlyUnlocked = [];
    ACHIEVEMENT_DEFS.forEach(def => {
      if (!state.achievements[def.id]) {
        const cond = conditions[def.id];
        if (cond && cond()) {
          state.achievements[def.id] = new Date().toISOString();
          newlyUnlocked.push(def);
        }
      }
    });

    if (newlyUnlocked.length) {
      Store.save();
      UI.toast('🏆 Achievement unlocked!', 'success');
      const def = newlyUnlocked[0];
      UI.openModal({
        title: 'Achievement Unlocked!',
        body: '<div class="text-center" style="font-size:3rem">' + def.emoji + '</div><h3 class="text-center">' + def.title + '</h3><p class="text-center text-muted">' + def.desc + '</p>',
        actions: [{ label: 'Awesome!', cls: 'btn-primary', action: 'close' }]
      });
    }
  }

  // Current streak: 1 if the learner has been active today, 0 otherwise.
  // (A simple, reliable measure — avoids fragile date math across timezones.)
  function streak() {
    const state = Store.load();
    const last = state.lastActivityDate;
    if (!last) return 0;
    const today = new Date().toISOString().slice(0, 10);
    return last === today ? 1 : 0;
  }

  function getUnlocked() {
    return ACHIEVEMENT_DEFS.map(def => ({
      def,
      date: Store.load().achievements[def.id] || null
    }));
  }

  return { check, getUnlocked, streak, defs: ACHIEVEMENT_DEFS };
})();
