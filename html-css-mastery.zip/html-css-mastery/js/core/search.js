/* =========================================================
   HTML & CSS MASTERY — search.js
   Global instant search across lessons, exercises, projects,
   quizzes, glossary and cheat sheets.
   ========================================================= */

const Search = (function () {

  function findAll(query) {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    const results = [];
    results.push(...Curriculum.search(q));
    results.push(...Exercises.search(q));
    results.push(...Projects.search(q));
    results.push(...Quizzes.getAll()
      .filter(z => (z.title + ' ' + z.category).toLowerCase().includes(q))
      .map(z => ({ type: 'Quiz', title: z.title, snippet: z.category, url: 'quizzes.html#' + z.id })));
    results.push(...Glossary.searchForGlobal(q));
    results.push(...Cheatsheets.search(q));
    return results;
  }

  function open() {
    let overlay = document.getElementById('searchOverlay');
    let panel = document.getElementById('searchPanel');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'searchOverlay';
      overlay.className = 'search-overlay';
      overlay.addEventListener('click', close);
      document.body.appendChild(overlay);
    }
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'searchPanel';
      panel.className = 'search-panel';
      panel.innerHTML = '<input type="text" id="globalSearchInput" placeholder="Search lessons, tags, properties, concepts..." aria-label="Search">' +
        '<div class="search-results" id="globalSearchResults"></div>';
      panel.querySelector('#globalSearchInput').addEventListener('input', (e) => render(e.target.value));
      document.body.appendChild(panel);
    }
    overlay.classList.add('open');
    panel.classList.add('open');
    const input = document.getElementById('globalSearchInput');
    input.value = '';
    input.focus();
    document.getElementById('globalSearchResults').innerHTML = '<div class="search-empty">Type to search the whole course.</div>';
  }

  function close() {
    const ov = document.getElementById('searchOverlay');
    const panel = document.getElementById('searchPanel');
    if (ov) ov.classList.remove('open');
    if (panel) panel.classList.remove('open');
  }

  function render(query) {
    const container = document.getElementById('globalSearchResults');
    const q = query.trim();
    if (!q) { container.innerHTML = '<div class="search-empty">Type to search the whole course.</div>'; return; }
    const results = findAll(q);
    if (!results.length) {
      container.innerHTML = '<div class="search-empty">No results for "<strong>' + q.replace(/</g, '&lt;') + '</strong>". Try "margin", "flexbox", "form".</div>';
      return;
    }
    container.innerHTML = results.slice(0, 20).map(r =>
      '<a class="search-result" href="' + r.url + '">' +
      '<div class="sr-type">' + r.type + '</div>' +
      '<div class="sr-title">' + String(r.title).replace(/<[^>]+>/g, '') + '</div>' +
      (r.snippet ? '<div class="sr-snippet">' + String(r.snippet).replace(/<[^>]+>/g, '').slice(0, 90) + '</div>' : '') +
      '</a>').join('');

    container.querySelectorAll('a.search-result').forEach(a => {
      a.addEventListener('click', close);
    });
  }

  return { findAll, open, close };
})();
