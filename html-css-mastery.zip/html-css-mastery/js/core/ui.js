/* =========================================================
   HTML & CSS MASTERY — ui.js
   Reusable UI helpers: toasts, modals, tabs, copy, accordion.
   ========================================================= */

const UI = (function () {
  // ---------- Toast notifications ----------
  function toast(message, type) {
    let box = document.getElementById('toast');
    if (!box) {
      box = document.createElement('div');
      box.id = 'toast';
      document.body.appendChild(box);
    }
    const icons = { success: '✅', error: '⚠️', info: 'ℹ️' };
    const el = document.createElement('div');
    el.className = 'toast ' + (type || 'info');
    el.innerHTML = '<span class="t-icon">' + (icons[type] || icons.info) + '</span><span>' + message + '</span>';
    box.appendChild(el);
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 300);
    }, 2600);
  }

  // ---------- Modal ----------
  function openModal({ title, body, actions }) {
    const backdrop = document.getElementById('modalRoot') || (() => {
      const d = document.createElement('div');
      d.id = 'modalRoot';
      d.className = 'modal-backdrop';
      document.body.appendChild(d);
      return d;
    })();

    let html = '<div class="modal" role="dialog" aria-modal="true">';
    if (title) html += '<h3>' + title + '</h3>';
    html += '<div class="modal-body">' + (body || '') + '</div>';
    html += '<div class="modal-actions">';
    if (actions) {
      actions.forEach(a => {
        html += '<button class="btn ' + (a.cls || 'btn-outline') + '" data-action="' + (a.action || '') + '">' + a.label + '</button>';
      });
    } else {
      html += '<button class="btn btn-outline" data-action="close">Close</button>';
    }
    html += '</div></div>';
    backdrop.innerHTML = html;
    backdrop.classList.add('open');

    backdrop.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.getAttribute('data-action');
        closeModal();
        if (action && action !== 'close') {
          const handler = (actions || []).find(a => a.action === action);
          if (handler && handler.onClick) handler.onClick();
        }
      });
    });
    return backdrop;
  }

  function closeModal() {
    const backdrop = document.getElementById('modalRoot');
    if (backdrop) backdrop.classList.remove('open');
  }

  // ---------- Copy text to clipboard ----------
  function copyText(text, label) {
    const done = () => toast((label || 'Code') + ' copied to clipboard', 'success');
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
    } else {
      fallbackCopy(text, done);
    }
  }

  function fallbackCopy(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); }
    catch (e) { toast('Copy failed — please copy manually', 'error'); }
    document.body.removeChild(ta);
  }

  // Wire up all [data-copy] buttons
  function initCopyButtons(root) {
    (root || document).querySelectorAll('[data-copy]').forEach(btn => {
      if (btn.dataset.bound) return;
      btn.dataset.bound = '1';
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-copy');
        let text = '';
        if (target === 'next') {
          const code = btn.closest('.codeblock, pre');
          text = code ? code.querySelector('code') ? code.querySelector('code').innerText : code.innerText : '';
        } else if (target.startsWith('#')) {
          const el = document.querySelector(target);
          text = el ? el.innerText || el.value : '';
        } else {
          text = btn.getAttribute('data-copy-text') || target;
        }
        copyText(text, btn.getAttribute('data-label') || 'Content');
      });
    });
  }

  // ---------- Tabs ----------
  function initTabs(root) {
    (root || document).querySelectorAll('.tabs').forEach(tabs => {
      tabs.querySelectorAll('button[data-tab]').forEach(btn => {
        if (btn.dataset.bound) return;
        btn.dataset.bound = '1';
        btn.addEventListener('click', () => {
          const target = btn.getAttribute('data-tab');
          tabs.querySelectorAll('button[data-tab]').forEach(b => b.classList.toggle('active', b === btn));
          const container = tabs.parentElement;
          container.querySelectorAll('[data-panel]').forEach(p => p.classList.toggle('active', p.getAttribute('data-panel') === target));
        });
      });
    });
  }

  // ---------- Accordions ----------
  function initAccordions(root) {
    (root || document).querySelectorAll('.accordion').forEach(acc => {
      const head = acc.querySelector('.acc-head');
      if (!head || head.dataset.bound) return;
      head.dataset.bound = '1';
      head.addEventListener('click', () => acc.classList.toggle('open'));
    });
  }

  // ---------- Back to top ----------
  function initBackTop() {
    const btn = document.getElementById('backTop');
    if (!btn) return;
    window.addEventListener('scroll', () => {
      btn.classList.toggle('show', window.scrollY > 400);
    }, { passive: true });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  // ---------- Escape key closes modals / search ----------
  function initGlobalKeys() {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeModal();
        const search = document.getElementById('searchPanel');
        if (search) search.classList.remove('open');
        const ov = document.getElementById('searchOverlay');
        if (ov) ov.classList.remove('open');
      }
    });
  }

  return { toast, openModal, closeModal, copyText, initCopyButtons, initTabs, initAccordions, initBackTop, initGlobalKeys };
})();
