/* =========================================================
   HTML & CSS MASTERY — lessons.js
   Renders lesson objects (structured blocks) into HTML,
   and handles lesson navigation + completion.
   ========================================================= */

const LessonRenderer = (function () {

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderCodeBlock(code, lang, caption) {
    let html = '<div class="codeblock">';
    html += '<button class="copy-code" data-copy="next" data-label="Code">Copy</button>';
    if (caption) html += '<div style="position:absolute;top:8px;left:14px;font-size:.72rem;color:#8fa3c8">' + esc(caption) + '</div>';
    html += '<pre><code class="lang-' + esc(lang || '') + '">' + esc(code) + '</code></pre>';
    html += '</div>';
    return html;
  }

  function renderInlineText(text) {
    return text;
  }

  function renderList(items, ordered) {
    const tag = ordered ? 'ol' : 'ul';
    let html = '<' + tag + '>';
    items.forEach(it => { html += '<li>' + renderInlineText(it) + '</li>'; });
    html += '</' + tag + '>';
    return html;
  }

  function renderTable(t) {
    let html = '<div style="overflow-x:auto"><table><thead><tr>';
    (t.head || []).forEach(h => { html += '<th>' + renderInlineText(h) + '</th>'; });
    html += '</tr></thead><tbody>';
    (t.rows || []).forEach(r => {
      html += '<tr>';
      r.forEach(c => { html += '<td>' + renderInlineText(c) + '</td>'; });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    return html;
  }

  function renderCallout(c) {
    const icons = { tip: '💡', warn: '⚠️', good: '✅' };
    return '<div class="callout callout-' + c.type + '"><strong>' + (icons[c.type] || '') + ' ' + renderInlineText(c.title) + '</strong><p>' + renderInlineText(c.text) + '</p></div>';
  }

  function renderTryIt(t) {
    const htmlVal = t.html || '';
    const cssVal = t.css || '';
    return '<div class="tryit" data-tryit>' +
      '<div class="tryit-bar"><span class="title">' + (t.title || 'Try It Yourself') + ' — edit and press Run</span>' +
      '<button class="btn btn-sm btn-primary tryit-run">▶ Run</button>' +
      '<button class="btn btn-sm btn-outline tryit-reset">Reset</button></div>' +
      '<div class="tryit-cols">' +
      '<div class="panel"><textarea class="tryit-html" spellcheck="false">' + esc(htmlVal) + '</textarea></div>' +
      '<div class="panel"><textarea class="tryit-css" spellcheck="false">' + esc(cssVal) + '</textarea></div>' +
      '</div>' +
      '<div class="tryit-preview"></div>' +
      '</div>';
  }

  function renderDemo(t) {
    const doc = '<!DOCTYPE html><html><head><style>body{font-family:sans-serif;padding:14px;margin:0}</style></head><body>' +
      (t.html || '') + '<style>' + (t.css || '') + '</style></body></html>';
    return '<div class="interactive-demo"><div class="demo-tabs"><button class="demo-tab active" data-tab="preview">Preview</button><button class="demo-tab" data-tab="html">HTML</button><button class="demo-tab" data-tab="css">CSS</button></div>' +
      '<div class="demo-pane active" data-panel="preview"><iframe class="demo-frame" sandbox="allow-scripts" srcdoc="' + esc(doc) + '"></iframe></div>' +
      '<div class="demo-pane" data-panel="html">' + renderCodeBlock(t.html || '', 'html', 'HTML') + '</div>' +
      '<div class="demo-pane" data-panel="css">' + renderCodeBlock(t.css || '', 'css', 'CSS') + '</div>' +
      '</div>';
  }

  function renderMiniQuiz(q) {
    const opts = q.options.map((o, i) =>
      '<button class="mq-opt" data-answer="' + i + '" data-correct="' + q.answer + '"><span class="letter">' + 'ABCD'.charAt(i) + '</span> ' + esc(o) + '</button>').join('');
    return '<div class="mini-quiz" data-miniquiz><div class="mq-q">❓ ' + renderInlineText(q.q) + '</div>' +
      '<div class="mq-options">' + opts + '</div>' +
      '<div class="mq-feedback"></div></div>';
  }

  function renderMistakes(items) {
    let html = '<ul class="mistakes">';
    items.forEach(m => { html += '<li><strong>✖ ' + renderInlineText(m.title) + '</strong>' + renderInlineText(m.text) + '</li>'; });
    html += '</ul>';
    return html;
  }

  function renderExerciseNote(e) {
    return '<div class="callout callout-good"><strong>✏️ Practice exercise</strong><p>' + renderInlineText(e.text) +
      '</p><a class="btn btn-sm btn-accent" href="exercises.html">Go to Exercises</a></div>';
  }

  function renderBlock(b) {
    switch (b.t) {
      case 'p': return '<p>' + renderInlineText(b.text) + '</p>';
      case 'lead': return '<p class="lead" style="font-size:1.08rem;color:var(--text-muted)">' + renderInlineText(b.text) + '</p>';
      case 'h3': return '<h3>' + renderInlineText(b.text) + '</h3>';
      case 'code': return renderCodeBlock(b.code, b.lang, b.caption);
      case 'syntax':
        return '<div class="syntax-box"><div class="syntax-label">' + esc(b.label || 'Syntax') + '</div>' + renderCodeBlock(b.code, 'css', '') + '</div>';
      case 'explain': {
        let html = '<div class="code-explain"><div>' + renderCodeBlock(b.code, b.lang, '') + '</div><div><ul class="explain-list">';
        (b.items || []).forEach(it => { html += '<li>' + renderInlineText(it) + '</li>'; });
        html += '</ul></div></div>';
        return html;
      }
      case 'callout': return renderCallout(b);
      case 'list': return renderList(b.items, b.ordered);
      case 'table': return renderTable(b);
      case 'tryit': return renderTryIt(b);
      case 'demo': return renderDemo(b);
      case 'quiz': return renderMiniQuiz(b);
      case 'mistakes': return renderMistakes(b.items);
      case 'exercise': return renderExerciseNote(b);
      case 'hr': return '<hr class="divider">';
      case 'note': return '<p class="text-muted text-small">' + renderInlineText(b.text) + '</p>';
      default: return '';
    }
  }

  function renderLesson(l, opts) {
    opts = opts || {};
    let html = '<div class="card lesson-hero">';
    html += '<div class="crumbs">' + esc(l.module) + ' &nbsp;•&nbsp; Lesson ' + (opts.index !== undefined ? opts.index + 1 : '') + '</div>';
    html += '<h1>' + esc(l.title) + '</h1>';
    if (l.summary) html += '<p class="lead" style="margin:0">' + esc(l.summary) + '</p>';
    html += '</div>';

    html += '<div class="card" style="margin-bottom:22px"><h3 style="margin-top:0">🎯 Learning Objectives</h3><div class="objectives">';
    (l.objectives || []).forEach(o => { html += '<div class="objective"><span class="check">✓</span><span>' + esc(o) + '</span></div>'; });
    html += '</div></div>';

    const bodyBlocks = l.blocks || [];
    let groups = [];
    let current = [];
    bodyBlocks.forEach(b => {
      if (b.t === 'h3') { groups.push(current); current = [b]; }
      else current.push(b);
    });
    if (current.length) groups.push(current);

    let blockNum = 1;
    groups.forEach(group => {
      const head = group.find(b => b.t === 'h3');
      let inner = '';
      group.forEach(b => { if (b.t !== 'h3') inner += renderBlock(b); });
      if (head) {
        html += '<div class="content-block"><h2><span class="num">' + (blockNum++).toString().padStart(2, '0') + '</span>' + renderInlineText(head.text) + '</h2>' + inner + '</div>';
      } else {
        html += '<div class="content-block">' + inner + '</div>';
      }
    });

    html += '<div class="lesson-nav">';
    if (opts.prev) html += '<a class="btn btn-outline" href="lesson.html?id=' + opts.prev.id + '">← ' + esc(opts.prev.title) + '</a>';
    else html += '<span></span>';
    if (opts.next) html += '<a class="btn btn-primary" href="lesson.html?id=' + opts.next.id + '">' + esc(opts.next.title) + ' →</a>';
    else html += '<span></span>';
    html += '</div>';

    return html;
  }

  function initLessonInteractions(container) {
    container = container || document;

    container.querySelectorAll('.tryit').forEach(box => {
      if (box.dataset.init) return;
      box.dataset.init = '1';
      const htmlTa = box.querySelector('.tryit-html');
      const cssTa = box.querySelector('.tryit-css');
      const preview = box.querySelector('.tryit-preview');
      const run = box.querySelector('.tryit-run');
      const reset = box.querySelector('.tryit-reset');
      const initialHtml = htmlTa.value;
      const initialCss = cssTa.value;

      const render = () => {
        const full = '<!DOCTYPE html><html><head><style>body{font-family:sans-serif;margin:0;padding:14px}</style></head><body>' + htmlTa.value + '<style>' + cssTa.value + '</style></body></html>';
        preview.innerHTML = '<iframe class="demo-frame" sandbox="allow-scripts" srcdoc="' + esc(full) + '" style="width:100%;min-height:200px;border:none;background:#fff"></iframe>';
      };

      run.addEventListener('click', render);
      reset.addEventListener('click', () => { htmlTa.value = initialHtml; cssTa.value = initialCss; render(); });
      render();
    });

    container.querySelectorAll('.interactive-demo').forEach(demo => {
      if (demo.dataset.initTabs) return;
      demo.dataset.initTabs = '1';
      demo.querySelectorAll('.demo-tab').forEach(tab => {
        tab.addEventListener('click', () => {
          const target = tab.getAttribute('data-tab');
          demo.querySelectorAll('.demo-tab').forEach(t => t.classList.toggle('active', t === tab));
          demo.querySelectorAll('.demo-pane').forEach(p => p.classList.toggle('active', p.getAttribute('data-panel') === target));
        });
      });
    });

    container.querySelectorAll('.mini-quiz').forEach(mq => {
      if (mq.dataset.initQ) return;
      mq.dataset.initQ = '1';
      const feedback = mq.querySelector('.mq-feedback');
      mq.querySelectorAll('.mq-opt').forEach(btn => {
        btn.addEventListener('click', () => {
          if (mq.dataset.done) return;
          mq.dataset.done = '1';
          const chosen = parseInt(btn.getAttribute('data-answer'), 10);
          const correct = parseInt(btn.getAttribute('data-correct'), 10);
          const isCorrect = chosen === correct;
          btn.classList.add(isCorrect ? 'correct' : 'wrong');
          if (!isCorrect) {
            const rightBtn = mq.querySelector('.mq-opt[data-answer="' + correct + '"]');
            if (rightBtn) rightBtn.classList.add('correct');
          }
          feedback.innerHTML = isCorrect
            ? '<span style="color:var(--accent)">✅ Correct! Well done.</span>'
            : '<span style="color:var(--danger)">❌ Not quite. The correct answer is <b>' + 'ABCD'.charAt(correct) + '</b>.</span>';
        });
      });
    });

    UI.initCopyButtons(container);
    UI.initTabs(container);
  }

  return { renderLesson, initLessonInteractions, renderCodeBlock, esc };
})();
