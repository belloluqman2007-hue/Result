/* =========================================================
   HTML & CSS MASTERY — theme.js
   Light / Dark mode with localStorage persistence.
   ========================================================= */

const Theme = (function () {
  function apply(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const state = Store.load();
    state.theme = theme;
    Store.save();
  }

  function toggle() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    apply(current === 'dark' ? 'light' : 'dark');
    updateButtons();
  }

  function updateButtons() {
    const theme = document.documentElement.getAttribute('data-theme') || 'light';
    const btn = document.getElementById('themeToggle');
    const btnMobile = document.getElementById('themeToggleMobile');
    if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
    if (btnMobile) btnMobile.textContent = theme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';
  }

  function init() {
    const state = Store.load();
    let theme = state.theme;
    if (!theme || (theme !== 'light' && theme !== 'dark')) {
      theme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    document.documentElement.setAttribute('data-theme', theme);
    state.theme = theme;
    Store.save();
    updateButtons();

    // Re-apply theme inside sandboxed preview iframes after they load
    document.addEventListener('click', function (e) {
      const t = e.target.closest('#themeToggle, #themeToggleMobile');
      if (t) toggle();
    });
  }

  return { init, apply, toggle, updateButtons };
})();
