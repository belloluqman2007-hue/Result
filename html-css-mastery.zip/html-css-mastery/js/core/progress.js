/* =========================================================
   HTML & CSS MASTERY — progress.js
   Compute overall and per-module progress percentages.
   ========================================================= */

const Progress = (function () {
  function lessonCount() {
    return Curriculum.getAllLessons().length;
  }

  function completedLessons() {
    return Store.load().completedLessons || [];
  }

  function overallPct() {
    const total = lessonCount();
    if (!total) return 0;
    return Math.round((completedLessons().length / total) * 100);
  }

  function moduleProgress(moduleName) {
    const lessons = Curriculum.getModuleLessons(moduleName);
    if (!lessons.length) return { done: 0, total: 0, pct: 0 };
    const done = lessons.filter(l => Store.isLessonCompleted(l.id)).length;
    return { done, total: lessons.length, pct: Math.round((done / lessons.length) * 100) };
  }

  function moduleProgressList() {
    return Curriculum.getModules().map(m => ({
      module: m.name,
      ...moduleProgress(m.name)
    }));
  }

  function quizzesDone() {
    return Object.keys(Store.load().quizScores || {}).length;
  }

  function exercisesDone() {
    return (Store.load().exercisesSolved || []).length;
  }

  function projectsDone() {
    return (Store.load().projectsCompleted || []).length;
  }

  // Summary data object used by dashboards
  function summary() {
    return {
      lessonsDone: completedLessons().length,
      lessonsTotal: lessonCount(),
      overall: overallPct(),
      modules: moduleProgressList(),
      quizzesDone: quizzesDone(),
      exercisesDone: exercisesDone(),
      projectsDone: projectsDone(),
      achievements: Object.keys(Store.load().achievements || {}).length,
      currentLesson: Store.load().currentLesson,
      streak: Achievements.streak()
    };
  }

  return { overallPct, moduleProgress, moduleProgressList, summary, completedLessons, lessonCount };
})();
