/* =========================================================
   HTML & CSS MASTERY — editor.js
   Live code playground (HTML + CSS → iframe preview) and
   DOM-based exercise validation.
   ========================================================= */

const Editor = (function () {

  function buildDoc(html, css) {
    return '<!DOCTYPE html><html><head><style>html,body{margin:0;padding:0}' +
      'body{font-family:sans-serif;padding:16px}</style>' +
      '<style>' + (css || '') + '</style></head><body>' + (html || '') + '</body></html>';
  }

  function renderPreview(container, html, css) {
    const iframe = document.createElement('iframe');
    iframe.className = 'editor-preview-frame';
    iframe.setAttribute('sandbox', 'allow-scripts');
    iframe.style.cssText = 'width:100%;height:100%;border:none;background:#fff;display:block';
    container.innerHTML = '';
    container.appendChild(iframe);
    iframe.srcdoc = buildDoc(html, css);
  }

  // ---------- Main playground page ----------
  function initPlayground() {
    const htmlTa = document.getElementById('htmlEditor');
    const cssTa = document.getElementById('cssEditor');
    const preview = document.getElementById('playgroundPreview');
    const runBtn = document.getElementById('playgroundRun');
    const resetBtn = document.getElementById('playgroundReset');
    const copyBtn = document.getElementById('playgroundCopy');
    const clearBtn = document.getElementById('playgroundClear');
    const fullBtn = document.getElementById('playgroundFull');
    const templateSelect = document.getElementById('templateSelect');
    const autoCheck = document.getElementById('autoPreview');

    const TEMPLATES = {
      blank: { html: '', css: '' },
      hello: { html: '<h1>Hello World</h1>\n<p>My first webpage.</p>', css: 'h1 {\n  color: blue;\n}' },
      page: { html: '<!DOCTYPE html>\n<html>\n<head>\n  <title>My Website</title>\n</head>\n<body>\n  <h1>Hello World</h1>\n</body>\n</html>', css: '' },
      card: { html: '<div class="card">\n  <h2>My Card</h2>\n  <p>Some text inside a card.</p>\n</div>', css: '.card {\n  border: 1px solid #ccc;\n  border-radius: 12px;\n  padding: 20px;\n  max-width: 300px;\n  box-shadow: 0 4px 10px rgba(0,0,0,0.1);\n}' },
      flex: { html: '<div class="row">\n  <div class="box">1</div>\n  <div class="box">2</div>\n  <div class="box">3</div>\n</div>', css: '.row {\n  display: flex;\n  gap: 16px;\n}\n.box {\n  flex: 1;\n  background: #2f5af0;\n  color: white;\n  padding: 20px;\n  border-radius: 8px;\n  text-align: center;\n}' },
      grid: { html: '<div class="grid">\n  <div class="cell">A</div>\n  <div class="cell">B</div>\n  <div class="cell">C</div>\n</div>', css: '.grid {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 12px;\n}\n.cell {\n  background: #00b386;\n  color: white;\n  padding: 20px;\n  border-radius: 8px;\n  text-align: center;\n}' },
      form: { html: '<form>\n  <label for="name">Name</label>\n  <input type="text" id="name" name="name">\n  <button type="submit">Send</button>\n</form>', css: 'label {\n  display: block;\n  margin-bottom: 4px;\n  font-weight: 600;\n}\ninput, button {\n  padding: 8px;\n  margin-bottom: 10px;\n  border-radius: 6px;\n  border: 1px solid #ccc;\n}\nbutton {\n  background: #2f5af0;\n  color: white;\n  border: none;\n  cursor: pointer;\n}' }
    };

    function setLineNumbers(ta, gutter) {
      if (!gutter) return;
      const lines = ta.value.split('\n').length;
      let html = '';
      for (let i = 1; i <= lines; i++) html += i + '\n';
      gutter.textContent = html;
    }

    const htmlGutter = document.getElementById('htmlGutter');
    const cssGutter = document.getElementById('cssGutter');
    if (htmlGutter) htmlTa.addEventListener('input', () => setLineNumbers(htmlTa, htmlGutter));
    if (cssGutter) cssTa.addEventListener('input', () => setLineNumbers(cssTa, cssGutter));
    setLineNumbers(htmlTa, htmlGutter);
    setLineNumbers(cssTa, cssGutter);

    const htmlWrap = document.getElementById('htmlWrap');
    const cssWrap = document.getElementById('cssWrap');
    if (htmlWrap) htmlWrap.addEventListener('scroll', () => { if (htmlGutter) htmlGutter.style.transform = 'translateY(-' + htmlWrap.scrollTop + 'px)'; });
    if (cssWrap) cssWrap.addEventListener('scroll', () => { if (cssGutter) cssGutter.style.transform = 'translateY(-' + cssWrap.scrollTop + 'px)'; });

    const run = () => renderPreview(preview, htmlTa.value, cssTa.value);

    runBtn.addEventListener('click', run);
    resetBtn.addEventListener('click', () => {
      const t = TEMPLATES.hello;
      htmlTa.value = t.html; cssTa.value = t.css;
      setLineNumbers(htmlTa, htmlGutter); setLineNumbers(cssTa, cssGutter);
      run();
    });
    copyBtn.addEventListener('click', () => {
      const text = '<!-- HTML -->\n' + htmlTa.value + '\n\n/* CSS */\n' + cssTa.value;
      UI.copyText(text, 'Code');
    });
    clearBtn.addEventListener('click', () => {
      htmlTa.value = ''; cssTa.value = '';
      setLineNumbers(htmlTa, htmlGutter); setLineNumbers(cssTa, cssGutter);
      run();
    });
    fullBtn.addEventListener('click', () => {
      const app = document.getElementById('editorApp');
      app.classList.toggle('fullscreen');
      fullBtn.textContent = app.classList.contains('fullscreen') ? '⤢ Exit' : '⤢';
      setTimeout(run, 50);
    });

    if (templateSelect) {
      templateSelect.addEventListener('change', () => {
        const t = TEMPLATES[templateSelect.value] || TEMPLATES.blank;
        htmlTa.value = t.html; cssTa.value = t.css;
        setLineNumbers(htmlTa, htmlGutter); setLineNumbers(cssTa, cssGutter);
        run();
      });
    }

    if (autoCheck) {
      autoCheck.addEventListener('change', () => {
        if (autoCheck.checked) {
          const debounce = (fn, ms) => { let t; return () => { clearTimeout(t); t = setTimeout(fn, ms); }; };
          htmlTa.addEventListener('input', debounce(run, 400));
          cssTa.addEventListener('input', debounce(run, 400));
        }
      });
    }

    run();
  }

  // ---------- Exercise validation ----------

  const TEST_HTML = `<h1>Title</h1>
<p>This is a paragraph with enough words to test.</p>
<div class="card"><h2>My Card</h2><p>Card text.</p></div>
<div class="row"><div class="child">1</div><div class="child">2</div></div>
<div class="grid"><div class="cell">1</div><div class="cell">2</div><div class="cell">3</div></div>
<div class="box">box</div>
<a href="#">link</a>
<div class="hero"></div>
<nav><a href="#">One</a><a href="#">Two</a><a href="#">Three</a></nav>
<div class="sidebar">sidebar</div>
<button class="btn">btn</button>
<header>header</header>
<main>main</main>
<footer>footer</footer>
<ul><li>a</li><li>b</li><li>c</li></ul>
<img src="x.jpg" alt="desc">
<video controls><source src="m.mp4"></video>
<form><label for="name">Name</label><input type="text" id="name"><button type="submit">Go</button></form>
<table><tr><th>N</th><th>S</th></tr><tr><td>a</td><td>b</td></tr></table>`;

  function parseValue(expected, computed) {
    const a = String(expected).trim().toLowerCase();
    let b = String(computed).trim().toLowerCase();
    if (/px$/.test(a) && /px$/.test(b)) {
      return parseFloat(a) === parseFloat(b);
    }
    return a === b;
  }

  const COLOR_PROPS = ['color', 'background-color', 'border-color'];

  function resolveColor(value) {
    try {
      const probe = document.createElement('span');
      probe.style.cssText = 'position:absolute;left:-9999px;color:' + value;
      document.body.appendChild(probe);
      const rgb = getComputedStyle(probe).color.trim();
      probe.remove();
      return rgb;
    } catch (e) { return null; }
  }

  function evaluateChecks(html, css, checks) {
    return new Promise((resolve) => {
      const results = [];
      let doc = null;
      try { doc = new DOMParser().parseFromString(buildDoc(html, css), 'text/html'); }
      catch (e) { doc = null; }

      let container = null;
      let styleEl = null;
      if (checks.some(c => c.type === 'css')) {
        try {
          container = document.createElement('div');
          container.setAttribute('aria-hidden', 'true');
          container.style.cssText = 'position:absolute;left:-9999px;top:0;width:1px;height:1px;overflow:hidden;pointer-events:none;opacity:0;';
          container.innerHTML = html;
          document.body.appendChild(container);
          styleEl = document.createElement('style');
          styleEl.textContent = css;
          document.head.appendChild(styleEl);
        } catch (e) { container = null; }
      }

      checks.forEach(check => {
        let pass = false;
        let detail = check.desc;
        try {
          switch (check.type) {
            case 'tag': {
              const el = doc && doc.querySelector(check.tag);
              if (check.text) {
                pass = !!(el && el.textContent && el.textContent.toLowerCase().includes(String(check.text).toLowerCase()));
              } else {
                pass = !!el;
              }
              break;
            }
            case 'count':
              pass = !!(doc && doc.querySelectorAll(check.tag).length >= (check.min || 1));
              break;
            case 'attr': {
              const el = doc && doc.querySelector(check.tag);
              pass = !!(el && el.hasAttribute(check.attr));
              break;
            }
            case 'css': {
              if (String(check.selector).startsWith('@media')) {
                const m = String(check.selector).match(/@media\s*\(max-width:\s*(\d+)px\)\s+(.+)/i);
                pass = false;
                if (m) {
                  const width = m[1];
                  const sel = m[2];
                  const re = new RegExp('@media\\s*\\(max-width:\\s*' + width + 'px\\)\\s*\\{[^}]*' + sel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[^}]*\\{[^}]*\\}', 'i');
                  pass = re.test(css);
                }
              } else if (container) {
                const el = container.querySelector(check.selector);
                if (!el) { pass = false; detail = 'Selector ' + check.selector + ' not found'; }
                else {
                  const cs = getComputedStyle(el);
                  const computed = cs.getPropertyValue(check.prop).trim();
                  pass = parseValue(check.value, computed);
                  if (!pass && COLOR_PROPS.includes(check.prop)) {
                    const expectedRgb = resolveColor(check.value);
                    pass = !!expectedRgb && expectedRgb.toLowerCase() === computed.toLowerCase();
                  }
                }
              }
              break;
            }
            case 'cssText':
              pass = new RegExp(check.regex, 'i').test(css || '');
              break;
            case 'link': {
              const a = doc && doc.querySelector('a[href]');
              pass = !!a && a.getAttribute('href').trim() !== '';
              break;
            }
            case 'image': {
              const img = doc && doc.querySelector('img[alt]');
              pass = !!img && img.getAttribute('alt').trim() !== '';
              break;
            }
            case 'form': pass = !!(doc && doc.querySelector('form')); break;
            case 'label': pass = !!(doc && doc.querySelector('label[for]')); break;
            case 'inputType': pass = !!(doc && doc.querySelector('input[type="' + check.inputType + '"]')); break;
            case 'list': pass = !!(doc && doc.querySelector(check.ordered ? 'ol' : 'ul')); break;
            case 'video': pass = !!(doc && doc.querySelector('video[controls]')); break;
            case 'header': case 'nav': case 'main': case 'footer':
              pass = !!(doc && doc.querySelector(check.type));
              break;
            default: pass = false;
          }
        } catch (e) { pass = false; }
        results.push({ desc: detail, pass });
      });

      if (container) container.remove();
      if (styleEl) styleEl.remove();

      resolve(results);
    });
  }

  async function runExercise(code, exercise) {
    let html, css;
    if (exercise.css) {
      html = TEST_HTML;
      css = code;
    } else {
      html = code;
      css = '';
      const m = code.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
      if (m) css = m[1];
    }
    const results = await evaluateChecks(html, css, exercise.checks);
    const allPass = results.every(r => r.pass);
    return { pass: allPass, results };
  }

  return { renderPreview, initPlayground, runExercise, buildDoc };
})();
