/* =========================================================
   HTML & CSS MASTERY — store.js
   localStorage helpers + progress state management.
   ========================================================= */

const Store = (function () {
  const PREFIX = 'hcm.';

  // The single source of truth for all user progress.
  const DEFAULT_STATE = {
    completedLessons: [],      // lesson ids completed
    currentLesson: null,       // most recent lesson id
    lessonVisits: {},          // lessonId -> count (for activity)
    quizScores: {},            // quizId -> {score, total, pct, date}
    exercisesSolved: [],       // exercise ids solved
    projectsCompleted: [],     // project ids completed
    achievements: {},          // achievementId -> dateISO
    lastActivityDate: null,    // for streak tracking
    theme: 'light',            // 'light' | 'dark'
    prefs: { autosave: true }
  };

  let state = null;

  function load() {
    if (state) return state;
    try {
      const raw = localStorage.getItem(PREFIX + 'state');
      state = Object.assign({}, DEFAULT_STATE, raw ? JSON.parse(raw) : {});
    } catch (e) {
      state = Object.assign({}, DEFAULT_STATE);
    }
    // Make sure nested structures exist
    state.completedLessons = state.completedLessons || [];
    state.lessonVisits = state.lessonVisits || {};
    state.quizScores = state.quizScores || {};
    state.exercisesSolved = state.exercisesSolved || [];
    state.projectsCompleted = state.projectsCompleted || [];
    state.achievements = state.achievements || {};
    state.prefs = state.prefs || { autosave: true };
    return state;
  }

  function save() {
    try {
      localStorage.setItem(PREFIX + 'state', JSON.stringify(state));
    } catch (e) {
      console.warn('Could not save progress', e);
    }
    document.dispatchEvent(new CustomEvent('hcm:statechange', { detail: state }));
  }

  function reset() {
    state = Object.assign({}, DEFAULT_STATE);
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.indexOf(PREFIX) === 0) toRemove.push(k);
    }
    toRemove.forEach((k) => localStorage.removeItem(k));
    save();
  }

  function touchActivity() {
    state.lastActivityDate = new Date().toISOString().slice(0, 10);
  }

  // ---- Lesson helpers ----
  function completeLesson(id) {
    load();
    if (!state.completedLessons.includes(id)) {
      state.completedLessons.push(id);
    }
    state.currentLesson = id;
    touchActivity();
    save();
    Achievements.check();
  }

  function isLessonCompleted(id) {
    load();
    return state.completedLessons.includes(id);
  }

  function visitLesson(id) {
    load();
    state.currentLesson = id;
    state.lessonVisits[id] = (state.lessonVisits[id] || 0) + 1;
    save();
  }

  // ---- Quiz helpers ----
  function saveQuizScore(quizId, score, total) {
    load();
    const pct = total ? Math.round((score / total) * 100) : 0;
    const prev = state.quizScores[quizId];
    if (!prev || (prev && pct >= prev.pct)) {
      state.quizScores[quizId] = { score, total, pct, date: new Date().toISOString() };
    }
    touchActivity();
    save();
    Achievements.check();
  }

  // ---- Exercises ----
  function solveExercise(id) {
    load();
    if (!state.exercisesSolved.includes(id)) state.exercisesSolved.push(id);
    touchActivity();
    save();
    Achievements.check();
  }

  // ---- Projects ----
  function completeProject(id) {
    load();
    if (!state.projectsCompleted.includes(id)) state.projectsCompleted.push(id);
    touchActivity();
    save();
    Achievements.check();
  }

  function isProjectCompleted(id) {
    load();
    return state.projectsCompleted.includes(id);
  }

  function setPref(key, value) {
    load();
    state.prefs[key] = value;
    save();
  }

  function getState() { load(); return state; }

  return {
    load, save, reset, getState, setPref,
    completeLesson, isLessonCompleted, visitLesson,
    saveQuizScore, solveExercise, completeProject, isProjectCompleted,
    touchActivity
  };
})();
