/* =========================================================
   HTML & CSS MASTERY — curriculum.js
   Central registry for course modules, lessons and ordering.
   Lesson content is registered via Curriculum.addLesson().
   ========================================================= */

const Curriculum = (function () {
  const lessons = [];

  const MODULES = [
    { name: 'Module 1 — Introduction',            code: 'html-intro' },
    { name: 'Module 2 — HTML Basics',              code: 'html-basics' },
    { name: 'Module 3 — HTML Components',          code: 'html-components' },
    { name: 'Module 4 — Semantic HTML',            code: 'html-semantic' },
    { name: 'Module 5 — CSS Fundamentals',         code: 'css-fundamentals' },
    { name: 'Module 6 — Box Model',                code: 'css-box' },
    { name: 'Module 7 — Layout',                   code: 'css-layout' },
    { name: 'Module 8 — Responsive Design',        code: 'css-responsive' },
    { name: 'Module 9 — Effects',                  code: 'css-effects' },
    { name: 'Module 10 — CSS Deep Dive',           code: 'css-deep-dive' },
  ];

  function addLesson(lesson) {
    lessons.push(lesson);
  }

  function getAllLessons() {
    return lessons;
  }

  function getModuleLessons(moduleName) {
    return lessons.filter(l => l.module === moduleName);
  }

  function getModules() {
    return MODULES.map(m => ({ name: m.name, code: m.code }));
  }

  function getLesson(id) {
    return lessons.find(l => l.id === id) || null;
  }

  function getIndex(id) {
    return lessons.findIndex(l => l.id === id);
  }

  function getPrevLesson(id) {
    const i = getIndex(id);
    return i > 0 ? lessons[i - 1] : null;
  }

  function getNextLesson(id) {
    const i = getIndex(id);
    return i < lessons.length - 1 ? lessons[i + 1] : null;
  }

  function getFirstLesson() {
    return lessons[0] || null;
  }

  function search(query) {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    return lessons
      .filter(l => (l.title + ' ' + l.module + ' ' + (l.keywords || []).join(' ')).toLowerCase().includes(q))
      .map(l => ({
        type: 'Lesson',
        title: l.title,
        snippet: l.summary,
        url: 'lesson.html?id=' + l.id
      }));
  }

  return {
    addLesson, getAllLessons, getModuleLessons, getModules,
    getLesson, getIndex, getPrevLesson, getNextLesson, getFirstLesson, search
  };
})();
