/* =========================================================
   HTML & CSS MASTERY — exercises.js
   Coding challenges with DOM-based validation.
   Check types:
     {type:'tag', tag, text, desc}            element with tag + optional text
     {type:'count', tag, min, desc}           at least N elements
     {type:'attr', tag, attr, value, desc}    element attribute present
     {type:'css', selector, prop, value, desc} computed style equals value
     {type:'link', desc}                       has an <a> with href
     {type:'image', desc}                      has an <img> with alt
     {type:'form', desc}                       has a <form>
     {type:'label', desc}                      has a <label> with for
     {type:'inputType', inputType, desc}       has an input of a type
     {type:'list', ordered, desc}              has a ul or ol
     {type:'video', desc}                      has a <video>
     {type:'header', desc}/{type:'nav', desc}/{type:'main', desc}/{type:'footer', desc}
   ========================================================= */

const EXERCISES = [
  // ---------- HTML basics ----------
  { id: 'ex-hello', module: 'HTML Basics', title: 'My First Heading', difficulty: 'easy',
    prompt: 'Create an <code>&lt;h1&gt;</code> element that contains the text <strong>Welcome to My Website</strong>.',
    starter: '<!-- Write your code here -->\n\n',
    checks: [{ type: 'tag', tag: 'h1', text: 'Welcome to My Website', desc: 'An &lt;h1&gt; with the text "Welcome to My Website"' }],
    hint: 'Write an opening tag &lt;h1&gt;, the text, then a closing tag &lt;/h1&gt;.',
    solution: '<h1>Welcome to My Website</h1>' },

  { id: 'ex-two-headings', module: 'HTML Basics', title: 'Heading Hierarchy', difficulty: 'easy',
    prompt: 'Create an <code>&lt;h1&gt;</code> with the text "My Page", then an <code>&lt;h2&gt;</code> with the text "About Me".',
    starter: '<!-- Add two headings -->\n\n',
    checks: [
      { type: 'tag', tag: 'h1', text: 'My Page', desc: 'An &lt;h1&gt; containing "My Page"' },
      { type: 'tag', tag: 'h2', text: 'About Me', desc: 'An &lt;h2&gt; containing "About Me"' }
    ],
    hint: 'Use &lt;h1&gt; for the main title and &lt;h2&gt; for a section heading.',
    solution: '<h1>My Page</h1>\n<h2>About Me</h2>' },

  { id: 'ex-paragraph', module: 'HTML Basics', title: 'A Paragraph', difficulty: 'easy',
    prompt: 'Create a <code>&lt;p&gt;</code> element containing at least 5 words of text.',
    starter: '<!-- Add a paragraph -->\n\n',
    checks: [{ type: 'tag', tag: 'p', desc: 'A &lt;p&gt; paragraph element' }],
    hint: 'A paragraph is written as &lt;p&gt;text&lt;/p&gt;.',
    solution: '<p>This is my very first paragraph of text.</p>' },

  { id: 'ex-link', module: 'HTML Basics', title: 'A Link', difficulty: 'easy',
    prompt: 'Create a link that points to <strong>https://example.com</strong> and displays the text "Visit Example".',
    starter: '<!-- Add a link -->\n\n',
    checks: [{ type: 'link', desc: 'An &lt;a&gt; element with a valid href' }],
    hint: 'Links use the &lt;a&gt; tag with an href attribute: &lt;a href="..."&gt;text&lt;/a&gt;.',
    solution: '<a href="https://example.com">Visit Example</a>' },

  { id: 'ex-image', module: 'HTML Basics', title: 'An Accessible Image', difficulty: 'easy',
    prompt: 'Add an <code>&lt;img&gt;</code> element with <code>src="photo.jpg"</code> and a meaningful <code>alt</code> attribute.',
    starter: '<!-- Add an image -->\n\n',
    checks: [
      { type: 'image', desc: 'An &lt;img&gt; element' },
      { type: 'attr', tag: 'img', attr: 'alt', desc: 'The image has an alt attribute' }
    ],
    hint: 'Use &lt;img src="photo.jpg" alt="A description of the photo"&gt;.',
    solution: '<img src="photo.jpg" alt="A scenic landscape photo">' },

  { id: 'ex-list', module: 'HTML Basics', title: 'An Unordered List', difficulty: 'easy',
    prompt: 'Create a <code>&lt;ul&gt;</code> with at least 3 <code>&lt;li&gt;</code> items.',
    starter: '<!-- Add a list -->\n\n',
    checks: [
      { type: 'list', ordered: false, desc: 'A &lt;ul&gt; unordered list' },
      { type: 'count', tag: 'li', min: 3, desc: 'At least 3 list items' }
    ],
    hint: 'Wrap list items in &lt;ul&gt;...&lt;/ul&gt;, each as &lt;li&gt;item&lt;/li&gt;.',
    solution: '<ul>\n  <li>HTML</li>\n  <li>CSS</li>\n  <li>JavaScript</li>\n</ul>' },

  // ---------- HTML components ----------
  { id: 'ex-table', module: 'HTML Components', title: 'A Simple Table', difficulty: 'medium',
    prompt: 'Create a table with a header row containing "Name" and "Score", and at least one data row.',
    starter: '<!-- Add a table -->\n\n',
    checks: [
      { type: 'tag', tag: 'table', desc: 'A &lt;table&gt; element' },
      { type: 'count', tag: 'th', min: 2, desc: 'At least 2 header cells (&lt;th&gt;)' },
      { type: 'count', tag: 'td', min: 2, desc: 'At least 2 data cells (&lt;td&gt;)' }
    ],
    hint: 'Rows are &lt;tr&gt;. Header cells are &lt;th&gt;, data cells are &lt;td&gt;.',
    solution: '<table>\n  <tr>\n    <th>Name</th><th>Score</th>\n  </tr>\n  <tr>\n    <td>Amina</td><td>85</td>\n  </tr>\n</table>' },

  { id: 'ex-form', module: 'HTML Components', title: 'A Labeled Form', difficulty: 'medium',
    prompt: 'Create a form containing a text input and a submit button. Give the input a label connected with the <code>for</code> attribute.',
    starter: '<!-- Add a form -->\n\n',
    checks: [
      { type: 'form', desc: 'A &lt;form&gt; element' },
      { type: 'inputType', inputType: 'text', desc: 'A text input' },
      { type: 'label', desc: 'A &lt;label&gt; with a for attribute' },
      { type: 'tag', tag: 'button', desc: 'A submit button' }
    ],
    hint: 'Link the label to the input: label for="name" and input id="name".',
    solution: '<form>\n  <label for="name">Name</label>\n  <input type="text" id="name">\n  <button type="submit">Send</button>\n</form>' },

  { id: 'ex-multimedia', module: 'HTML Components', title: 'Embed a Video', difficulty: 'medium',
    prompt: 'Add a <code>&lt;video&gt;</code> element with the <code>controls</code> attribute and a source file <code>movie.mp4</code>.',
    starter: '<!-- Add a video -->\n\n',
    checks: [
      { type: 'video', desc: 'A &lt;video&gt; element with controls' }
    ],
    hint: 'Use &lt;video controls&gt; with a &lt;source src="movie.mp4"&gt; inside.',
    solution: '<video controls>\n  <source src="movie.mp4" type="video/mp4">\n</video>' },

  { id: 'ex-semantic', module: 'Semantic HTML', title: 'Semantic Structure', difficulty: 'medium',
    prompt: 'Structure a page using <code>&lt;header&gt;</code>, <code>&lt;nav&gt;</code>, <code>&lt;main&gt;</code>, and <code>&lt;footer&gt;</code> elements.',
    starter: '<!-- Build a semantic page structure -->\n\n',
    checks: [
      { type: 'header', desc: 'A &lt;header&gt; element' },
      { type: 'nav', desc: 'A &lt;nav&gt; element' },
      { type: 'main', desc: 'A &lt;main&gt; element' },
      { type: 'footer', desc: 'A &lt;footer&gt; element' }
    ],
    hint: 'Wrap the top in &lt;header&gt;, navigation in &lt;nav&gt;, main content in &lt;main&gt; and bottom in &lt;footer&gt;.',
    solution: '<header>\n  <h1>My Site</h1>\n</header>\n<nav>\n  <a href="#">Home</a>\n  <a href="#">About</a>\n</nav>\n<main>\n  <p>Welcome!</p>\n</main>\n<footer>\n  <p>&copy; 2026</p>\n</footer>' },

  // ---------- CSS ----------
  { id: 'ex-css-color', module: 'CSS Fundamentals', title: 'Make Text Blue', difficulty: 'easy', css: true,
    prompt: 'Write CSS that makes all <code>&lt;h1&gt;</code> elements the color <strong>blue</strong>.',
    starter: '/* Style the h1 */\n',
    checks: [{ type: 'css', selector: 'h1', prop: 'color', value: 'blue', desc: 'h1 text color is blue' }],
    hint: 'h1 { color: blue; }',
    solution: 'h1 { color: blue; }' },

  { id: 'ex-css-class', module: 'CSS Fundamentals', title: 'Style a Class', difficulty: 'easy', css: true,
    prompt: 'Write CSS so that elements with class <code>card</code> have a <strong>2px solid gray</strong> border and <strong>10px</strong> padding.',
    starter: '/* Style .card */\n',
    checks: [
      { type: 'css', selector: '.card', prop: 'border-width', value: '2px', desc: '.card has a 2px border width' },
      { type: 'css', selector: '.card', prop: 'padding', value: '10px', desc: '.card has 10px padding' }
    ],
    hint: '.card { border: 2px solid gray; padding: 10px; }',
    solution: '.card { border: 2px solid gray; padding: 10px; }' },

  { id: 'ex-flex', module: 'Layout', title: 'Flexbox Row', difficulty: 'medium', css: true,
    prompt: 'Give <code>.row</code> a <code>display: flex</code> with items spaced using <code>justify-content: space-between</code> and a <code>16px</code> gap.',
    starter: '.row {\n  /* your flexbox here */\n}\n',
    checks: [
      { type: 'css', selector: '.row', prop: 'display', value: 'flex', desc: '.row uses flexbox' },
      { type: 'css', selector: '.row', prop: 'justify-content', value: 'space-between', desc: 'Items are spaced apart' },
      { type: 'css', selector: '.row', prop: 'gap', value: '16px', desc: 'A 16px gap between items' }
    ],
    hint: 'display:flex; justify-content:space-between; gap:16px;',
    solution: '.row {\n  display: flex;\n  justify-content: space-between;\n  gap: 16px;\n}' },

  { id: 'ex-grid', module: 'Layout', title: 'Grid Columns', difficulty: 'medium', css: true,
    prompt: 'Make <code>.grid</code> a CSS grid with <strong>three equal columns</strong> using the <code>fr</code> unit, with a <code>12px</code> gap.',
    starter: '.grid {\n  /* your grid here */\n}\n',
    checks: [
      { type: 'css', selector: '.grid', prop: 'display', value: 'grid', desc: '.grid uses CSS grid' },
      { type: 'css', selector: '.grid', prop: 'grid-template-columns', value: '1fr 1fr 1fr', desc: 'Three equal columns' },
      { type: 'css', selector: '.grid', prop: 'gap', value: '12px', desc: 'A 12px gap' }
    ],
    hint: 'display:grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;',
    solution: '.grid {\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr;\n  gap: 12px;\n}' },

  { id: 'ex-center', module: 'Layout', title: 'Center a Block', difficulty: 'medium', css: true,
    prompt: 'Center <code>.box</code> horizontally by giving it a width of <code>300px</code> and using <code>margin</code> with auto left and right values.',
    starter: '.box {\n  /* center me */\n}\n',
    checks: [
      { type: 'css', selector: '.box', prop: 'width', value: '300px', desc: '.box has a width of 300px' },
      { type: 'css', selector: '.box', prop: 'margin-left', value: 'auto', desc: 'Left margin is auto' },
      { type: 'css', selector: '.box', prop: 'margin-right', value: 'auto', desc: 'Right margin is auto' }
    ],
    hint: 'width:300px; margin: 0 auto;',
    solution: '.box {\n  width: 300px;\n  margin: 0 auto;\n}' },

  { id: 'ex-media', module: 'Responsive Design', title: 'A Media Query', difficulty: 'hard', css: true,
    prompt: 'Write a media query that hides elements with class <code>sidebar</code> (display: none) when the screen is at most <strong>768px</strong> wide.',
    starter: '/* Add a media query */\n',
    checks: [{ type: 'css', selector: '@media (max-width: 768px) .sidebar', prop: 'display', value: 'none', desc: 'Sidebar hidden at max-width 768px' }],
    hint: '@media (max-width: 768px) { .sidebar { display: none; } }',
    solution: '@media (max-width: 768px) {\n  .sidebar { display: none; }\n}' },

  { id: 'ex-hover', module: 'Effects', title: 'A Hover Effect', difficulty: 'medium', css: true,
    prompt: 'Make links turn <strong>blue</strong> when hovered using the <code>:hover</code> pseudo-class.',
    starter: '/* Style links on hover */\n',
    checks: [{ type: 'css', selector: 'a:hover', prop: 'color', value: 'blue', desc: 'Links turn blue on hover' }],
    hint: 'a:hover { color: blue; }',
    solution: 'a:hover { color: blue; }' },

  { id: 'ex-transition', module: 'Effects', title: 'A Smooth Transition', difficulty: 'hard', css: true,
    prompt: 'Add a <code>transition</code> to <code>.btn</code> so that <code>background-color</code> animates over <strong>0.3 seconds</strong>.',
    starter: '.btn {\n  /* add a transition */\n}\n',
    checks: [{ type: 'css', selector: '.btn', prop: 'transition-duration', value: '0.3s', desc: 'A transition lasting 0.3s' }],
    hint: 'transition: background-color 0.3s ease;',
    solution: '.btn {\n  transition: background-color 0.3s ease;\n}' },

  { id: 'ex-boxmodel', module: 'Box Model', title: 'Padding Shorthand', difficulty: 'easy', css: true,
    prompt: 'Give <code>.box</code> <strong>20px</strong> padding on top and bottom and <strong>10px</strong> on left and right, using the shorthand.',
    starter: '.box {\n  /* padding */\n}\n',
    checks: [
      { type: 'css', selector: '.box', prop: 'padding-top', value: '20px', desc: '20px top padding' },
      { type: 'css', selector: '.box', prop: 'padding-left', value: '10px', desc: '10px left padding' }
    ],
    hint: 'padding: 20px 10px;',
    solution: '.box {\n  padding: 20px 10px;\n}' },

  { id: 'ex-font', module: 'CSS Fundamentals', title: 'Font Size', difficulty: 'easy', css: true,
    prompt: 'Set <code>p</code> elements to <code>font-size: 18px</code> and <code>line-height: 1.6</code>.',
    starter: 'p {\n  /* styles */\n}\n',
    checks: [
      { type: 'css', selector: 'p', prop: 'font-size', value: '18px', desc: 'p font-size is 18px' },
      { type: 'css', selector: 'p', prop: 'line-height', value: '1.6', desc: 'p line-height is 1.6' }
    ],
    hint: 'p { font-size: 18px; line-height: 1.6; }',
    solution: 'p {\n  font-size: 18px;\n  line-height: 1.6;\n}' },

  { id: 'ex-background', module: 'CSS Fundamentals', title: 'A Background Image', difficulty: 'medium', css: true,
    prompt: 'Give <code>.hero</code> a <code>background-image</code> of <code>url("bg.jpg")</code> with <code>background-size: cover</code> and no repeat.',
    starter: '.hero {\n  /* background */\n}\n',
    checks: [
      { type: 'css', selector: '.hero', prop: 'background-image', value: 'url("bg.jpg")', desc: 'Uses bg.jpg as background' },
      { type: 'css', selector: '.hero', prop: 'background-size', value: 'cover', desc: 'background-size is cover' }
    ],
    hint: 'background-image: url("bg.jpg"); background-size: cover;',
    solution: '.hero {\n  background-image: url("bg.jpg");\n  background-size: cover;\n  background-repeat: no-repeat;\n}' },

  // ---------- Combined HTML+CSS ----------
  { id: 'ex-card', module: 'Project Building', title: 'A Styled Card', difficulty: 'medium', css: true,
    prompt: 'Build a <code>&lt;div class="card"&gt;</code> containing an <code>&lt;h2&gt;</code> with "My Card" and a <code>&lt;p&gt;</code>. Style the card with a <strong>border</strong>, <strong>12px radius</strong> and <strong>16px padding</strong>.',
    starter: '<div class="card">\n  <!-- content -->\n</div>\n\n<style>\n  /* styles */\n</style>\n',
    checks: [
      { type: 'tag', tag: 'h2', text: 'My Card', desc: 'An &lt;h2&gt; with "My Card"' },
      { type: 'css', selector: '.card', prop: 'border-width', value: '1px', desc: 'The card has a border' },
      { type: 'css', selector: '.card', prop: 'border-radius', value: '12px', desc: 'The card has rounded corners' }
    ],
    hint: 'Set a border, border-radius and padding on .card.',
    solution: '<div class="card">\n  <h2>My Card</h2>\n  <p>This is a styled card.</p>\n</div>\n<style>\n  .card { border: 1px solid gray; border-radius: 12px; padding: 16px; }\n</style>' },

  { id: 'ex-navbar', module: 'Project Building', title: 'A Flex Navbar', difficulty: 'medium', css: true,
    prompt: 'Create a <code>&lt;nav&gt;</code> containing three links and a brand text. Use <code>display: flex</code> on the nav with <code>justify-content: space-between</code>.',
    starter: '<nav>\n  <!-- brand and links -->\n</nav>\n\n<style>\n  /* flexbox */\n</style>\n',
    checks: [
      { type: 'nav', desc: 'A &lt;nav&gt; element' },
      { type: 'count', tag: 'a', min: 3, desc: 'At least 3 links' },
      { type: 'css', selector: 'nav', prop: 'display', value: 'flex', desc: 'Nav uses flexbox' },
      { type: 'css', selector: 'nav', prop: 'justify-content', value: 'space-between', desc: 'Brand and links spread apart' }
    ],
    hint: 'display:flex; justify-content: space-between; on nav.',
    solution: '<nav>\n  <span>MySite</span>\n  <div>\n    <a href="#">Home</a>\n    <a href="#">About</a>\n    <a href="#">Contact</a>\n  </div>\n</nav>\n<style>\n  nav { display: flex; justify-content: space-between; align-items: center; }\n</style>' },

  { id: 'ex-html5-doc', module: 'HTML Basics', title: 'Full Document', difficulty: 'medium',
    prompt: 'Write a complete HTML5 document: <code>&lt;!DOCTYPE html&gt;</code>, an <code>&lt;html&gt;</code> element, a <code>&lt;head&gt;</code> with a title "My Site", and a <code>&lt;body&gt;</code> with one heading.',
    starter: '<!-- Write a full HTML document -->\n\n',
    checks: [
      { type: 'tag', tag: 'html', desc: 'An &lt;html&gt; element' },
      { type: 'tag', tag: 'head', desc: 'A &lt;head&gt; element' },
      { type: 'tag', tag: 'body', desc: 'A &lt;body&gt; element' },
      { type: 'count', tag: 'h1', min: 1, desc: 'At least one heading' }
    ],
    hint: 'Doctype, then html > head > body.',
    solution: '<!DOCTYPE html>\n<html>\n  <head>\n    <title>My Site</title>\n  </head>\n  <body>\n    <h1>Welcome</h1>\n  </body>\n</html>' }
];

const Exercises = {
  getAll() { return EXERCISES; },
  get(id) { return EXERCISES.find(e => e.id === id); },
  search(q) {
    const query = q.toLowerCase().trim();
    if (!query) return [];
    return EXERCISES.filter(e => (e.title + ' ' + e.module + ' ' + e.prompt).toLowerCase().includes(query))
      .map(e => ({ type: 'Exercise', title: e.title, snippet: e.prompt.replace(/<[^>]+>/g, ''), url: 'exercises.html#ex-' + e.id }));
  }
};
