/* =========================================================
   HTML & CSS MASTERY — lessons-intro.js
   Module 1 (Introduction) — Module 4 (Semantic HTML)
   ========================================================= */

(function () {

  /* ============ MODULE 1 — INTRODUCTION ============ */

  Curriculum.addLesson({
    id: 'what-is-web-dev',
    module: 'Module 1 — Introduction',
    title: 'What Is Web Development?',
    summary: 'Understand how websites work and what frontend and backend development mean.',
    keywords: ['web development', 'frontend', 'backend', 'browser', 'html', 'css', 'javascript', 'website'],
    objectives: [
      'Understand what a website is',
      'Know the three building blocks: HTML, CSS and JavaScript',
      'Understand the difference between frontend and backend',
      'Understand how your browser reads code'
    ],
    blocks: [
      { t: 'lead', text: 'Before you write a single line of code, it helps to understand what actually happens when you open a website in your browser.' },
      { t: 'h3', text: 'What is a website?' },
      { t: 'p', text: 'A <strong>website</strong> is a collection of web pages that live on the internet. Each web page is a file written in code. When you visit a site, your <strong>browser</strong> (Chrome, Firefox, Edge, Safari) downloads those files and turns them into the page you see and interact with.' },
      { t: 'p', text: 'Websites are built with three main languages. You can think of a website like a house:' },
      { t: 'table', head: ['Language', 'Role', 'House analogy'], rows: [
        ['<code>HTML</code>', 'The structure and content', 'The bricks, walls, rooms and furniture'],
        ['<code>CSS</code>', 'The styling and look', 'The paint, wallpaper, lighting and decorations'],
        ['<code>JavaScript</code>', 'The behaviour and interaction', 'The electricity, plumbing and gadgets that make things work']
      ] },
      { t: 'h3', text: 'Frontend vs Backend' },
      { t: 'p', text: 'Web development is split into two main areas:' },
      { t: 'list', items: [
        '<strong>Frontend</strong> — what the user sees and clicks. Built with <code>HTML</code>, <code>CSS</code> and <code>JavaScript</code>. This is exactly what you will learn in this course.',
        '<strong>Backend</strong> — the server, database and logic behind the scenes that store data and send it to the browser. Languages include Node.js, Python, PHP and more.'
      ] },
      { t: 'callout', type: 'tip', title: 'Why this matters',
        text: 'In this course you become a <strong>frontend developer</strong>. You will be able to build beautiful, responsive websites entirely with HTML and CSS — and add interactivity with JavaScript.' },
      { t: 'h3', text: 'How the browser builds a page' },
      { t: 'p', text: 'When the browser receives an HTML file it reads it from top to bottom and builds a model of the page called the <strong>DOM</strong> (Document Object Model). It then applies CSS to make it pretty and runs JavaScript to make it interactive.' },
      { t: 'callout', type: 'good', title: 'Key idea',
        text: 'HTML <strong>structures</strong>, CSS <strong>styles</strong>, JavaScript <strong>behaves</strong>. Master all three and you can build almost anything on the web.' },
      { t: 'quiz', q: 'Which language is responsible for the STRUCTURE of a webpage?', options: ['CSS', 'JavaScript', 'HTML', 'Python'], answer: 2,
        explanation: 'HTML (HyperText Markup Language) defines the structure and content. CSS handles styling and JavaScript handles behaviour.' }
    ]
  });

  Curriculum.addLesson({
    id: 'what-is-html',
    module: 'Module 1 — Introduction',
    title: 'What Is HTML?',
    summary: 'Learn what HTML is and meet tags, elements and the basic anatomy of markup.',
    keywords: ['html', 'markup', 'tag', 'element', 'hypertext', 'language'],
    objectives: [
      'Define HTML and what "markup" means',
      'Understand tags and elements',
      'See the anatomy of an HTML element',
      'Understand why HTML is called a "markup" language'
    ],
    blocks: [
      { t: 'lead', text: '<strong>HTML</strong> stands for <strong>HyperText Markup Language</strong>. It is the language used to describe the structure and content of a web page.' },
      { t: 'p', text: 'HTML is <strong>not</strong> a programming language. It is a <strong>markup language</strong>, which means it marks up (labels) content so the browser knows what each piece of content is.' },
      { t: 'h3', text: 'What does "markup" mean?' },
      { t: 'p', text: 'Imagine a school report. You highlight headings in one colour, names in another, and important facts in bold. That labelling is "marking up". HTML does the same thing for the browser — it tells the browser "this is a heading", "this is a paragraph", "this is a link".' },
      { t: 'h3', text: 'Tags and elements' },
      { t: 'p', text: 'HTML uses <strong>tags</strong> written between angle brackets like <code>&lt;p&gt;</code>. A tag plus its content is called an <strong>element</strong>. Here is a complete paragraph element:' },
      { t: 'code', lang: 'html', caption: 'A paragraph element', code: `<p>This is a paragraph of text.</p>` },
      { t: 'p', text: 'The parts are:' },
      { t: 'list', items: [
        '<strong>Opening tag</strong> <code>&lt;p&gt;</code> — where the element begins.',
        '<strong>Content</strong> — the actual text or stuff inside.',
        '<strong>Closing tag</strong> <code>&lt;/p&gt;</code> — note the forward slash <code>/</code> — where the element ends.'
      ] },
      { t: 'h3', text: 'Nesting elements' },
      { t: 'p', text: 'Elements can live inside other elements. This is called <strong>nesting</strong>. The inner element should close before the outer one closes:' },
      { t: 'code', lang: 'html', caption: 'Correct and incorrect nesting', code: `<!-- Correct: inner closes first -->
<div>
  <p>Hello</p>
</div>

<!-- Incorrect: closing order is wrong -->
<div>
  <p>Hello</div>
</p>` },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'Forgetting the closing tag <code>&lt;/p&gt;</code> is one of the most common beginner mistakes. Most tags need a closing tag — always close what you open.' },
      { t: 'quiz', q: 'HTML is best described as:', options: ['A programming language', 'A markup language', 'A styling language', 'A database'], answer: 1,
        explanation: 'HTML is a markup language — it marks up content to describe its structure. It does not contain programming logic like loops or conditions.' }
    ]
  });

  Curriculum.addLesson({
    id: 'html-document-structure',
    module: 'Module 1 — Introduction',
    title: 'HTML Document Structure',
    summary: 'Learn the skeleton of every HTML page: doctype, html, head and body.',
    keywords: ['doctype', 'html', 'head', 'body', 'title', 'meta', 'structure', 'skeleton'],
    objectives: [
      'Identify the four main parts of an HTML page',
      'Understand the head and body',
      'Write a complete minimal HTML document',
      'Understand the doctype declaration'
    ],
    blocks: [
      { t: 'lead', text: 'Every HTML page follows the same skeleton. Learn this once and you will recognize it in every website you ever inspect.' },
      { t: 'code', lang: 'html', caption: 'The complete HTML skeleton', code: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>My First Page</title>
  </head>
  <body>
    <h1>Hello World</h1>
    <p>Welcome to my website.</p>
  </body>
</html>` },
      { t: 'h3', text: 'Breaking it down' },
      { t: 'list', items: [
        '<code>&lt;!DOCTYPE html&gt;</code> — tells the browser this is modern HTML5. It is a declaration, not a tag.',
        '<code>&lt;html&gt;</code> — the root element that wraps the whole page. The <code>lang="en"</code> attribute declares the language.',
        '<code>&lt;head&gt;</code> — invisible "behind the scenes" info: the page title, character set, and links to CSS files. Nothing in the head shows on the page.',
        '<code>&lt;body&gt;</code> — everything the user actually sees goes here.'
      ] },
      { t: 'callout', type: 'tip', title: 'The head vs the body',
        text: 'Think of the <code>&lt;head&gt;</code> as the page\'s ID card (metadata) and the <code>&lt;body&gt;</code> as the actual person (visible content).' },
      { t: 'h3', text: 'Try it yourself' },
      { t: 'tryit', html: `<!DOCTYPE html>
<html>
  <head>
    <title>My First Page</title>
  </head>
  <body>
    <h1>Hello World</h1>
    <p>My very first web page.</p>
  </body>
</html>` },
      { t: 'callout', type: 'warn', title: 'Common mistakes',
        text: 'Putting visible content inside <code>&lt;head&gt;</code>, forgetting <code>&lt;!DOCTYPE html&gt;</code>, or writing content before the <code>&lt;html&gt;</code> tag are common errors. Keep your structure tidy.' },
      { t: 'quiz', q: 'Where does the text you see on a webpage go?', options: ['Inside the <head>', 'Inside the <body>', 'Inside the <title>', 'Before the <!DOCTYPE html>'], answer: 1,
        explanation: 'Visible content goes inside the <body>. The <head> holds metadata and the <title> shows only in the browser tab.' }
    ]
  });

  Curriculum.addLesson({
    id: 'html-elements',
    module: 'Module 1 — Introduction',
    title: 'HTML Elements',
    summary: 'Explore common elements, void elements, and how to choose the right element.',
    keywords: ['element', 'void', 'block', 'inline', 'div', 'span', 'tag'],
    objectives: [
      'Recognize common HTML elements',
      'Understand block vs inline elements',
      'Know what a void (self-closing) element is',
      'Use div and span for grouping'
    ],
    blocks: [
      { t: 'lead', text: 'Elements are the building blocks of every page. Two useful ideas will help you use them correctly: <strong>block</strong> vs <strong>inline</strong>, and <strong>void</strong> elements.' },
      { t: 'h3', text: 'Block vs inline elements' },
      { t: 'p', text: '<strong>Block</strong> elements start on a new line and take the full width available. <strong>Inline</strong> elements sit on the same line as the text around them and only take as much space as they need.' },
      { t: 'code', lang: 'html', caption: 'Block vs inline', code: `<!-- Block elements: new lines, full width -->
<h1>Heading</h1>
<p>Paragraph</p>
<div>Divider block</div>

<!-- Inline elements: flow with text -->
<p>This has <strong>bold</strong> and <span>a span</span> inline.</p>` },
      { t: 'table', head: ['Block', 'Inline'], rows: [
        ['<code>h1</code>-<code>h6</code>, <code>p</code>, <code>div</code>, <code>section</code>, <code>ul</code>, <code>li</code>', '<code>a</code>, <code>strong</code>, <code>em</code>, <code>span</code>, <code>img</code>, <code>button</code>']
      ] },
      { t: 'h3', text: 'Void elements' },
      { t: 'p', text: 'Some elements have <strong>no content and no closing tag</strong>. They are called <strong>void</strong> or self-closing elements. Examples: <code>&lt;img&gt;</code>, <code>&lt;br&gt;</code>, <code>&lt;input&gt;</code>, <code>&lt;hr&gt;</code>.' },
      { t: 'code', lang: 'html', caption: 'Void elements', code: `<img src="photo.jpg" alt="A photo">
<br>
<hr>
<input type="text">` },
      { t: 'h3', text: 'Div and span: the all-purpose containers' },
      { t: 'p', text: '<code>&lt;div&gt;</code> is a block-level container and <code>&lt;span&gt;</code> is an inline container. They add no meaning on their own — you use them to group content and apply styles.' },
      { t: 'demo', title: 'Elements in action', html: `<div style="background:#eef2ff;padding:14px;border-radius:8px">
  <h3>I am inside a div</h3>
  <p>This text has <strong>bold</strong> and <em>italic</em> words.</p>
</div>` },
      { t: 'quiz', q: 'Which of these is a VOID element (no closing tag)?', options: ['<p>', '<strong>', '<img>', '<h1>'], answer: 2,
        explanation: 'The <img> element has no closing tag — it is a void/self-closing element. The others all require closing tags.' }
    ]
  });

  Curriculum.addLesson({
    id: 'html-attributes',
    module: 'Module 1 — Introduction',
    title: 'HTML Attributes',
    summary: 'Add extra information to elements with attributes like id, class, href and src.',
    keywords: ['attribute', 'id', 'class', 'href', 'src', 'value', 'style'],
    objectives: [
      'Understand what attributes are',
      'Use id and class to identify elements',
      'Know common attributes like href, src, alt',
      'Understand boolean attributes'
    ],
    blocks: [
      { t: 'lead', text: 'Attributes give elements extra information. They live inside the opening tag and come as <code>name="value"</code> pairs.' },
      { t: 'code', lang: 'html', caption: 'Attribute syntax', code: `<a href="https://example.com">Visit Example</a>

<img src="dog.jpg" alt="A cute dog">

<p class="intro" id="first">Hello</p>` },
      { t: 'list', items: [
        '<code>href</code> — the destination of a link.',
        '<code>src</code> — the source file for an image or script.',
        '<code>alt</code> — alternative text describing an image.',
        '<code>id</code> — a unique identifier (only ONE per page).',
        '<code>class</code> — a reusable label you can share across many elements.',
        '<code>style</code> — inline CSS (best avoided for most styling).'
      ] },
      { t: 'h3', text: 'id vs class' },
      { t: 'p', text: 'An <code>id</code> is like a national ID number — unique to one element. A <code>class</code> is like a school badge — many students can wear the same badge. You will use this constantly with CSS.' },
      { t: 'h3', text: 'Boolean attributes' },
      { t: 'p', text: 'Some attributes are just a name with no value. They turn a feature on or off. Examples: <code>disabled</code>, <code>checked</code>, <code>required</code>.' },
      { t: 'code', lang: 'html', caption: 'Boolean attributes', code: `<input type="text" required>
<input type="checkbox" checked>
<button disabled>Can't click me</button>` },
      { t: 'callout', type: 'warn', title: 'Common mistakes',
        text: 'Duplicating an <code>id</code>, forgetting quotes around values (<code>href=https://x</code> is wrong), and mixing up <code>id</code> vs <code>class</code> are classic errors.' },
      { t: 'quiz', q: 'Which attribute makes an image appear?', options: ['href', 'alt', 'src', 'link'], answer: 2,
        explanation: 'The <code>src</code> attribute points to the image file. <code>alt</code> provides alternative text, and <code>href</code> is used for links.' }
    ]
  });

  /* ============ MODULE 2 — HTML BASICS ============ */

  Curriculum.addLesson({
    id: 'headings',
    module: 'Module 2 — HTML Basics',
    title: 'Headings',
    summary: 'Use h1 to h6 to structure page headings with correct hierarchy.',
    keywords: ['heading', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hierarchy', 'seo'],
    objectives: [
      'Know the six heading levels',
      'Create a correct heading hierarchy',
      'Understand why headings matter for accessibility and SEO',
      'Avoid common heading mistakes'
    ],
    blocks: [
      { t: 'lead', text: 'Headings are how you structure and title the sections of a page. They help readers and search engines understand your content.' },
      { t: 'code', lang: 'html', caption: 'All six heading levels', code: `<h1>Main Title</h1>
<h2>Section Heading</h2>
<h3>Sub-Section</h3>
<h4>Smaller</h4>
<h5>Even smaller</h5>
<h6>Smallest</h6>` },
      { t: 'h3', text: 'Heading hierarchy' },
      { t: 'p', text: 'Use only <strong>one</strong> <code>&lt;h1&gt;</code> per page — it is the main title. Then go down the levels in order: <code>h1 → h2 → h3</code>. Skipping levels (jumping from <code>h1</code> to <code>h4</code>) confuses screen readers and search engines.' },
      { t: 'demo', title: 'Heading sizes', html: `<h1>h1 — Page title</h1><h2>h2 — Section</h2><h3>h3 — Sub section</h3><h4>h4 — Note</h4>` },
      { t: 'callout', type: 'warn', title: 'Common mistakes',
        text: 'Do <strong>not</strong> pick a heading level because of its size — that is what CSS is for. Use headings for <em>structure</em>, not for making text big. Also avoid using more than one <code>h1</code>.' },
      { t: 'quiz', q: 'How many <h1> tags should a page ideally have?', options: ['As many as you like', 'Exactly two', 'One', 'None'], answer: 2,
        explanation: 'A page should have a single <h1> as its main title. Extra <h1>s confuse both search engines and screen readers.' }
    ]
  });

  Curriculum.addLesson({
    id: 'paragraphs',
    module: 'Module 2 — HTML Basics',
    title: 'Paragraphs & Text Formatting',
    summary: 'Write paragraphs and format text with strong, em, and line breaks.',
    keywords: ['paragraph', 'p', 'strong', 'em', 'br', 'formatting', 'text'],
    objectives: [
      'Create paragraphs with the <p> tag',
      'Format text with strong, em, mark, del',
      'Use br for line breaks and hr for dividers',
      'Understand that HTML collapses whitespace'
    ],
    blocks: [
      { t: 'lead', text: 'Paragraphs hold your main text. Inside them you can format words with inline elements to add emphasis and meaning.' },
      { t: 'code', lang: 'html', caption: 'Paragraphs and formatting', code: `<p>This is the first paragraph.</p>
<p>This is the <strong>important</strong> and
   this is <em>emphasized</em> text.</p>

<p>One line.<br>Next line after a break.</p>` },
      { t: 'table', head: ['Tag', 'Purpose'], rows: [
        ['<code>&lt;p&gt;</code>', 'A paragraph of text'],
        ['<code>&lt;strong&gt;</code>', 'Important text (shown bold)'],
        ['<code>&lt;em&gt;</code>', 'Emphasized text (shown italic)'],
        ['<code>&lt;mark&gt;</code>', 'Highlighted text'],
        ['<code>&lt;del&gt;</code>', 'Deleted text (strikethrough)'],
        ['<code>&lt;br&gt;</code>', 'A line break (void)'],
        ['<code>&lt;hr&gt;</code>', 'A horizontal divider (void)']
      ] },
      { t: 'h3', text: 'Whitespace is collapsed' },
      { t: 'p', text: 'HTML ignores extra spaces, tabs and new lines in your code. Everything collapses into a single space. To control spacing, use CSS or <code>&lt;br&gt;</code>.' },
      { t: 'demo', title: 'Text formatting demo', html: `<p>This is <strong>bold</strong>, <em>italic</em>, <mark>highlighted</mark> and <del>strikethrough</del>.</p><hr><p>After a horizontal rule.</p>` },
      { t: 'callout', type: 'tip', title: 'strong vs b',
        text: 'Prefer <code>&lt;strong&gt;</code> over <code>&lt;b&gt;</code> and <code>&lt;em&gt;</code> over <code>&lt;i&gt;</code>. <code>strong</code> and <code>em</code> carry <em>meaning</em> (semantics), not just visual style.' },
      { t: 'quiz', q: 'Which tag makes text IMPORTANT (bold with meaning)?', options: ['<b>', '<i>', '<strong>', '<small>'], answer: 2,
        explanation: '<strong> adds semantic importance and is shown bold. The <b> tag is presentational only and carries no meaning.' }
    ]
  });

  Curriculum.addLesson({
    id: 'links',
    module: 'Module 2 — HTML Basics',
    title: 'Links',
    summary: 'Create hyperlinks with the <a> tag using href and relative/absolute URLs.',
    keywords: ['link', 'a', 'href', 'hyperlink', 'anchor', 'relative', 'absolute', 'target'],
    objectives: [
      'Create links with the <a> tag',
      'Understand relative vs absolute URLs',
      'Open links in new tabs with target',
      'Create anchor links within a page'
    ],
    blocks: [
      { t: 'lead', text: 'Links are what make the web a "web". Without them pages would be isolated. A link is made with the anchor tag <code>&lt;a&gt;</code> and the <code>href</code> attribute.' },
      { t: 'code', lang: 'html', caption: 'Basic links', code: `<a href="https://example.com">Visit Example</a>
<a href="/about.html">About page (same site)</a>
<a href="about.html">About (relative path)</a>
<a href="https://example.com" target="_blank">Open in new tab</a>` },
      { t: 'h3', text: 'Absolute vs relative URLs' },
      { t: 'list', items: [
        '<strong>Absolute</strong> — the full address including <code>https://</code>, e.g. <code>https://google.com</code>. Use for other websites.',
        '<strong>Relative</strong> — a path from the current file, e.g. <code>about.html</code> or <code>../css/style.css</code>. Use for pages and files on your own site.'
      ] },
      { t: 'h3', text: 'Anchor links within a page' },
      { t: 'p', text: 'Point a link at an element\'s <code>id</code> to jump to it. The link starts with a hash <code>#</code>.' },
      { t: 'code', lang: 'html', caption: 'Jump to a section', code: `<a href="#contact">Jump to contact</a>

<!-- further down the page -->
<section id="contact">
  <h2>Contact Us</h2>
</section>` },
      { t: 'callout', type: 'warn', title: 'Common mistakes',
        text: 'Forgetting <code>https://</code> in external links, using <code>target="_blank"</code> everywhere, and linking to <code>href="#"</code> as a placeholder are common issues.' },
      { t: 'quiz', q: 'To open a link in a NEW browser tab you add:', options: ['target="_self"', 'target="_blank"', 'rel="new"', 'open="tab"'], answer: 1,
        explanation: '<code>target="_blank"</code> opens the link in a new tab. _self (the default) opens it in the same tab.' }
    ]
  });

  Curriculum.addLesson({
    id: 'images',
    module: 'Module 2 — HTML Basics',
    title: 'Images',
    summary: 'Add images with <img>, using src, alt and width/height attributes.',
    keywords: ['image', 'img', 'src', 'alt', 'width', 'height', 'picture'],
    objectives: [
      'Add images with the <img> tag',
      'Write meaningful alt text',
      'Control image size with width and height',
      'Understand image file formats'
    ],
    blocks: [
      { t: 'lead', text: 'Images make pages engaging. The <code>&lt;img&gt;</code> element is a void element — it has no closing tag.' },
      { t: 'code', lang: 'html', caption: 'Adding an image', code: `<img src="dog.jpg" alt="A happy dog playing">
<img src="logo.png" alt="Company logo" width="120" height="60">` },
      { t: 'h3', text: 'Alt text matters' },
      { t: 'p', text: 'The <code>alt</code> attribute describes the image. Screen readers read it aloud for visually-impaired users, and it shows if the image fails to load. Always write a short, descriptive <code>alt</code>.' },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'An image without <code>alt</code> is an accessibility problem. Use <code>alt=""</code> (empty) for decorative images that add no information.' },
      { t: 'h3', text: 'Common image formats' },
      { t: 'table', head: ['Format', 'Best for'], rows: [
        ['<code>JPG</code>', 'Photos and images with many colours'],
        ['<code>PNG</code>', 'Images needing transparency or crisp lines'],
        ['<code>GIF</code>', 'Simple animations'],
        ['<code>SVG</code>', 'Icons and logos (scales to any size)'],
        ['<code>WebP</code>', 'Modern format — great quality, small size']
      ] },
      { t: 'demo', title: 'Image demo', html: `<div style="font-family:sans-serif">
<img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='100'%3E%3Crect width='160' height='100' rx='10' fill='%232f5af0'/%3E%3Ctext x='80' y='55' font-size='16' fill='white' text-anchor='middle' font-family='sans-serif'%3EExample image%3C/text%3E%3C/svg%3E" alt="Placeholder example image" width="160">
<p>This image is defined with an <code>alt</code> attribute.</p>
</div>` },
      { t: 'quiz', q: 'Which attribute provides a text description of an image for screen readers?', options: ['src', 'alt', 'title', 'width'], answer: 1,
        explanation: 'The <code>alt</code> attribute gives alternative text describing the image. <code>src</code> just points to the file.' }
    ]
  });

  Curriculum.addLesson({
    id: 'lists',
    module: 'Module 2 — HTML Basics',
    title: 'Lists',
    summary: 'Create ordered, unordered and description lists.',
    keywords: ['list', 'ul', 'ol', 'li', 'dl', 'dt', 'dd', 'nested'],
    objectives: [
      'Create unordered lists with <ul>',
      'Create ordered lists with <ol>',
      'Nest lists inside lists',
      'Use description lists for definitions'
    ],
    blocks: [
      { t: 'lead', text: 'Lists organize related items. There are three types: unordered (bullets), ordered (numbers), and description lists.' },
      { t: 'code', lang: 'html', caption: 'Unordered and ordered lists', code: `<!-- Unordered list: bullets -->
<ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>JavaScript</li>
</ul>

<!-- Ordered list: numbers -->
<ol>
  <li>Open your editor</li>
  <li>Write the code</li>
  <li>Save the file</li>
</ol>` },
      { t: 'p', text: 'Only <code>&lt;li&gt;</code> (list item) elements should be direct children of <code>&lt;ul&gt;</code> or <code>&lt;ol&gt;</code>.' },
      { t: 'h3', text: 'Nested lists' },
      { t: 'p', text: 'You can put a list inside a list item to create sub-items (like an outline).' },
      { t: 'code', lang: 'html', caption: 'Nested list', code: `<ul>
  <li>Fruits
    <ul>
      <li>Apple</li>
      <li>Mango</li>
    </ul>
  </li>
  <li>Vegetables</li>
</ul>` },
      { t: 'h3', text: 'Description lists' },
      { t: 'p', text: 'A description list pairs terms with descriptions, great for glossaries or definitions.' },
      { t: 'code', lang: 'html', caption: 'Description list', code: `<dl>
  <dt>HTML</dt>
  <dd>Structures web content</dd>
  <dt>CSS</dt>
  <dd>Styles web content</dd>
</dl>` },
      { t: 'demo', title: 'List demo', html: `<ul><li>One</li><li>Two<ul><li>Two point one</li></ul></li></ul><ol><li>First step</li><li>Second step</li></ol>` },
      { t: 'quiz', q: 'Which tag creates a bulleted (unordered) list?', options: ['<ol>', '<ul>', '<li>', '<dl>'], answer: 1,
        explanation: '<ul> creates an unordered (bulleted) list. <ol> makes an ordered list and <li> is the list item used inside both.' }
    ]
  });

  /* ============ MODULE 3 — HTML COMPONENTS ============ */

  Curriculum.addLesson({
    id: 'tables',
    module: 'Module 3 — HTML Components',
    title: 'Tables',
    summary: 'Build data tables with table, thead, tbody, tr, th and td.',
    keywords: ['table', 'tr', 'th', 'td', 'thead', 'tbody', 'caption', 'rowspan', 'colspan'],
    objectives: [
      'Create a basic HTML table',
      'Structure tables with thead, tbody and tfoot',
      'Use th for headers and td for data',
      'Merge cells with colspan and rowspan'
    ],
    blocks: [
      { t: 'lead', text: 'Tables display data in rows and columns — perfect for schedules, scores and comparisons.' },
      { t: 'code', lang: 'html', caption: 'A simple table', code: `<table>
  <tr>
    <th>Name</th>
    <th>Score</th>
  </tr>
  <tr>
    <td>Amina</td>
    <td>85</td>
  </tr>
  <tr>
    <td>John</td>
    <td>92</td>
  </tr>
</table>` },
      { t: 'h3', text: 'Table structure tags' },
      { t: 'list', items: [
        '<code>&lt;table&gt;</code> — the container.',
        '<code>&lt;tr&gt;</code> — a table row.',
        '<code>&lt;th&gt;</code> — a header cell (bold by default).',
        '<code>&lt;td&gt;</code> — a data cell.',
        '<code>&lt;thead&gt;</code> / <code>&lt;tbody&gt;</code> — group header and body rows.',
        '<code>&lt;caption&gt;</code> — the table\'s title.'
      ] },
      { t: 'h3', text: 'Merging cells' },
      { t: 'code', lang: 'html', caption: 'colspan and rowspan', code: `<table>
  <tr>
    <th>Subject</th>
    <th>Score</th>
  </tr>
  <tr>
    <td>Maths</td>
    <td>80</td>
  </tr>
  <tr>
    <td colspan="2">Total: 80</td>
  </tr>
</table>` },
      { t: 'p', text: '<code>colspan</code> merges cells horizontally across columns; <code>rowspan</code> merges them vertically down rows.' },
      { t: 'demo', title: 'Table demo', html: `<table style="width:100%;border-collapse:collapse;font-family:sans-serif;font-size:14px">
<tr style="background:#eef2ff"><th>Subject</th><th>Score</th><th>Grade</th></tr>
<tr><td>Maths</td><td>85</td><td>A</td></tr>
<tr><td>English</td><td>78</td><td>B</td></tr>
<tr><td>Science</td><td>92</td><td>A</td></tr>
</table>` },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'Do not use tables for page layout — that was an old practice and it is bad for responsiveness. Use tables only for <em>tabular data</em>, and use CSS Grid/Flexbox for layout.' },
      { t: 'quiz', q: 'Which tag defines a header cell in a table?', options: ['<td>', '<th>', '<tr>', '<caption>'], answer: 1,
        explanation: '<th> defines a header cell. <td> is a regular data cell and <tr> is a table row.' }
    ]
  });

  Curriculum.addLesson({
    id: 'forms',
    module: 'Module 3 — HTML Components',
    title: 'Forms',
    summary: 'Create forms with the <form> element, labels, and action/method attributes.',
    keywords: ['form', 'label', 'action', 'method', 'input', 'submit', 'fieldset'],
    objectives: [
      'Build a form with the <form> element',
      'Use labels with inputs',
      'Understand the action and method attributes',
      'Group related fields with fieldset'
    ],
    blocks: [
      { t: 'lead', text: 'Forms let users send information to you — names, emails, logins, searches. A form is a container for inputs.' },
      { t: 'code', lang: 'html', caption: 'A basic form', code: `<form action="/submit" method="post">
  <label for="name">Your name</label>
  <input type="text" id="name" name="name">

  <button type="submit">Send</button>
</form>` },
      { t: 'h3', text: 'Key attributes' },
      { t: 'list', items: [
        '<code>action</code> — the URL where the data is sent.',
        '<code>method</code> — how data is sent: <code>get</code> (in URL) or <code>post</code> (in the request body).',
        '<code>name</code> — the key that identifies each field\'s value.',
        '<code>for</code> on the label + <code>id</code> on the input — this connects them.'
      ] },
      { t: 'callout', type: 'tip', title: 'Why labels matter',
        text: 'Every input should have a <code>&lt;label&gt;</code>. Clicking the label focuses the input, and screen readers announce the label. Never leave inputs unlabelled.' },
      { t: 'h3', text: 'Fieldset and legend' },
      { t: 'code', lang: 'html', caption: 'Grouping fields', code: `<fieldset>
  <legend>Contact details</legend>
  <label for="email">Email</label>
  <input type="email" id="email" name="email">
</fieldset>` },
      { t: 'demo', title: 'Form demo', html: `<form style="font-family:sans-serif;max-width:300px">
<label for="nm">Name</label><br>
<input type="text" id="nm" name="name" style="width:100%;padding:8px;margin:4px 0 10px;border:1px solid #ccc;border-radius:6px">
<label for="ml">Email</label><br>
<input type="email" id="ml" name="email" style="width:100%;padding:8px;margin:4px 0 10px;border:1px solid #ccc;border-radius:6px">
<button type="submit" style="background:#2f5af0;color:#fff;border:none;padding:10px 16px;border-radius:6px">Submit</button>
</form>` },
      { t: 'quiz', q: 'Which attribute connects a <label> to an input?', options: ['name', 'for', 'id', 'value'], answer: 1,
        explanation: 'The label\'s <code>for</code> attribute must match the input\'s <code>id</code> to connect them.' }
    ]
  });

  Curriculum.addLesson({
    id: 'inputs',
    module: 'Module 3 — HTML Components',
    title: 'Inputs & Form Controls',
    summary: 'Master input types: text, email, password, checkbox, radio, select, textarea.',
    keywords: ['input', 'type', 'text', 'email', 'password', 'checkbox', 'radio', 'select', 'textarea', 'placeholder', 'required'],
    objectives: [
      'Use common input types',
      'Understand checkbox and radio',
      'Create dropdowns with select and option',
      'Add textarea for longer text',
      'Use validation attributes'
    ],
    blocks: [
      { t: 'lead', text: 'The <code>&lt;input&gt;</code> element is the workhorse of forms. Its <code>type</code> attribute changes how it looks and behaves.' },
      { t: 'code', lang: 'html', caption: 'Input types', code: `<input type="text" placeholder="Your name">
<input type="email" placeholder="you@email.com">
<input type="password" placeholder="Secret">
<input type="number" min="1" max="10">
<input type="date">
<input type="color">
<input type="checkbox"> Remember me
<input type="radio" name="plan" value="basic"> Basic
<input type="radio" name="plan" value="pro"> Pro
<select>
  <option>Choose one</option>
  <option>HTML</option>
  <option>CSS</option>
</select>
<textarea rows="3" placeholder="Long message"></textarea>` },
      { t: 'h3', text: 'Validation attributes' },
      { t: 'list', items: [
        '<code>required</code> — the field must be filled.',
        '<code>placeholder</code> — grey hint text inside the field.',
        '<code>min</code>/<code>max</code> — limits for numbers.',
        '<code>pattern</code> — a regular expression the value must match.'
      ] },
      { t: 'callout', type: 'tip', title: 'Radio groups',
        text: 'Radio buttons with the same <code>name</code> belong to the same group — only one can be selected at a time. Checkboxes are independent — you can tick many.' },
      { t: 'demo', title: 'Inputs demo', html: `<div style="font-family:sans-serif;display:grid;gap:10px;max-width:320px">
<input placeholder="Text input" style="padding:8px;border:1px solid #ccc;border-radius:6px">
<input type="email" placeholder="Email" style="padding:8px;border:1px solid #ccc;border-radius:6px">
<label><input type="checkbox"> I agree</label>
<label><input type="radio" name="r"> Option A</label>
<select style="padding:8px;border:1px solid #ccc;border-radius:6px"><option>Red</option><option>Green</option></select>
</div>` },
      { t: 'quiz', q: 'Radio buttons with the same name let you:', options: ['Select many options', 'Select exactly one option', 'Type text', 'Upload files'], answer: 1,
        explanation: 'Radio buttons sharing the same <code>name</code> form a group where only one option can be selected.' }
    ]
  });

  Curriculum.addLesson({
    id: 'buttons',
    module: 'Module 3 — HTML Components',
    title: 'Buttons',
    summary: 'Create and style buttons, and understand the different button types.',
    keywords: ['button', 'submit', 'reset', 'button type', 'click'],
    objectives: [
      'Create buttons with the <button> element',
      'Understand button types: submit, reset, button',
      'Know the difference between <button> and <a>',
      'Add a disabled state'
    ],
    blocks: [
      { t: 'lead', text: 'Buttons let users trigger actions. The <code>&lt;button&gt;</code> element is the correct, semantic choice for actions.' },
      { t: 'code', lang: 'html', caption: 'Button types', code: `<button type="submit">Submit form</button>
<button type="reset">Reset form</button>
<button type="button" onclick="alert('Hi')">Do something</button>
<button disabled>Disabled</button>` },
      { t: 'h3', text: 'The three types' },
      { t: 'list', items: [
        '<code>submit</code> (default) — submits the form it lives in.',
        '<code>reset</code> — clears all form fields.',
        '<code>button</code> — does nothing by itself; you add behaviour with JavaScript.'
      ] },
      { t: 'callout', type: 'warn', title: 'button vs a',
        text: 'Use <code>&lt;button&gt;</code> for actions (submit, open menu, delete) and <code>&lt;a&gt;</code> for navigation to another page. Using the wrong one confuses assistive technology and can break keyboard navigation.' },
      { t: 'demo', title: 'Buttons demo', html: `<div style="font-family:sans-serif;display:flex;gap:10px;flex-wrap:wrap">
<button style="background:#2f5af0;color:#fff;border:none;padding:10px 18px;border-radius:8px">Primary</button>
<button style="background:#00b386;color:#fff;border:none;padding:10px 18px;border-radius:8px">Success</button>
<button style="background:#fff;border:1px solid #ccc;padding:10px 18px;border-radius:8px">Outline</button>
<button disabled style="padding:10px 18px;border-radius:8px">Disabled</button>
</div>` },
      { t: 'quiz', q: 'Which button type submits the surrounding form?', options: ['type="button"', 'type="submit"', 'type="reset"', 'type="link"'], answer: 1,
        explanation: '<code>type="submit"</code> submits the form. type="button" does nothing by default, and type="reset" clears the form.' }
    ]
  });

  Curriculum.addLesson({
    id: 'multimedia',
    module: 'Module 3 — HTML Components',
    title: 'Multimedia',
    summary: 'Embed audio, video and iframes in your pages.',
    keywords: ['video', 'audio', 'iframe', 'embed', 'controls', 'youtube', 'media'],
    objectives: [
      'Embed video with the <video> tag',
      'Embed audio with the <audio> tag',
      'Embed external content with iframe',
      'Understand the controls attribute'
    ],
    blocks: [
      { t: 'lead', text: 'Websites often need more than text and images. Video, audio and embedded content make pages rich and engaging.' },
      { t: 'code', lang: 'html', caption: 'Video and audio', code: `<video controls width="400">
  <source src="movie.mp4" type="video/mp4">
  Your browser does not support video.
</video>

<audio controls>
  <source src="song.mp3" type="audio/mpeg">
  Your browser does not support audio.
</audio>` },
      { t: 'p', text: 'The <code>controls</code> attribute shows play, pause and volume controls. Without it the media plays silently with no controls.' },
      { t: 'h3', text: 'Other media attributes' },
      { t: 'list', items: [
        '<code>autoplay</code> — plays automatically (use with care).',
        '<code>loop</code> — repeats forever.',
        '<code>muted</code> — starts muted.',
        '<code>poster</code> — a preview image for video.'
      ] },
      { t: 'h3', text: 'Iframes' },
      { t: 'p', text: 'The <code>&lt;iframe&gt;</code> embeds another document — like a YouTube video or a map.' },
      { t: 'code', lang: 'html', caption: 'Embedding a YouTube video', code: `<iframe width="560" height="315"
  src="https://www.youtube.com/embed/VIDEO_ID"
  title="A YouTube video" allowfullscreen>
</iframe>` },
      { t: 'demo', title: 'Embedded iframe demo', html: `<div style="font-family:sans-serif;border:1px solid #ddd;border-radius:8px;padding:14px;max-width:360px">
<p><strong>An embedded frame:</strong></p>
<iframe src="data:text/html,<p style='font-family:sans-serif;padding:10px'>This content comes from another document.</p>" style="width:100%;height:80px;border:1px solid #ccc;border-radius:6px"></iframe>
</div>` },
      { t: 'callout', type: 'warn', title: 'Performance',
        text: 'Videos and iframes are heavy. Use <code>controls</code> and avoid <code>autoplay</code> to save bandwidth and respect your users.' },
      { t: 'quiz', q: 'Which attribute shows the play/pause controls on a video?', options: ['controls', 'play', 'buttons', 'show'], answer: 0,
        explanation: 'The <code>controls</code> attribute displays the play, pause, volume and progress controls on media elements.' }
    ]
  });

  /* ============ MODULE 4 — SEMANTIC HTML ============ */

  Curriculum.addLesson({
    id: 'semantic-header-footer',
    module: 'Module 4 — Semantic HTML',
    title: 'Header & Footer',
    summary: 'Use <header> for the top of a page or section and <footer> for its bottom.',
    keywords: ['header', 'footer', 'semantic', 'page top', 'page bottom'],
    objectives: [
      'Understand what semantic HTML means',
      'Use <header> appropriately',
      'Use <footer> appropriately',
      'Know when header/footer apply to sections too'
    ],
    blocks: [
      { t: 'lead', text: 'Semantic HTML means using elements whose <em>names describe their meaning</em>, instead of generic <code>&lt;div&gt;</code> everywhere. It helps accessibility, SEO and code clarity.' },
      { t: 'h3', text: 'The <header> element' },
      { t: 'p', text: '<code>&lt;header&gt;</code> holds introductory content — typically a logo and site navigation at the top of a page, or the title of a section.' },
      { t: 'code', lang: 'html', caption: 'A page header', code: `<header>
  <h1>My Website</h1>
  <nav>
    <a href="/">Home</a>
    <a href="/about">About</a>
  </nav>
</header>` },
      { t: 'h3', text: 'The <footer> element' },
      { t: 'p', text: '<code>&lt;footer&gt;</code> holds closing information — copyright, contact details, links, social media — at the bottom of a page or section.' },
      { t: 'code', lang: 'html', caption: 'A page footer', code: `<footer>
  <p>&copy; 2026 My Website</p>
  <a href="mailto:hello@site.com">Contact us</a>
</footer>` },
      { t: 'demo', title: 'Header & footer demo', html: `<div style="font-family:sans-serif">
<header style="background:#2f5af0;color:#fff;padding:16px;border-radius:8px 8px 0 0"><h3 style="margin:0">Site Header</h3></header>
<main style="padding:20px;background:#fff;border:1px solid #ddd">Main content goes here.</main>
<footer style="background:#eef2f8;padding:14px;border-radius:0 0 8px 8px;color:#555">Footer: copyright &amp; links</footer>
</div>` },
      { t: 'callout', type: 'tip', title: 'Not just for pages',
        text: 'A <code>&lt;header&gt;</code> and <code>&lt;footer&gt;</code> can also appear inside a <code>&lt;section&gt;</code> or <code>&lt;article&gt;</code> to mark that block\'s own top and bottom.' },
      { t: 'quiz', q: 'Which element is best for the top of a page holding the logo and navigation?', options: ['<div>', '<header>', '<span>', '<section>'], answer: 1,
        explanation: '<header> is the semantic element for the introductory content at the top of a page or section — ideal for logos and nav.' }
    ]
  });

  Curriculum.addLesson({
    id: 'semantic-nav',
    module: 'Module 4 — Semantic HTML',
    title: 'Navigation (<nav>)',
    summary: 'Build a semantic navigation menu with <nav> and links.',
    keywords: ['nav', 'navigation', 'menu', 'navbar'],
    objectives: [
      'Use <nav> for navigation links',
      'Build a simple nav bar with links',
      'Understand nav landmark for accessibility',
      'Place nav inside header appropriately'
    ],
    blocks: [
      { t: 'lead', text: 'The <code>&lt;nav&gt;</code> element wraps a set of navigation links. It defines a landmark that screen readers and assistive tech can jump to.' },
      { t: 'code', lang: 'html', caption: 'A simple nav', code: `<nav>
  <ul>
    <li><a href="/">Home</a></li>
    <li><a href="/about">About</a></li>
    <li><a href="/contact">Contact</a></li>
  </ul>
</nav>` },
      { t: 'p', text: 'Using a list inside <code>nav</code> is a common and accessible pattern. The <code>nav</code> element itself is for <em>major</em> navigation blocks, not every link on the page.' },
      { t: 'demo', title: 'Nav bar demo', html: `<nav style="font-family:sans-serif;background:#1c2433;padding:12px 18px;border-radius:8px">
<ul style="list-style:none;margin:0;padding:0;display:flex;gap:20px">
<li><a href="#" style="color:#fff;text-decoration:none">Home</a></li>
<li><a href="#" style="color:#cdd6e8;text-decoration:none">About</a></li>
<li><a href="#" style="color:#cdd6e8;text-decoration:none">Contact</a></li>
</ul>
</nav>` },
      { t: 'callout', type: 'good', title: 'Accessibility win',
        text: 'A <code>&lt;nav&gt;</code> landmark lets keyboard and screen-reader users jump straight to navigation. That is a big usability boost for everyone.' },
      { t: 'quiz', q: 'What is the semantic element for a set of navigation links?', options: ['<menu>', '<nav>', '<links>', '<header>'], answer: 1,
        explanation: '<nav> marks a navigation landmark. <menu> is rarely used for this, and header is for intro content.' }
    ]
  });

  Curriculum.addLesson({
    id: 'semantic-main-section-article',
    module: 'Module 4 — Semantic HTML',
    title: 'Main, Section & Article',
    summary: 'Structure page content with main, section and article.',
    keywords: ['main', 'section', 'article', 'semantic', 'content'],
    objectives: [
      'Use <main> for the main content',
      'Group content with <section>',
      'Mark standalone content with <article>',
      'Understand when to choose each'
    ],
    blocks: [
      { t: 'lead', text: 'Three elements structure the bulk of your content: <code>main</code>, <code>section</code> and <code>article</code>.' },
      { t: 'h3', text: '<main>' },
      { t: 'p', text: '<code>&lt;main&gt;</code> holds the unique, primary content of the page. There should be only one per page, and it should not include nav, headers or footers that repeat across pages.' },
      { t: 'h3', text: '<section>' },
      { t: 'p', text: '<code>&lt;section&gt;</code> groups related content, usually with a heading. Think of chapters in a book.' },
      { t: 'h3', text: '<article>' },
      { t: 'p', text: '<code>&lt;article&gt;</code> marks content that could stand on its own — a blog post, a news story, a product review. Articles can contain sections, and sections can contain articles.' },
      { t: 'code', lang: 'html', caption: 'Putting it together', code: `<main>
  <section>
    <h2>Latest News</h2>
    <article>
      <h3>School wins award</h3>
      <p>Our students took first place...</p>
    </article>
    <article>
      <h3>New library opens</h3>
      <p>The new library is now open...</p>
    </article>
  </section>
</main>` },
      { t: 'demo', title: 'Semantic structure demo', html: `<div style="font-family:sans-serif;border:2px solid #2f5af0;border-radius:8px;padding:12px;background:#f7f9ff">
<strong style="color:#2f5af0">&lt;main&gt;</strong>
<div style="border:2px solid #00b386;border-radius:8px;padding:10px;margin-top:8px;background:#f2fffa">
<strong style="color:#008f6b">&lt;section&gt;</strong>
<div style="border:2px dashed #999;border-radius:8px;padding:8px;margin-top:8px"><strong>&lt;article&gt;</strong> content</div>
</div>
</div>` },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'Having more than one <code>&lt;main&gt;</code>, or putting repeated site-wide content (logo, footer) inside <code>&lt;main&gt;</code>, are common semantic errors.' },
      { t: 'quiz', q: 'Which element is best for a self-contained blog post?', options: ['<section>', '<article>', '<main>', '<div>'], answer: 1,
        explanation: '<article> is for content that can stand independently, like a blog post. A <section> just groups related content.' }
    ]
  });

  Curriculum.addLesson({
    id: 'semantic-aside',
    module: 'Module 4 — Semantic HTML',
    title: 'Aside & Other Semantic Tags',
    summary: 'Use <aside> for side content and meet figure, time, address and mark.',
    keywords: ['aside', 'sidebar', 'figure', 'figcaption', 'time', 'address', 'mark', 'semantic'],
    objectives: [
      'Use <aside> for complementary side content',
      'Use figure and figcaption for images',
      'Use time, address and mark where appropriate',
      'Choose semantic elements over div'
    ],
    blocks: [
      { t: 'lead', text: '<code>&lt;aside&gt;</code> holds content related to but separate from the main content — sidebars, related links, pull quotes, ads.' },
      { t: 'code', lang: 'html', caption: 'Aside in action', code: `<main>
  <p>The main article goes here.</p>
</main>
<aside>
  <h3>Related articles</h3>
  <ul>
    <li><a href="#">Beginner HTML</a></li>
    <li><a href="#">CSS Flexbox</a></li>
  </ul>
</aside>` },
      { t: 'h3', text: 'More useful semantic elements' },
      { t: 'table', head: ['Element', 'Use for'], rows: [
        ['<code>&lt;figure&gt;</code> + <code>&lt;figcaption&gt;</code>', 'An image or diagram with a caption'],
        ['<code>&lt;time&gt;</code>', 'Dates and times'],
        ['<code>&lt;address&gt;</code>', 'Contact information'],
        ['<code>&lt;mark&gt;</code>', 'Highlighted / relevant text']
      ] },
      { t: 'code', lang: 'html', caption: 'Figure with caption', code: `<figure>
  <img src="chart.png" alt="Sales chart">
  <figcaption>Quarterly sales, 2026</figcaption>
</figure>
<p>Published <time datetime="2026-08-05">Aug 5</time>.</p>` },
      { t: 'demo', title: 'Aside layout demo', html: `<div style="font-family:sans-serif;display:grid;grid-template-columns:2fr 1fr;gap:12px">
<div style="border:2px solid #2f5af0;border-radius:8px;padding:12px"><strong style="color:#2f5af0">&lt;main&gt;</strong><p style="margin:6px 0 0">Main content.</p></div>
<div style="border:2px solid #00b386;border-radius:8px;padding:12px"><strong style="color:#008f6b">&lt;aside&gt;</strong><p style="margin:6px 0 0">Related links.</p></div>
</div>` },
      { t: 'callout', type: 'good', title: 'Why semantics matter',
        text: 'Semantic tags give meaning to content, improve accessibility, boost SEO, and make your code much easier for other developers (and your future self) to read.' },
      { t: 'quiz', q: 'Which element is best for a sidebar with related links?', options: ['<main>', '<section>', '<aside>', '<nav>'], answer: 2,
        explanation: '<aside> is for complementary side content. <nav> is only for navigation links, not arbitrary side content.' }
    ]
  });

})();
