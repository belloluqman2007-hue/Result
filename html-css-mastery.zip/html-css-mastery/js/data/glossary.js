/* =========================================================
   HTML & CSS MASTERY — glossary.js
   Searchable glossary of terms.
   ========================================================= */

const GLOSSARY = [
  { term: 'HTML', cat: 'Languages', def: 'HyperText Markup Language. The standard language used to structure the content of web pages.' },
  { term: 'CSS', cat: 'Languages', def: 'Cascading Style Sheets. The language used to style and lay out web pages — colours, fonts, spacing and more.' },
  { term: 'JavaScript', cat: 'Languages', def: 'A programming language that adds interactivity and behaviour to web pages, like menus, quizzes and live updates.' },
  { term: 'Element', cat: 'HTML', def: 'An opening tag, its content, and its closing tag together. For example, &lt;p&gt;Hello&lt;/p&gt; is a paragraph element.' },
  { term: 'Tag', cat: 'HTML', def: 'The markup that defines an element, written in angle brackets like &lt;p&gt; or &lt;/p&gt;. Most elements have an opening and closing tag.' },
  { term: 'Attribute', cat: 'HTML', def: 'Extra information written inside the opening tag, as name="value" pairs, e.g. href, src, alt, id, class.' },
  { term: 'Void element', cat: 'HTML', def: 'An element with no content and no closing tag, such as &lt;img&gt;, &lt;br&gt; and &lt;input&gt;.' },
  { term: 'Block element', cat: 'HTML', def: 'An element that starts on a new line and takes the full width available, like &lt;p&gt;, &lt;div&gt; and &lt;h1&gt;.' },
  { term: 'Inline element', cat: 'HTML', def: 'An element that sits within a line of text and only takes the width it needs, like &lt;a&gt;, &lt;strong&gt; and &lt;span&gt;.' },
  { term: 'Selector', cat: 'CSS', def: 'The part of a CSS rule that chooses which element(s) to style, e.g. p, .class, #id.' },
  { term: 'Property', cat: 'CSS', def: 'The aspect of an element you style, such as color, font-size, margin or display.' },
  { term: 'Value', cat: 'CSS', def: 'The setting assigned to a property, such as blue, 16px or flex.' },
  { term: 'Declaration', cat: 'CSS', def: 'A single property: value pair inside a CSS rule, ending with a semicolon.' },
  { term: 'Rule', cat: 'CSS', def: 'A selector with its declarations in braces, e.g. h1 { color: blue; }.' },
  { term: 'Class', cat: 'CSS', def: 'A reusable label applied to elements via class="...", targeted in CSS with a dot (.classname).' },
  { term: 'ID', cat: 'CSS', def: 'A unique identifier for one element via id="...", targeted in CSS with a hash (#idname).' },
  { term: 'DOM', cat: 'Core', def: 'Document Object Model. The browser\u2019s in-memory model of the page that JavaScript reads and changes.' },
  { term: 'Browser', cat: 'Core', def: 'Software like Chrome, Firefox, Edge or Safari that downloads web files and renders them into a usable page.' },
  { term: 'Server', cat: 'Core', def: 'A computer that stores websites and sends their files to browsers when requested.' },
  { term: 'Frontend', cat: 'Core', def: 'The part of a website users see and interact with, built with HTML, CSS and JavaScript.' },
  { term: 'Backend', cat: 'Core', def: 'The server-side part that stores data and handles logic, using languages like Node.js, Python or PHP.' },
  { term: 'URL', cat: 'Core', def: 'Uniform Resource Locator. A web address, like https://example.com/page.' },
  { term: 'Responsive Design', cat: 'Concepts', def: 'A design approach that makes a website adapt its layout to any screen size, from phones to desktops.' },
  { term: 'Media Query', cat: 'Concepts', def: 'A CSS feature that applies styles conditionally based on screen size or other device features, e.g. @media (max-width: 600px).' },
  { term: 'Breakpoint', cat: 'Concepts', def: 'A screen width where the layout changes to adapt, such as 768px for tablets.' },
  { term: 'Flexbox', cat: 'Concepts', def: 'A one-dimensional CSS layout model for arranging items in a row or column with alignment and spacing.' },
  { term: 'Grid', cat: 'Concepts', def: 'A two-dimensional CSS layout system that arranges items in rows and columns simultaneously.' },
  { term: 'Box Model', cat: 'Concepts', def: 'The model describing every element as a box of content, padding, border and margin.' },
  { term: 'Padding', cat: 'Concepts', def: 'The space inside an element between its content and its border.' },
  { term: 'Margin', cat: 'Concepts', def: 'The space outside an element\u2019s border, separating it from neighbouring elements.' },
  { term: 'Border', cat: 'Concepts', def: 'The line drawn around an element\u2019s padding, set with width, style and colour.' },
  { term: 'Specificity', cat: 'Concepts', def: 'The scoring system CSS uses to decide which rule wins when several target the same element.' },
  { term: 'Cascade', cat: 'Concepts', def: 'The process by which the browser combines and resolves all CSS rules to determine the final style.' },
  { term: 'Inheritance', cat: 'Concepts', def: 'When child elements take property values (like font or colour) from their parent automatically.' },
  { term: 'Pseudo-class', cat: 'Concepts', def: 'A selector that targets a state, like :hover (mouse over) or :focus (keyboard focus).' },
  { term: 'Keyframes', cat: 'Concepts', def: 'The @keyframes rule defines the stages of a CSS animation using from/to or percentage steps.' },
  { term: 'Transition', cat: 'Concepts', def: 'A CSS feature that smoothly animates property changes over a set duration.' },
  { term: 'Gradient', cat: 'Concepts', def: 'A smooth blend between two or more colours, created with linear-gradient or radial-gradient.' },
  { term: 'Semantic HTML', cat: 'Concepts', def: 'Using meaningful elements (like header, nav, main) whose names describe their purpose, instead of generic divs.' },
  { term: 'Accessibility', cat: 'Concepts', def: 'Designing so that people of all abilities can use a website, including screen readers and keyboard-only users.' },
  { term: 'Landmark', cat: 'Concepts', def: 'A semantic region of a page (like nav or main) that assistive technology users can jump to.' },
  { term: 'SEO', cat: 'Concepts', def: 'Search Engine Optimization — practices that help a site rank well in search engines, such as using semantic HTML and one h1.' },
  { term: 'Viewport', cat: 'Concepts', def: 'The visible area of a web page in the browser. Responsive design adapts to the viewport size.' },
  { term: 'Alt text', cat: 'Accessibility', def: 'The alt attribute describing an image, read by screen readers and shown if the image fails to load.' },
  { term: 'Debugging', cat: 'Concepts', def: 'The process of finding and fixing errors in code, often using the browser\u2019s developer tools.' },
  { term: 'DevTools', cat: 'Concepts', def: 'Developer tools built into browsers that let you inspect HTML, CSS, network activity and console errors.' },
  { term: 'Boolean attribute', cat: 'HTML', def: 'An attribute that is just a name with no value, turning a feature on or off, like disabled or required.' },
  { term: 'GitHub', cat: 'Core', def: 'A platform for hosting and sharing code using the Git version-control system.' },
  { term: 'Open-source', cat: 'Core', def: 'Software whose source code is freely available for anyone to view, modify and share.' }
];

const Glossary = {
  getAll() { return GLOSSARY; },
  search(q) {
    const query = q.toLowerCase().trim();
    if (!query) return GLOSSARY;
    return GLOSSARY.filter(t => (t.term + ' ' + t.def + ' ' + t.cat).toLowerCase().includes(query));
  },
  searchForGlobal(q) {
    const query = q.toLowerCase().trim();
    if (!query) return [];
    return GLOSSARY.filter(t => (t.term + ' ' + t.def).toLowerCase().includes(query))
      .map(t => ({ type: 'Glossary', title: t.term, snippet: t.def.replace(/<[^>]+>/g, ''), url: 'glossary.html?q=' + encodeURIComponent(t.term) }));
  }
};
