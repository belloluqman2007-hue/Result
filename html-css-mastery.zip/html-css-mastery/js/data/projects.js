/* =========================================================
   HTML & CSS MASTERY — projects.js
   Progressive projects (1-9) plus the final capstone.
   ========================================================= */

const PROJECTS = [
  { id: 'p1', num: 1, title: 'Personal Profile Page', difficulty: 'Beginner',
    skills: ['HTML structure', 'Headings', 'Paragraphs', 'Images', 'Links', 'Basic CSS'],
    objective: 'Build a simple personal profile page that introduces yourself using headings, a photo, a paragraph about you, and links to your hobbies.',
    requirements: [
      'A <code>&lt;h1&gt;</code> with your name',
      'A paragraph introducing yourself',
      'An image (your photo or an avatar)',
      'A list of your hobbies or skills',
      'At least one link to a website you like',
      'Basic CSS: a background color, font, and some padding'
    ],
    instructions: [
      'Create a new folder and add <code>index.html</code> and <code>style.css</code>.',
      'In HTML, add the doctype, html, head (with title and linked CSS) and body.',
      'Add an h1, a paragraph, an image, a list and a link.',
      'Style the page: choose a color scheme, set a font, add spacing.',
      'Open index.html in your browser to preview, and test resizing.'
    ],
    challenges: [
      'Add a <code>nav</code> so users can jump to your About and Hobbies sections.',
      'Center the whole page with a max-width container.',
      'Make your image round using border-radius.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Profile</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Your profile goes here -->
</body>
</html>` },

  { id: 'p2', num: 2, title: 'Simple School Website', difficulty: 'Beginner',
    skills: ['Semantic HTML', 'Multiple pages', 'Navigation', 'Tables', 'Lists'],
    objective: 'Create a small multi-page school website with a Home, About and Contact page linked together by navigation.',
    requirements: [
      'A <code>nav</code> with links to Home, About and Contact',
      'A <code>header</code> with the school name',
      'A Home page with an intro paragraph',
      'An About page with a list of school programs',
      'A Contact page with a simple form',
      'A <code>footer</code> with copyright'
    ],
    instructions: [
      'Create three files: index.html, about.html, contact.html plus a shared style.css.',
      'Use semantic tags: header, nav, main, section, footer.',
      'Reuse the same nav and footer on every page (copy the code).',
      'Link all pages together with &lt;a&gt; tags using relative paths.',
      'Test navigation by clicking through every page.'
    ],
    challenges: [
      'Add a table of term dates or staff on the About page.',
      'Style the nav links so the current page looks different.',
      'Add an image banner to the Home page.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My School</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Greenfield High School</h1>
    <nav>
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
    </nav>
  </header>
  <main>
    <!-- Page content -->
  </main>
  <footer>&copy; 2026 Greenfield High</footer>
</body>
</html>` },

  { id: 'p3', num: 3, title: 'Restaurant Website', difficulty: 'Beginner',
    skills: ['Layout', 'Lists', 'Images', 'Colors', 'Typography'],
    objective: 'Build a one-page restaurant site with a hero, a menu, an about section and a reservation form.',
    requirements: [
      'A hero section with the restaurant name and tagline',
      'A menu section listing dishes (use lists or cards)',
      'An "About us" section',
      'A reservation form (name, date, guests)',
      'A footer with address and hours',
      'A consistent color theme matching a restaurant feel'
    ],
    instructions: [
      'Start with a hero: a strong heading, subtitle and a call-to-action button.',
      'Add a menu section — give each dish a name, description and price.',
      'Use a warm color palette (e.g. reds, oranges, creams).',
      'Style the reservation form with labels and inputs.',
      'Add hover effects on menu cards.'
    ],
    challenges: [
      'Use CSS Grid for the menu card layout.',
      'Add a "special of the day" highlighted card.',
      'Make the hero background a gradient.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tasty Bites</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="hero">
    <h1>Tasty Bites</h1>
    <p>Fresh food, cooked with love</p>
  </header>
  <!-- Add menu, about, reservation -->
</body>
</html>` },

  { id: 'p4', num: 4, title: 'Portfolio Website', difficulty: 'Intermediate',
    skills: ['Flexbox', 'Cards', 'Hover effects', 'Sections', 'Responsive'],
    objective: 'Create a personal portfolio to showcase projects, skills and contact info using a modern single-page layout.',
    requirements: [
      'A header with your name and nav',
      'A hero/intro section',
      'A Projects section using cards (image, title, description)',
      'A Skills section (use a list or progress bars)',
      'A Contact section',
      'Hover effects on cards'
    ],
    instructions: [
      'Build the hero with a big headline and a short intro.',
      'Use Flexbox for the nav and to lay out skill badges.',
      'Create project cards with flexbox or grid, each with an image, title and description.',
      'Add hover effects (lift, shadow) to the cards.',
      'Make it responsive with a media query.'
    ],
    challenges: [
      'Add a smooth scroll to sections using anchor links.',
      'Use grid-template-areas for the overall page.',
      'Add a subtle gradient to the hero.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Portfolio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Jane Doe</h1>
    <nav>
      <a href="#projects">Projects</a>
      <a href="#skills">Skills</a>
      <a href="#contact">Contact</a>
    </nav>
  </header>
  <!-- Hero, Projects, Skills, Contact -->
</body>
</html>` },

  { id: 'p5', num: 5, title: 'Registration Form', difficulty: 'Intermediate',
    skills: ['Forms', 'Inputs', 'Validation', 'Labels', 'Buttons'],
    objective: 'Build a clean, well-structured registration form for a school or event with proper labels and validation.',
    requirements: [
      'A heading and brief description',
      'Text inputs for name and email',
      'A password input',
      'Radio buttons for gender or a select for course',
      'Checkbox for terms and conditions',
      'A submit button',
      'Every input labelled with a &lt;label&gt;'
    ],
    instructions: [
      'Wrap all fields in a &lt;form&gt;.',
      'Use the correct input types (email, password, radio, checkbox).',
      'Connect each label to its input using for/id.',
      'Add required, placeholder and validation attributes.',
      'Style the form: spacing, borders, focus states.'
    ],
    challenges: [
      'Add a &lt;fieldset&gt; with a legend to group contact details.',
      'Style the focus state of inputs.',
      'Add a confirm-password input.'
    ],
    starter: `<form action="#" method="post">
  <h2>Create Account</h2>
  <!-- Add labeled inputs here -->
</form>` },

  { id: 'p6', num: 6, title: 'Student Result Table', difficulty: 'Intermediate',
    skills: ['Tables', 'thead/tbody', 'colspan', 'Styling tables'],
    objective: 'Create a styled table that shows student scores with headers, totals and a grade column.',
    requirements: [
      'A table with headers for Student, Subjects, Score and Grade',
      'At least 4 students',
      'At least 3 subjects per student',
      'A total or average row using colspan',
      'Alternating row colours for readability'
    ],
    instructions: [
      'Structure the table with thead (headers) and tbody (data).',
      'Add one row per student with their scores.',
      'Use colspan for a totals row.',
      'Style with borders, header background and zebra striping.',
      'Highlight the top score.'
    ],
    challenges: [
      'Add a caption to the table.',
      'Colour-code grades (A green, C orange, F red).',
      'Make the table scrollable on small screens.'
    ],
    starter: `<table>
  <thead>
    <tr>
      <th>Student</th>
      <th>Subject</th>
      <th>Score</th>
      <th>Grade</th>
    </tr>
  </thead>
  <tbody>
    <!-- Add rows -->
  </tbody>
</table>` },

  { id: 'p7', num: 7, title: 'Responsive Landing Page', difficulty: 'Advanced',
    skills: ['Responsive design', 'Media queries', 'Flexbox', 'Grid', 'Mobile-first'],
    objective: 'Build a fully responsive landing page for a product or service that works well on phones, tablets and desktops.',
    requirements: [
      'A mobile-first design',
      'A hero with a call-to-action',
      'A features section using a responsive grid',
      'A pricing or plan section with cards',
      'A testimonial section',
      'A footer',
      'Media queries that adjust the layout at breakpoints'
    ],
    instructions: [
      'Start with the phone layout first.',
      'Use a responsive grid (auto-fit/minmax) for the features.',
      'Stack content on mobile, spread into columns on larger screens.',
      'Test at 375px, 768px and 1024px widths in DevTools.',
      'Ensure images and text reflow cleanly.'
    ],
    challenges: [
      'Use grid-template-areas for the page layout.',
      'Add a mobile hamburger menu.',
      'Add smooth hover and transition effects.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product Landing</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Hero, Features, Pricing, Testimonials, Footer -->
</body>
</html>` },

  { id: 'p8', num: 8, title: 'School Dashboard UI', difficulty: 'Advanced',
    skills: ['Layout', 'Grid', 'Cards', 'Sidebar', 'Icons'],
    objective: 'Build the user interface of a school admin dashboard with a sidebar, stat cards and a content area.',
    requirements: [
      'A sidebar with navigation links',
      'A top bar with a search box and user name',
      'Stat cards (students, staff, attendance)',
      'A content area with a simple table or chart placeholder',
      'A responsive layout that stacks on mobile',
      'Hover effects on cards and nav links'
    ],
    instructions: [
      'Use CSS Grid for the overall dashboard layout (sidebar + main).',
      'Build the sidebar with a list of links.',
      'Add stat cards using a grid.',
      'Add a table of recent activity.',
      'Make the sidebar collapse or hide on mobile.'
    ],
    challenges: [
      'Add icons next to nav links.',
      'Highlight the active nav item.',
      'Make the sidebar a slide-in menu on mobile.'
    ],
    starter: `<div class="dashboard">
  <aside class="sidebar">
    <!-- nav links -->
  </aside>
  <main class="content">
    <header class="topbar">...</header>
    <!-- stat cards, table -->
  </main>
</div>` },

  { id: 'p9', num: 9, title: 'Complete Responsive School Website', difficulty: 'Advanced',
    skills: ['Everything learned', 'Multiple sections', 'Responsive', 'Semantic HTML'],
    objective: 'Combine everything to build a complete, responsive multi-section school website. This prepares you for the final capstone.',
    requirements: [
      'A header with logo and responsive nav',
      'A hero section',
      'A programs section (cards)',
      'An about section',
      'A gallery with images',
      'A contact section with a form',
      'A footer',
      'Full responsiveness'
    ],
    instructions: [
      'Plan the sections before coding.',
      'Build the HTML structure with semantic tags.',
      'Add CSS progressively: base, then layout, then responsive.',
      'Test every section on phone, tablet and desktop.',
      'Polish with hover effects and transitions.'
    ],
    challenges: [
      'Add a sticky header.',
      'Use grid-template-areas.',
      'Add a hamburger menu.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My School</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>...</header>
  <main>
    <section class="hero">...</section>
    <section class="programs">...</section>
    <!-- about, gallery, contact -->
  </main>
  <footer>...</footer>
</body>
</html>` },

  { id: 'p10', num: 10, title: 'CAPSTONE: Complete Responsive School Website', difficulty: 'Capstone', capstone: true,
    skills: ['All HTML', 'All CSS', 'Responsive design', 'Flexbox', 'Grid', 'Forms', 'Semantic HTML'],
    objective: 'Your final project: build a complete, professional, fully responsive school website from scratch, applying everything you have learned.',
    requirements: [
      'A <strong>Home</strong> page with a hero section',
      'An <strong>About</strong> page describing the school',
      'A <strong>Programs</strong> page showing courses with cards',
      'A <strong>Contact</strong> page with a registration form',
      'A responsive <strong>navigation</strong> bar (hamburger on mobile)',
      'A hero section with a call-to-action',
      'Cards for programs and news',
      'Images with alt text',
      'A registration form with labels',
      'A footer with links and contact info',
      'Use <strong>Flexbox</strong> for nav and rows',
      'Use <strong>CSS Grid</strong> for page and card layouts',
      '<strong>Media queries</strong> for full responsiveness',
      '<strong>Hover effects</strong> on cards and links',
      '<strong>Transitions</strong> for smooth interactions'
    ],
    instructions: [
      'Plan: sketch each page and its sections before coding.',
      'Set up the folder: index.html, about.html, programs.html, contact.html and a shared style.css.',
      'Build the shared header and footer once, then reuse across pages.',
      'Style mobile-first, then add media queries for larger screens.',
      'Use semantic tags throughout (header, nav, main, section, article, footer).',
      'Test every page on phone, tablet and desktop using DevTools.',
      'Validate your HTML with the W3C validator if possible.',
      'Review: check navigation, responsiveness, accessibility and polish.'
    ],
    challenges: [
      'Add a sticky nav that stays on top when scrolling.',
      'Add an "upcoming events" section using a table.',
      'Make the registration form show a success message.',
      'Add a subtle animation to the hero.',
      'Ensure 100% of images have meaningful alt text.'
    ],
    starter: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My School</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="site-header">
    <div class="logo">My School</div>
    <nav class="nav">
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
      <a href="programs.html">Programs</a>
      <a href="contact.html">Contact</a>
    </nav>
  </header>
  <main>
    <section class="hero">
      <h1>Welcome to My School</h1>
      <p>Quality education for every student.</p>
    </section>
    <!-- Add more sections -->
  </main>
  <footer>&copy; 2026 My School</footer>
</body>
</html>` }
];

const Projects = {
  getAll() { return PROJECTS; },
  get(id) { return PROJECTS.find(p => p.id === id); },
  search(q) {
    const query = q.toLowerCase().trim();
    if (!query) return [];
    return PROJECTS.filter(p => (p.title + ' ' + p.objective).toLowerCase().includes(query))
      .map(p => ({ type: 'Project', title: p.title, snippet: p.objective, url: 'projects.html#p-' + p.id }));
  }
};
