/* =========================================================
   HTML & CSS MASTERY — cheatsheets.js
   HTML and CSS quick-reference cheat sheets.
   ========================================================= */

const CHEATSHEETS = {
  html: [
    { cat: 'Structure', items: [
      { name: '<!DOCTYPE html>', purpose: 'Declares the document as HTML5.', example: '<!DOCTYPE html>' },
      { name: '<html>', purpose: 'Root element wrapping the whole page.', example: '<html lang="en">' },
      { name: '<head>', purpose: 'Invisible metadata: title, links, scripts.', example: '<head>...</head>' },
      { name: '<body>', purpose: 'All visible content lives here.', example: '<body>...</body>' },
      { name: '<title>', purpose: 'Text shown in the browser tab.', example: '<title>My Page</title>' },
      { name: '<meta>', purpose: 'Page metadata like charset and viewport.', example: '<meta charset="UTF-8">' }
    ] },
    { cat: 'Text', items: [
      { name: '<h1>..<h6>', purpose: 'Headings, h1 largest to h6 smallest.', example: '<h1>Main Title</h1>' },
      { name: '<p>', purpose: 'A paragraph of text.', example: '<p>Hello there.</p>' },
      { name: '<strong>', purpose: 'Important text (bold).', example: '<strong>Important</strong>' },
      { name: '<em>', purpose: 'Emphasized text (italic).', example: '<em>Emphasis</em>' },
      { name: '<mark>', purpose: 'Highlighted text.', example: '<mark>key</mark>' },
      { name: '<br>', purpose: 'A line break (void).', example: 'line 1<br>line 2' },
      { name: '<hr>', purpose: 'A horizontal rule/divider (void).', example: '<hr>' }
    ] },
    { cat: 'Links', items: [
      { name: '<a>', purpose: 'A hyperlink to another page or location.', example: '<a href="page.html">Link</a>' },
      { name: '<a target>', purpose: 'Opens the link in a new tab.', example: '<a href="x.com" target="_blank">X</a>' }
    ] },
    { cat: 'Images', items: [
      { name: '<img>', purpose: 'Embeds an image (void element).', example: '<img src="pic.jpg" alt="A photo">' }
    ] },
    { cat: 'Lists', items: [
      { name: '<ul>', purpose: 'Unordered (bulleted) list.', example: '<ul><li>Item</li></ul>' },
      { name: '<ol>', purpose: 'Ordered (numbered) list.', example: '<ol><li>Step</li></ol>' },
      { name: '<li>', purpose: 'A list item.', example: '<li>One</li>' },
      { name: '<dl>', purpose: 'Description list (terms + descriptions).', example: '<dl><dt>Term</dt><dd>Def</dd></dl>' }
    ] },
    { cat: 'Tables', items: [
      { name: '<table>', purpose: 'A data table.', example: '<table>...</table>' },
      { name: '<tr>', purpose: 'A table row.', example: '<tr><td>A</td></tr>' },
      { name: '<th>', purpose: 'A header cell.', example: '<th>Name</th>' },
      { name: '<td>', purpose: 'A data cell.', example: '<td>John</td>' },
      { name: '<thead>/<tbody>', purpose: 'Group header and body rows.', example: '<thead><tr><th>..' },
      { name: 'colspan/rowspan', purpose: 'Merge cells.', example: '<td colspan="2">..' }
    ] },
    { cat: 'Forms', items: [
      { name: '<form>', purpose: 'Collects user input.', example: '<form action="/submit" method="post">' },
      { name: '<input>', purpose: 'A form field (void).', example: '<input type="text">' },
      { name: '<label>', purpose: 'A label for an input.', example: '<label for="n">Name</label>' },
      { name: '<button>', purpose: 'A clickable button.', example: '<button type="submit">Go</button>' },
      { name: '<select>/<option>', purpose: 'A dropdown.', example: '<select><option>A</option></select>' },
      { name: '<textarea>', purpose: 'Multi-line text input.', example: '<textarea rows="3"></textarea>' }
    ] },
    { cat: 'Semantic HTML', items: [
      { name: '<header>', purpose: 'Intro content / top of a section.', example: '<header><h1>Site</h1></header>' },
      { name: '<nav>', purpose: 'Navigation links.', example: '<nav><a href="#">Home</a></nav>' },
      { name: '<main>', purpose: 'Unique main content (one per page).', example: '<main>...</main>' },
      { name: '<section>', purpose: 'A themed group of content.', example: '<section><h2>News</h2></section>' },
      { name: '<article>', purpose: 'Self-contained content.', example: '<article>blog post</article>' },
      { name: '<aside>', purpose: 'Complementary side content.', example: '<aside>related links</aside>' },
      { name: '<footer>', purpose: 'Closing info: copyright, contact.', example: '<footer>&copy; 2026</footer>' }
    ] },
    { cat: 'Multimedia', items: [
      { name: '<video>', purpose: 'Embed a video.', example: '<video controls><source src="m.mp4"></video>' },
      { name: '<audio>', purpose: 'Embed audio.', example: '<audio controls><source src="a.mp3"></audio>' },
      { name: '<iframe>', purpose: 'Embed another document.', example: '<iframe src="x.com"></iframe>' },
      { name: '<figure>', purpose: 'Groups media with a caption.', example: '<figure><img src="p.jpg"><figcaption>Caption</figcaption></figure>' }
    ] }
  ],

  css: [
    { cat: 'Text', items: [
      { name: 'font-family', purpose: 'Set the font.', syntax: 'font-family: Arial, sans-serif;', example: 'font-family: "Segoe UI", sans-serif;' },
      { name: 'font-size', purpose: 'Size of the text.', syntax: 'font-size: 16px;', example: 'font-size: 1.5rem;' },
      { name: 'font-weight', purpose: 'Thickness (bold).', syntax: 'font-weight: 700;', example: 'font-weight: bold;' },
      { name: 'text-align', purpose: 'Horizontal alignment.', syntax: 'text-align: center;', example: 'text-align: justify;' },
      { name: 'line-height', purpose: 'Space between lines.', syntax: 'line-height: 1.6;', example: 'line-height: 1.6;' },
      { name: 'text-transform', purpose: 'Change case.', syntax: 'text-transform: uppercase;', example: 'text-transform: capitalize;' }
    ] },
    { cat: 'Colors', items: [
      { name: 'color', purpose: 'Text colour.', syntax: 'color: #333;', example: 'color: rgb(255, 0, 0);' },
      { name: 'background-color', purpose: 'Background colour.', syntax: 'background-color: #fff;', example: 'background-color: lightblue;' },
      { name: 'opacity', purpose: 'Transparency (0-1).', syntax: 'opacity: 0.5;', example: 'opacity: 0.8;' }
    ] },
    { cat: 'Backgrounds', items: [
      { name: 'background-image', purpose: 'A background image.', syntax: 'background-image: url("img.jpg");', example: 'background-image: url("bg.png");' },
      { name: 'background-size', purpose: 'How the image fills.', syntax: 'background-size: cover;', example: 'background-size: contain;' },
      { name: 'background-repeat', purpose: 'Repeat behaviour.', syntax: 'background-repeat: no-repeat;', example: 'background-repeat: repeat-x;' },
      { name: 'background', purpose: 'Shorthand.', syntax: 'background: color url pos/size repeat;', example: 'background: #2f5af0 url("b.jpg") center/cover;' }
    ] },
    { cat: 'Box Model', items: [
      { name: 'padding', purpose: 'Space inside the border.', syntax: 'padding: 10px 20px;', example: 'padding: 16px;' },
      { name: 'margin', purpose: 'Space outside the border.', syntax: 'margin: 0 auto;', example: 'margin: 20px 0;' },
      { name: 'border', purpose: 'A border around the element.', syntax: 'border: 2px solid #333;', example: 'border: 1px dashed gray;' },
      { name: 'border-radius', purpose: 'Round the corners.', syntax: 'border-radius: 12px;', example: 'border-radius: 50%;' },
      { name: 'box-sizing', purpose: 'Include padding in width.', syntax: 'box-sizing: border-box;', example: 'box-sizing: border-box;' },
      { name: 'width', purpose: 'Set the width.', syntax: 'width: 300px;', example: 'width: 100%;' },
      { name: 'max-width', purpose: 'Maximum width.', syntax: 'max-width: 960px;', example: 'max-width: 100%;' }
    ] },
    { cat: 'Display', items: [
      { name: 'display', purpose: 'Layout behaviour of an element.', syntax: 'display: block;', example: 'display: flex;' },
      { name: 'gap', purpose: 'Space between flex/grid items.', syntax: 'gap: 16px;', example: 'gap: 12px;' }
    ] },
    { cat: 'Position', items: [
      { name: 'position', purpose: 'Positioning scheme.', syntax: 'position: relative;', example: 'position: sticky;' },
      { name: 'top/right/bottom/left', purpose: 'Offsets for positioned elements.', syntax: 'top: 10px;', example: 'right: 0;' },
      { name: 'z-index', purpose: 'Stacking order.', syntax: 'z-index: 10;', example: 'z-index: 100;' }
    ] },
    { cat: 'Flexbox', items: [
      { name: 'display: flex', purpose: 'Make a flex container.', syntax: 'display: flex;', example: 'display: flex;' },
      { name: 'justify-content', purpose: 'Align along main axis.', syntax: 'justify-content: space-between;', example: 'justify-content: center;' },
      { name: 'align-items', purpose: 'Align along cross axis.', syntax: 'align-items: center;', example: 'align-items: stretch;' },
      { name: 'flex-direction', purpose: 'Row or column.', syntax: 'flex-direction: column;', example: 'flex-direction: row;' },
      { name: 'flex-wrap', purpose: 'Wrap items to new lines.', syntax: 'flex-wrap: wrap;', example: 'flex-wrap: wrap;' },
      { name: 'flex', purpose: 'Grow/shrink shorthand.', syntax: 'flex: 1;', example: 'flex: 2;' }
    ] },
    { cat: 'Grid', items: [
      { name: 'display: grid', purpose: 'Make a grid container.', syntax: 'display: grid;', example: 'display: grid;' },
      { name: 'grid-template-columns', purpose: 'Define columns.', syntax: 'grid-template-columns: 1fr 1fr;', example: 'grid-template-columns: repeat(3, 1fr);' },
      { name: 'grid-template-areas', purpose: 'Named layout areas.', syntax: 'grid-template-areas: "a a" "b c";', example: '.header { grid-area: a; }' },
      { name: 'grid-column', purpose: 'Span columns.', syntax: 'grid-column: span 2;', example: 'grid-column: span 2;' },
      { name: 'gap', purpose: 'Space between cells.', syntax: 'gap: 16px;', example: 'gap: 20px;' }
    ] },
    { cat: 'Responsive Design', items: [
      { name: '@media', purpose: 'Conditional styles by screen size.', syntax: '@media (max-width: 768px) { }', example: '@media (min-width: 1024px) { ... }' },
      { name: 'min-width', purpose: 'Apply above a width.', syntax: 'min-width: 768px;', example: 'min-width: 900px;' },
      { name: 'max-width', purpose: 'Apply below a width.', syntax: 'max-width: 600px;', example: 'max-width: 480px;' }
    ] },
    { cat: 'Transitions', items: [
      { name: 'transition', purpose: 'Animate property changes.', syntax: 'transition: property duration timing;', example: 'transition: all 0.3s ease;' },
      { name: 'transition-duration', purpose: 'How long the change takes.', syntax: 'transition-duration: 0.3s;', example: 'transition-duration: 0.2s;' }
    ] },
    { cat: 'Transform', items: [
      { name: 'transform', purpose: 'Move, scale, rotate, skew.', syntax: 'transform: translate(10px) scale(1.1);', example: 'transform: rotate(45deg);' },
      { name: 'translate()', purpose: 'Move the element.', syntax: 'transform: translate(x, y);', example: 'transform: translateY(-20px);' },
      { name: 'scale()', purpose: 'Resize the element.', syntax: 'transform: scale(1.2);', example: 'transform: scale(0.9);' },
      { name: 'rotate()', purpose: 'Rotate the element.', syntax: 'transform: rotate(deg);', example: 'transform: rotate(180deg);' }
    ] },
    { cat: 'Animation', items: [
      { name: '@keyframes', purpose: 'Define animation frames.', syntax: '@keyframes name { from {...} to {...} }', example: '@keyframes fade { 0%{opacity:0} 100%{opacity:1} }' },
      { name: 'animation', purpose: 'Apply an animation.', syntax: 'animation: name duration timing;', example: 'animation: fade 1s ease;' },
      { name: 'animation-iteration-count', purpose: 'How many times.', syntax: 'animation-iteration-count: infinite;', example: 'animation-iteration-count: 3;' },
      { name: 'box-shadow', purpose: 'Drop shadow for depth.', syntax: 'box-shadow: x y blur color;', example: 'box-shadow: 0 4px 10px rgba(0,0,0,0.2);' },
      { name: 'text-shadow', purpose: 'Shadow on text.', syntax: 'text-shadow: x y blur color;', example: 'text-shadow: 2px 2px 4px rgba(0,0,0,0.4);' }
    ] }
  ]
};

const Cheatsheets = {
  get(kind) { return CHEATSHEETS[kind] || []; },
  search(q) {
    const query = q.toLowerCase().trim();
    if (!query) return [];
    const out = [];
    ['html', 'css'].forEach(kind => {
      CHEATSHEETS[kind].forEach(cat => {
        cat.items.forEach(it => {
          if ((it.name + ' ' + it.purpose).toLowerCase().includes(query)) {
            out.push({ type: 'Cheat sheet: ' + (kind === 'html' ? 'HTML' : 'CSS'), title: it.name, snippet: it.purpose, url: 'cheatsheets.html' + (kind === 'html' ? '#html' : '#css') });
          }
        });
      });
    });
    return out;
  }
};
