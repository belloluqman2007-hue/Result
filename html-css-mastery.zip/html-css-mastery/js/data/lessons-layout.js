/* =========================================================
   HTML & CSS MASTERY — lessons-layout.js
   Module 7 (Layout), Module 8 (Responsive), Module 9 (Effects)
   ========================================================= */

(function () {

  /* ============ MODULE 7 — LAYOUT ============ */

  Curriculum.addLesson({
    id: 'css-display',
    module: 'Module 7 — Layout',
    title: 'Display',
    summary: 'Change how elements display with block, inline, inline-block and none.',
    keywords: ['display', 'block', 'inline', 'inline-block', 'none', 'flex', 'grid'],
    objectives: [
      'Understand the display property',
      'Use block, inline and inline-block',
      'Hide elements with display: none',
      'Know that flex and grid are also display values'
    ],
    blocks: [
      { t: 'lead', text: 'The <code>display</code> property controls how an element behaves in the layout — whether it is a full-width block, sits inline, or hides entirely.' },
      { t: 'table', head: ['Value', 'Behaviour'], rows: [
        ['<code>block</code>', 'Full width, starts on a new line'],
        ['<code>inline</code>', 'Flows with text, no width/height'],
        ['<code>inline-block</code>', 'Inline but respects width/height'],
        ['<code>none</code>', 'Removed from the page entirely'],
        ['<code>flex</code>', 'Makes it a flex container'],
        ['<code>grid</code>', 'Makes it a grid container']
      ] },
      { t: 'code', lang: 'css', caption: 'Changing display', code: `.inline-block {
  display: inline-block;
  width: 150px;    /* respected! */
}

.hidden {
  display: none;   /* disappears from layout */
}` },
      { t: 'p', text: 'You can change an element\'s display. For example, turning a list into a horizontal menu with <code>display: inline</code> or <code>flex</code> on the items.' },
      { t: 'demo', title: 'Display values demo', html: `<div style="font-family:sans-serif;display:grid;gap:8px">
<div style="background:#ffe3e4;padding:8px;border-radius:6px">block — full width</div>
<span style="background:#e3f6ee;padding:8px;border-radius:6px;display:inline-block;margin-top:4px">inline-block</span>
<span style="background:#e3f6ee;padding:8px;border-radius:6px;display:inline-block;margin-top:4px">another inline-block</span>
</div>` },
      { t: 'callout', type: 'tip', title: 'display: none vs visibility: hidden',
        text: '<code>display: none</code> removes the element from the layout entirely. <code>visibility: hidden</code> keeps its space but makes it invisible. Choose depending on the effect you want.' },
      { t: 'quiz', q: 'Which display value removes an element from the page layout?', options: ['inline', 'none', 'block', 'hidden'], answer: 1,
        explanation: '<code>display: none</code> takes the element out of the layout. visibility:hidden keeps the space but hides it.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-position',
    module: 'Module 7 — Layout',
    title: 'Position',
    summary: 'Position elements with static, relative, absolute, fixed and sticky.',
    keywords: ['position', 'relative', 'absolute', 'fixed', 'sticky', 'top', 'left', 'z-index'],
    objectives: [
      'Understand the five position values',
      'Use relative and absolute together',
      'Create fixed and sticky elements',
      'Stack elements with z-index'
    ],
    blocks: [
      { t: 'lead', text: '<code>position</code> changes where an element sits on the page. Combined with <code>top</code>, <code>right</code>, <code>bottom</code> and <code>left</code>, it is very powerful.' },
      { t: 'table', head: ['Value', 'Behaviour'], rows: [
        ['<code>static</code>', 'Default — normal document flow'],
        ['<code>relative</code>', 'Offset from its normal spot'],
        ['<code>absolute</code>', 'Positioned relative to nearest positioned ancestor'],
        ['<code>fixed</code>', 'Relative to the viewport — stays on scroll'],
        ['<code>sticky</code>', 'Relative, then "sticks" when scrolling']
      ] },
      { t: 'h3', text: 'Relative + absolute (the common pair)' },
      { t: 'p', text: 'Set the parent to <code>relative</code>, then position a child <code>absolute</code> inside it — the child positions relative to the parent.' },
      { t: 'code', lang: 'css', caption: 'Badge over a card', code: `.card {
  position: relative;
}

.badge {
  position: absolute;
  top: 10px;
  right: 10px;
}` },
      { t: 'h3', text: 'Sticky headers' },
      { t: 'code', lang: 'css', caption: 'A sticky nav', code: `nav {
  position: sticky;
  top: 0;
}` },
      { t: 'demo', title: 'Absolute positioning demo', html: `<div style="position:relative;height:120px;background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;font-family:sans-serif;padding:12px">
<p style="margin:0">Parent (position: relative)</p>
<div style="position:absolute;top:10px;right:10px;background:#e5484d;color:#fff;padding:4px 10px;border-radius:20px;font-size:12px">New!</div>
</div>` },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'An <code>absolute</code> element positions relative to the nearest positioned ancestor. If none exists, it positions relative to the whole page — which often is not what you expect.' },
      { t: 'quiz', q: 'Which position value keeps an element fixed on screen while scrolling?', options: ['relative', 'absolute', 'fixed', 'static'], answer: 2,
        explanation: '<code>position: fixed</code> anchors an element to the viewport so it stays visible while the page scrolls (like a sticky button).' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-flexbox-1',
    module: 'Module 7 — Layout',
    flexbox: true,
    title: 'Flexbox (Part 1): The Basics',
    summary: 'Create flexible one-dimensional layouts with display: flex.',
    keywords: ['flexbox', 'flex', 'justify-content', 'align-items', 'flex-direction', 'gap', 'flexbox'],
    objectives: [
      'Turn a container into a flexbox',
      'Align items along the main and cross axes',
      'Use justify-content and align-items',
      'Space items with gap'
    ],
    blocks: [
      { t: 'lead', text: '<strong>Flexbox</strong> is a modern, powerful way to arrange elements in a row or column. It handles alignment, spacing and distribution far better than floats or tables.' },
      { t: 'code', lang: 'css', caption: 'Making a flex container', code: `.row {
  display: flex;
  gap: 16px;                 /* space between items */
}` },
      { t: 'p', text: 'The parent becomes a <strong>flex container</strong> and its children become <strong>flex items</strong> laid out in a row by default.' },
      { t: 'h3', text: 'Aligning along the main axis' },
      { t: 'code', lang: 'css', caption: 'justify-content', code: `.row {
  display: flex;
  justify-content: space-between; /* start, center, space-around... */
}` },
      { t: 'table', head: ['justify-content value', 'Effect (row)'], rows: [
        ['<code>flex-start</code>', 'Items at the start (left)'],
        ['<code>center</code>', 'Items centered'],
        ['<code>space-between</code>', 'Equal space between items'],
        ['<code>space-around</code>', 'Equal space around items'],
        ['<code>space-evenly</code>', 'Equal space everywhere']
      ] },
      { t: 'h3', text: 'Aligning along the cross axis' },
      { t: 'code', lang: 'css', caption: 'align-items', code: `.row {
  display: flex;
  align-items: center;  /* stretch, flex-start, flex-end */
}` },
      { t: 'demo', title: 'Flexbox centering', html: `<div style="font-family:sans-serif;display:flex;justify-content:space-between;align-items:center;background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;padding:14px">
<span style="background:#2f5af0;color:#fff;padding:10px;border-radius:6px">Item 1</span>
<span style="background:#00b386;color:#fff;padding:10px;border-radius:6px">Item 2</span>
<span style="background:#e5484d;color:#fff;padding:10px;border-radius:6px">Item 3</span>
</div>` },
      { t: 'callout', type: 'tip', title: 'Perfect centering',
        text: 'The classic trick to center something both ways: <code>display:flex; justify-content:center; align-items:center;</code> on the container.' },
      { t: 'quiz', q: 'Which property distributes flex items along the main axis?', options: ['align-items', 'justify-content', 'flex-wrap', 'gap'], answer: 1,
        explanation: 'justify-content aligns items along the main axis (row default). align-items works on the cross axis.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-flexbox-2',
    module: 'Module 7 — Layout',
    flexbox: true,
    title: 'Flexbox (Part 2): Grow & Wrap',
    summary: 'Control flex items with flex-grow, flex-wrap and flex-direction.',
    keywords: ['flexbox', 'flex-grow', 'flex-wrap', 'flex-direction', 'flex-basis', 'flex', 'flexbox'],
    objectives: [
      'Grow and shrink flex items with flex',
      'Wrap items onto new lines',
      'Change direction with flex-direction',
      'Build a flexible nav or card row'
    ],
    blocks: [
      { t: 'lead', text: 'Beyond alignment, Flexbox lets items grow, shrink and wrap to fill available space — that is what makes it so flexible.' },
      { t: 'code', lang: 'css', caption: 'flex-grow', code: `.item {
  flex: 1;   /* grows to fill space equally */
}
.item.big {
  flex: 2;   /* takes twice as much space */
}` },
      { t: 'h3', text: 'Wrapping' },
      { t: 'code', lang: 'css', caption: 'Allow items to wrap', code: `.cards {
  display: flex;
  flex-wrap: wrap;   /* default nowrap */
  gap: 16px;
}` },
      { t: 'h3', text: 'Direction' },
      { t: 'code', lang: 'css', caption: 'Row vs column', code: `.column {
  display: flex;
  flex-direction: column;  /* stack vertically */
}` },
      { t: 'demo', title: 'Flexbox wrap demo', html: `<div style="font-family:sans-serif;display:flex;flex-wrap:wrap;gap:10px;background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;padding:14px">
<div style="flex:1;min-width:120px;background:#2f5af0;color:#fff;padding:16px;border-radius:6px;text-align:center">Card 1</div>
<div style="flex:1;min-width:120px;background:#00b386;color:#fff;padding:16px;border-radius:6px;text-align:center">Card 2</div>
<div style="flex:1;min-width:120px;background:#e5484d;color:#fff;padding:16px;border-radius:6px;text-align:center">Card 3</div>
</div>` },
      { t: 'callout', type: 'good', title: 'Real-world use',
        text: 'Flexbox is perfect for nav bars, toolbars, card rows, and centering. For entire page grids with rows and columns, CSS Grid (next) is usually better.' },
      { t: 'quiz', q: 'Which flex property makes items wrap onto new lines?', options: ['flex-grow', 'flex-wrap', 'flex-direction', 'justify-content'], answer: 1,
        explanation: '<code>flex-wrap: wrap</code> lets items flow onto additional lines when space runs out instead of shrinking.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-grid-1',
    module: 'Module 7 — Layout',
    grid: true,
    title: 'CSS Grid (Part 1): The Basics',
    summary: 'Create two-dimensional layouts with display: grid and template columns.',
    keywords: ['grid', 'grid-template-columns', 'gap', 'grid-template-rows', 'css grid', 'grid'],
    objectives: [
      'Make a grid container',
      'Define columns with grid-template-columns',
      'Use repeat() and the fr unit',
      'Place items automatically'
    ],
    blocks: [
      { t: 'lead', text: '<strong>CSS Grid</strong> is a two-dimensional layout system — it arranges items in rows <em>and</em> columns at the same time. Great for page layouts and card grids.' },
      { t: 'code', lang: 'css', caption: 'A simple grid', code: `.grid {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr; /* 3 equal columns */
  gap: 16px;
}` },
      { t: 'p', text: 'The <code>fr</code> unit means "fraction of the available space". <code>1fr 1fr 1fr</code> = three equal columns. You can mix fixed and flexible sizes:' },
      { t: 'code', lang: 'css', caption: 'Mixing sizes', code: `.layout {
  display: grid;
  grid-template-columns: 200px 1fr; /* sidebar + content */
  gap: 20px;
}` },
      { t: 'h3', text: 'Using repeat()' },
      { t: 'code', lang: 'css', caption: 'repeat function', code: `.cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}` },
      { t: 'demo', title: 'Grid columns demo', html: `<div style="font-family:sans-serif;display:grid;grid-template-columns:repeat(3,1fr);gap:10px;background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;padding:14px">
<div style="background:#2f5af0;color:#fff;padding:16px;border-radius:6px;text-align:center">Col 1</div>
<div style="background:#00b386;color:#fff;padding:16px;border-radius:6px;text-align:center">Col 2</div>
<div style="background:#e5484d;color:#fff;padding:16px;border-radius:6px;text-align:center">Col 3</div>
</div>` },
      { t: 'callout', type: 'tip', title: 'Grid vs Flexbox',
        text: 'Quick guide: <strong>Flexbox</strong> for one-dimensional rows/columns of items; <strong>Grid</strong> for full two-dimensional layouts where you control rows and columns together.' },
      { t: 'quiz', q: 'Which unit means "a fraction of the available space" in Grid?', options: ['px', 'em', 'fr', '%'], answer: 2,
        explanation: 'The <code>fr</code> unit distributes available space in fractions. 1fr 1fr gives two equal columns.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-grid-2',
    module: 'Module 7 — Layout',
    grid: true,
    title: 'CSS Grid (Part 2): Areas & Span',
    summary: 'Design layouts with grid areas and make items span multiple columns.',
    keywords: ['grid', 'grid-area', 'grid-template-areas', 'grid-column', 'span', 'css grid', 'grid'],
    objectives: [
      'Use grid-template-areas for readable layouts',
      'Make items span with grid-column',
      'Build a full page layout with Grid',
      'Auto-fit with repeat(auto-fit, minmax)'
    ],
    blocks: [
      { t: 'lead', text: 'Grid\'s real power shows in full-page layouts. <code>grid-template-areas</code> lets you describe the layout with names — extremely readable.' },
      { t: 'code', lang: 'css', caption: 'A full page grid', code: `.page {
  display: grid;
  grid-template-areas:
    "header header"
    "sidebar main"
    "footer footer";
  grid-template-columns: 200px 1fr;
  gap: 16px;
}
.header  { grid-area: header; }
.sidebar { grid-area: sidebar; }
.main    { grid-area: main; }
.footer  { grid-area: footer; }` },
      { t: 'h3', text: 'Spanning with grid-column' },
      { t: 'code', lang: 'css', caption: 'A wide card', code: `.wide {
  grid-column: span 2;   /* span two columns */
}` },
      { t: 'h3', text: 'Responsive grids' },
      { t: 'code', lang: 'css', caption: 'Auto-fit columns', code: `.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}` },
      { t: 'p', text: 'This creates as many 200px+ columns as fit — cards reflow automatically on every screen size. A hugely useful pattern.' },
      { t: 'demo', title: 'auto-fit grid demo', html: `<div style="font-family:sans-serif;display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px">
<div style="background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;padding:16px;text-align:center">A</div>
<div style="background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;padding:16px;text-align:center">B</div>
<div style="background:#eef2ff;border:2px solid #2f5af0;border-radius:8px;padding:16px;text-align:center">C</div>
</div>` },
      { t: 'callout', type: 'good', title: 'Best practice',
        text: 'Use <code>grid-template-areas</code> for the overall page layout and Flexbox for arranging items inside each area. Combined, they are a complete layout toolkit.' },
      { t: 'quiz', q: 'Which property makes a grid item stretch across multiple columns?', options: ['grid-area', 'grid-column: span 2', 'justify-content', 'gap'], answer: 1,
        explanation: '<code>grid-column: span 2</code> makes the item span two column tracks. grid-template-areas is for naming the layout.' }
    ]
  });

  /* ============ MODULE 8 — RESPONSIVE DESIGN ============ */

  Curriculum.addLesson({
    id: 'media-queries',
    module: 'Module 8 — Responsive Design',
    title: 'Media Queries',
    summary: 'Apply different styles for different screen sizes with @media.',
    keywords: ['media query', 'responsive', '@media', 'breakpoint', 'max-width', 'min-width'],
    objectives: [
      'Understand what responsive design is',
      'Write a media query',
      'Choose breakpoints',
      'Use max-width and min-width'
    ],
    blocks: [
      { t: 'lead', text: '<strong>Responsive design</strong> makes a website adapt to any screen — phone, tablet or desktop. <strong>Media queries</strong> are how you apply different CSS at different screen sizes.' },
      { t: 'code', lang: 'css', caption: 'A media query', code: `/* Mobile-first: base styles here */

/* Tablet and up */
@media (min-width: 768px) {
  .columns { display: grid; grid-template-columns: 1fr 1fr; }
}

/* Desktop and up */
@media (min-width: 1024px) {
  .columns { grid-template-columns: 1fr 1fr 1fr; }
}` },
      { t: 'h3', text: 'max-width vs min-width' },
      { t: 'list', items: [
        '<code>@media (max-width: 600px)</code> — applies when the screen is <em>at most</em> 600px (small).',
        '<code>@media (min-width: 600px)</code> — applies when the screen is <em>at least</em> 600px (larger).'
      ] },
      { t: 'demo', title: 'A responsive grid', html: `<div style="font-family:sans-serif;display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px">
<div style="background:#2f5af0;color:#fff;padding:18px;border-radius:8px;text-align:center">1</div>
<div style="background:#00b386;color:#fff;padding:18px;border-radius:8px;text-align:center">2</div>
<div style="background:#e5484d;color:#fff;padding:18px;border-radius:8px;text-align:center">3</div>
</div>` },
      { t: 'callout', type: 'tip', title: 'Resize the window',
        text: 'Open your browser\'s developer tools (F12) and click the mobile icon to see how a page responds at phone sizes. This is essential for testing.' },
      { t: 'quiz', q: 'A media query with (max-width: 600px) applies styles when the screen is...', options: ['Wider than 600px', '600px or narrower', 'Exactly 600px', 'Any size'], answer: 1,
        explanation: 'max-width: 600px targets viewports at most 600px wide — that is, phones and small screens.' }
    ]
  });

  Curriculum.addLesson({
    id: 'mobile-first',
    module: 'Module 8 — Responsive Design',
    title: 'Mobile First',
    summary: 'Design for small screens first, then add styles for larger screens.',
    keywords: ['mobile-first', 'responsive', 'progressive enhancement', 'min-width'],
    objectives: [
      'Understand the mobile-first approach',
      'Write base styles for mobile',
      'Add enhancements with min-width queries',
      'Know why mobile-first is recommended'
    ],
    blocks: [
      { t: 'lead', text: '<strong>Mobile-first</strong> means you design and write CSS for the smallest screens first, then add more advanced layouts as the screen grows.' },
      { t: 'code', lang: 'css', caption: 'Mobile-first CSS', code: `/* Base = phone styles */
.card { padding: 12px; font-size: 15px; }

/* Add complexity for larger screens */
@media (min-width: 768px) {
  .card { padding: 20px; font-size: 16px; }
}` },
      { t: 'h3', text: 'Why mobile-first?' },
      { t: 'list', items: [
        'Most users browse on phones — start with what matters.',
        'You only ever add complexity upward, never fight to remove it.',
        'Forces you to prioritize content and keep it simple.',
        'Performance-friendly for small devices.'
      ] },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'Designing for desktop and then trying to "shrink" everything for mobile often produces cramped, broken layouts. Starting small and growing is far easier.' },
      { t: 'quiz', q: 'In a mobile-first approach, where do you write your base styles?', options: ['Inside media queries', 'At the top, no query', 'Only in a separate file', 'Never'], answer: 1,
        explanation: 'Base styles are written first with no media query, then min-width queries add enhancements for larger screens.' }
    ]
  });

  Curriculum.addLesson({
    id: 'responsive-images',
    module: 'Module 8 — Responsive Design',
    title: 'Responsive Images',
    summary: 'Make images fluid with max-width: 100% and the picture element.',
    keywords: ['responsive image', 'max-width', 'srcset', 'picture', 'fluid image', 'height auto'],
    objectives: [
      'Make images fluid and never overflow',
      'Use max-width: 100% with height: auto',
      'Understand srcset for different screens',
      'Use the picture element'
    ],
    blocks: [
      { t: 'lead', text: 'A fixed-size image can overflow a small screen. Responsive images scale to fit their container and can even load different files per device.' },
      { t: 'code', lang: 'css', caption: 'Make an image fluid', code: `img {
  max-width: 100%;
  height: auto;   /* keep aspect ratio */
}` },
      { t: 'p', text: 'With <code>max-width: 100%</code>, the image never exceeds its container but can shrink on small screens.' },
      { t: 'h3', text: 'Serving different files with srcset' },
      { t: 'code', lang: 'html', caption: 'srcset for sharp images', code: `<img src="photo.jpg"
     srcset="photo-small.jpg 480w,
             photo.jpg 1200w"
     sizes="(max-width: 600px) 100vw, 50vw"
     alt="A landscape">` },
      { t: 'h3', text: 'The picture element' },
      { t: 'p', text: 'When you want different <em>art</em> at different sizes, use <code>&lt;picture&gt;</code>:' },
      { t: 'code', lang: 'html', caption: 'Picture element', code: `<picture>
  <source media="(min-width: 800px)" srcset="wide.jpg">
  <source media="(min-width: 400px)" srcset="medium.jpg">
  <img src="small.jpg" alt="A scenic view">
</picture>` },
      { t: 'demo', title: 'Fluid image demo', html: `<div style="font-family:sans-serif;max-width:340px;border:1px solid #ddd;border-radius:8px;overflow:hidden">
<img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='340' height='140'%3E%3Crect width='340' height='140' fill='%232f5af0'/%3E%3Ctext x='170' y='80' font-size='16' fill='white' text-anchor='middle' font-family='sans-serif'%3Efluid image%3C/text%3E%3C/svg%3E" style="max-width:100%;height:auto;display:block" alt="Responsive image example">
</div>` },
      { t: 'callout', type: 'good', title: 'Add this to every project',
        text: 'A global <code>img { max-width: 100%; height: auto; }</code> rule prevents almost every image overflow problem.' },
      { t: 'quiz', q: 'Which CSS makes an image never wider than its container?', options: ['width: 100%', 'max-width: 100%', 'height: 100%', 'display: inline'], answer: 1,
        explanation: '<code>max-width: 100%</code> lets the image shrink to fit but never exceed its container, keeping the aspect ratio with height:auto.' }
    ]
  });

  Curriculum.addLesson({
    id: 'responsive-nav',
    module: 'Module 8 — Responsive Design',
    title: 'Responsive Navigation',
    summary: 'Build a nav that becomes a hamburger menu on mobile.',
    keywords: ['responsive nav', 'hamburger', 'menu', 'toggle', 'mobile nav'],
    objectives: [
      'Build a nav that works on all screens',
      'Hide the full menu on mobile',
      'Show a hamburger button on mobile',
      'Toggle the menu with a small script'
    ],
    blocks: [
      { t: 'lead', text: 'Navigation is the hardest part of responsive design. A full menu that fits on desktop must collapse into a compact hamburger menu on phones.' },
      { t: 'h3', text: 'The approach' },
      { t: 'list', items: [
        'Build the nav with links inside <code>&lt;nav&gt;</code>.',
        'On desktop, show the links in a row.',
        'On mobile, hide the links and show a hamburger button.',
        'Clicking the button toggles the menu (a little JavaScript).'
      ] },
      { t: 'code', lang: 'css', caption: 'Show/hide with media queries', code: `/* Desktop: show links, hide hamburger */
.nav-links { display: flex; gap: 16px; }
.menu-btn { display: none; }

/* Mobile: hide links, show hamburger */
@media (max-width: 768px) {
  .nav-links { display: none; flex-direction: column; }
  .menu-btn { display: block; }
  .nav-links.open { display: flex; }
}` },
      { t: 'code', lang: 'html', caption: 'The HTML', code: `<nav>
  <button class="menu-btn" aria-label="Toggle menu">☰</button>
  <div class="nav-links">
    <a href="#">Home</a>
    <a href="#">About</a>
  </div>
</nav>` },
      { t: 'code', lang: 'js', caption: 'Toggle with JavaScript', code: `const btn = document.querySelector('.menu-btn');
const links = document.querySelector('.nav-links');
btn.addEventListener('click', () => {
  links.classList.toggle('open');
});` },
      { t: 'demo', title: 'Responsive nav demo', html: `<nav style="font-family:sans-serif;background:#1c2433;padding:12px 18px;border-radius:8px;display:flex;align-items:center;gap:16px">
<span style="color:#fff;font-weight:700">MySite</span>
<div style="display:flex;gap:16px;margin-left:auto">
<a href="#" style="color:#fff;text-decoration:none">Home</a>
<a href="#" style="color:#cdd6e8;text-decoration:none">About</a>
<a href="#" style="color:#cdd6e8;text-decoration:none">Contact</a>
</div>
</nav>` },
      { t: 'callout', type: 'tip', title: 'Why this matters',
        text: 'This exact pattern powers most real websites. You will build your own mobile menu later in this course and on the capstone project.' },
      { t: 'quiz', q: 'On mobile, a common pattern is to:', options: ['Show all links at once', 'Hide links and show a hamburger button', 'Remove navigation entirely', 'Scale down the whole nav'], answer: 1,
        explanation: 'On small screens the full link list is hidden behind a hamburger button, toggled open by the user.' }
    ]
  });

  /* ============ MODULE 9 — EFFECTS ============ */

  Curriculum.addLesson({
    id: 'css-hover',
    module: 'Module 9 — Effects',
    title: 'Hover Effects',
    summary: 'React to the mouse with the :hover pseudo-class and active/focus states.',
    keywords: ['hover', 'pseudo-class', 'active', 'focus', 'hover effect', ':hover'],
    objectives: [
      'Use the :hover pseudo-class',
      'Style active and focus states',
      'Combine hover with color changes',
      'Understand that hover is not available on touch'
    ],
    blocks: [
      { t: 'lead', text: 'Hover effects respond when the mouse is over an element. They make interfaces feel alive and interactive.' },
      { t: 'code', lang: 'css', caption: 'A hover effect', code: `.btn {
  background: #2f5af0;
  color: white;
}
.btn:hover {
  background: #2048cf;   /* darker on hover */
  transform: translateY(-2px);
}` },
      { t: 'h3', text: 'Other interactive states' },
      { t: 'list', items: [
        '<code>:active</code> — while the element is being pressed (mouse down).',
        '<code>:focus</code> — when focused (keyboard tab or click).',
        '<code>:visited</code> — for links the user already visited.'
      ] },
      { t: 'code', lang: 'css', caption: 'Multiple states', code: `a {
  color: #2f5af0;
}
a:hover { color: #2048cf; }
a:active { color: #e5484d; }
a:focus-visible { outline: 3px solid #2f5af0; }` },
      { t: 'demo', title: 'Hover me', html: `<div style="font-family:sans-serif;text-align:center">
<button style="background:#2f5af0;color:#fff;border:none;padding:12px 22px;border-radius:8px;font-size:16px;cursor:pointer;transition:background .2s,transform .2s" onmouseover="this.style.background='#2048cf';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='#2f5af0';this.style.transform='none'">Hover over me</button>
</div>` },
      { t: 'callout', type: 'warn', title: 'Touch devices',
        text: 'There is no hover on touchscreens. Never make crucial functionality depend on hover alone — always ensure taps and keyboard still work.' },
      { t: 'quiz', q: 'Which pseudo-class styles an element while the mouse is over it?', options: [':active', ':hover', ':focus', ':link'], answer: 1,
        explanation: '<code>:hover</code> matches when the pointer is over the element. :active is while pressing, :focus when focused.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-transitions',
    module: 'Module 9 — Effects',
    title: 'Transitions',
    summary: 'Animate property changes smoothly with transition.',
    keywords: ['transition', 'transition-property', 'ease', 'smooth', 'duration'],
    objectives: [
      'Smoothly animate changes with transition',
      'Set property, duration and easing',
      'Transition multiple properties',
      'Use the transition shorthand'
    ],
    blocks: [
      { t: 'lead', text: 'Without transitions, style changes happen instantly. <code>transition</code> makes them glide smoothly over a short time.' },
      { t: 'code', lang: 'css', caption: 'A smooth hover', code: `.card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}` },
      { t: 'h3', text: 'The shorthand' },
      { t: 'code', lang: 'css', caption: 'transition: property duration timing', code: `/* shorthand: property, duration, timing function */
transition: background-color 0.2s ease-in;

/* multiple properties */
transition: color 0.2s, background-color 0.3s;

/* transition everything */
transition: all 0.3s ease;` },
      { t: 'list', items: [
        '<strong>property</strong> — what to animate (<code>all</code>, <code>background-color</code>, <code>transform</code>).',
        '<strong>duration</strong> — how long (e.g. <code>0.3s</code>).',
        '<strong>timing function</strong> — <code>ease</code>, <code>linear</code>, <code>ease-in</code>, <code>ease-out</code>.'
      ] },
      { t: 'demo', title: 'Transition demo', html: `<div style="font-family:sans-serif;text-align:center">
<div style="width:120px;height:60px;background:#2f5af0;border-radius:8px;transition:width .4s ease, background .4s;margin:0 auto;display:grid;place-items:color;color:#fff" onmouseover="this.style.width='200px';this.style.background='#00b386'" onmouseout="this.style.width='120px';this.style.background='#2f5af0'">Hover me</div>
</div>` },
      { t: 'callout', type: 'tip', title: 'Keep it subtle',
        text: 'Short, gentle transitions (0.15s–0.4s) feel polished. Very long or bouncy transitions can feel slow and annoying.' },
      { t: 'quiz', q: 'In transition: transform 0.3s ease, what does ease control?', options: ['Duration', 'Property', 'Timing function', 'Delay'], answer: 2,
        explanation: 'ease is the timing function — how the animation speeds up and slows down over the duration.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-transform',
    module: 'Module 9 — Effects',
    title: 'Transform',
    summary: 'Move, scale, rotate and skew elements with transform.',
    keywords: ['transform', 'translate', 'scale', 'rotate', 'skew', 'transform-origin'],
    objectives: [
      'Move elements with translate',
      'Scale elements with scale',
      'Rotate with rotate',
      'Combine transforms'
    ],
    blocks: [
      { t: 'lead', text: '<code>transform</code> lets you move, resize, rotate and tilt elements without affecting the layout around them.' },
      { t: 'code', lang: 'css', caption: 'Transform functions', code: `.moved  { transform: translateX(20px); }
.scaled { transform: scale(1.2); }
.rotated{ transform: rotate(45deg); }
.skewed { transform: skew(10deg); }

/* combine several */
.fancy  { transform: translate(10px, 20px) scale(1.1) rotate(5deg); }` },
      { t: 'table', head: ['Function', 'What it does'], rows: [
        ['<code>translate(x, y)</code>', 'Moves the element'],
        ['<code>scale(n)</code>', 'Resizes (1 = original)'],
        ['<code>rotate(deg)</code>', 'Rotates around its center'],
        ['<code>skew(deg)</code>', 'Slants the element']
      ] },
      { t: 'demo', title: 'Transform demo', html: `<div style="font-family:sans-serif;display:flex;gap:20px;justify-content:center;flex-wrap:wrap">
<div style="width:90px;height:90px;background:#2f5af0;border-radius:8px;display:grid;place-items:center;color:#fff;transform:scale(1.1)">scale</div>
<div style="width:90px;height:90px;background:#00b386;border-radius:8px;display:grid;place-items:center;color:#fff;transform:rotate(12deg)">rotate</div>
<div style="width:90px;height:90px;background:#e5484d;border-radius:8px;display:grid;place-items:center;color:#fff;transform:translate(6px,8px)">translate</div>
</div>` },
      { t: 'callout', type: 'good', title: 'Performance',
        text: 'Transforms (and opacity) are GPU-accelerated, so animating them is smoother and more performant than animating width or margins.' },
      { t: 'quiz', q: 'Which transform scales an element up to 150%?', options: ['transform: rotate(1.5)', 'transform: scale(1.5)', 'transform: translate(1.5)', 'transform: size(1.5)'], answer: 1,
        explanation: '<code>scale(1.5)</code> makes the element 1.5 times its original size. rotate turns it, translate moves it.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-animations',
    module: 'Module 9 — Effects',
    title: 'Animations',
    summary: 'Create keyframe animations with @keyframes and animation properties.',
    keywords: ['animation', 'keyframes', 'animate', 'from', 'to', 'infinite', 'animation-name'],
    objectives: [
      'Define a keyframe animation',
      'Apply it with the animation property',
      'Control duration, iteration and delay',
      'Combine animation with hover'
    ],
    blocks: [
      { t: 'lead', text: 'While transitions animate a change, <strong>animations</strong> play a sequence of frames you define — great for attention and motion.' },
      { t: 'code', lang: 'css', caption: 'A bounce animation', code: `@keyframes bounce {
  0%   { transform: translateY(0); }
  50%  { transform: translateY(-20px); }
  100% { transform: translateY(0); }
}

.ball {
  animation: bounce 1s ease infinite;
}` },
      { t: 'h3', text: 'The animation shorthand' },
      { t: 'code', lang: 'css', caption: 'animation: name duration timing iteration', code: `.pulse {
  animation: pulse 2s ease-in-out infinite;
}` },
      { t: 'list', items: [
        '<code>animation-name</code> — which @keyframes to use.',
        '<code>animation-duration</code> — how long one cycle lasts.',
        '<code>animation-iteration-count</code> — <code>infinite</code> or a number.',
        '<code>animation-delay</code> — wait before starting.',
        '<code>animation-fill-mode</code> — state before/after (forwards, backwards).'
      ] },
      { t: 'demo', title: 'Pulsing animation', html: `<div style="font-family:sans-serif;text-align:center">
<div style="width:70px;height:70px;background:#00b386;border-radius:50%;margin:0 auto;display:grid;place-items:center;color:#fff;animation:pulse 1.6s ease-in-out infinite" id="pulseBall">&#9650;</div>
<style>@keyframes pulse {0%{transform:scale(1);opacity:1}50%{transform:scale(1.25);opacity:.7}100%{transform:scale(1);opacity:1}}</style>
</div>` },
      { t: 'callout', type: 'warn', title: 'Use motion wisely',
        text: 'Animations are eye-catching but can distract or even cause discomfort. Prefer subtle motion, avoid constant flashing, and respect users who prefer reduced motion.' },
      { t: 'quiz', q: 'Which property sets how many times an animation runs?', options: ['animation-duration', 'animation-iteration-count', 'animation-delay', 'animation-name'], answer: 1,
        explanation: '<code>animation-iteration-count</code> controls repetitions — use infinite to loop forever or a number for a set count.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-shadows',
    module: 'Module 9 — Effects',
    title: 'Shadows & Elevation',
    summary: 'Add depth with box-shadow and text-shadow.',
    keywords: ['box-shadow', 'text-shadow', 'shadow', 'blur', 'offset', 'elevation'],
    objectives: [
      'Add box shadows for depth',
      'Understand shadow offset, blur and color',
      'Create soft and strong shadows',
      'Add text shadows'
    ],
    blocks: [
      { t: 'lead', text: 'Shadows create a sense of depth and elevation, making elements feel raised off the page.' },
      { t: 'code', lang: 'css', caption: 'Box shadow', code: `.card {
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}` },
      { t: 'p', text: 'The values: <strong>horizontal offset, vertical offset, blur, color</strong>.' },
      { t: 'code', lang: 'css', caption: 'Variations', code: `/* soft elevation */
box-shadow: 0 8px 20px rgba(0,0,0,0.1);

/* stronger shadow */
box-shadow: 0 20px 40px rgba(0,0,0,0.25);

/* text shadow */
text-shadow: 2px 2px 4px rgba(0,0,0,0.4);` },
      { t: 'demo', title: 'Shadow demo', html: `<div style="font-family:sans-serif;display:flex;gap:20px;justify-content:center;flex-wrap:wrap;padding:20px">
<div style="width:110px;height:110px;background:#fff;border-radius:12px;box-shadow:0 4px 10px rgba(0,0,0,0.12);display:grid;place-items:center">Light</div>
<div style="width:110px;height:110px;background:#fff;border-radius:12px;box-shadow:0 18px 36px rgba(0,0,0,0.22);display:grid;place-items:center">Strong</div>
</div>` },
      { t: 'callout', type: 'tip', title: 'Use the browser devtools',
        text: 'In DevTools you can click the box-shadow icon to drag and tweak shadows visually — a fast way to learn how the values work.' },
      { t: 'quiz', q: 'In box-shadow: 0 4px 10px rgba(0,0,0,0.15), the value 4px is the:', options: ['Horizontal offset', 'Vertical offset', 'Blur radius', 'Color'], answer: 1,
        explanation: 'The order is horizontal offset, vertical offset, blur, color. So 4px is the vertical offset pushing the shadow down.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-gradients',
    module: 'Module 9 — Effects',
    title: 'Gradients',
    summary: 'Blend colors smoothly with linear and radial gradients.',
    keywords: ['gradient', 'linear-gradient', 'radial-gradient', 'background-image', 'smooth color'],
    objectives: [
      'Create linear gradients',
      'Control direction and color stops',
      'Use radial gradients',
      'Apply gradients as backgrounds'
    ],
    blocks: [
      { t: 'lead', text: 'A <strong>gradient</strong> is a smooth transition between colors. You can use them anywhere you use a background color.' },
      { t: 'code', lang: 'css', caption: 'Linear gradient', code: `.hero {
  background: linear-gradient(135deg, #2f5af0, #00b386);
}` },
      { t: 'p', text: 'The first value is the direction (<code>to right</code>, <code>to bottom</code>, or an angle like <code>135deg</code>), followed by the colours.' },
      { t: 'code', lang: 'css', caption: 'More gradient examples', code: `/* left to right, three colors */
background: linear-gradient(to right, red, orange, yellow);

/* radial: from the center */
background: radial-gradient(circle, white, blue);` },
      { t: 'demo', title: 'Gradient demo', html: `<div style="font-family:sans-serif;display:grid;gap:12px">
<div style="background:linear-gradient(90deg,#2f5af0,#00b386);color:#fff;padding:20px;border-radius:10px">Linear gradient</div>
<div style="background:radial-gradient(circle at top,#ffe6a3,#ff8f6b);padding:20px;border-radius:10px">Radial gradient</div>
</div>` },
      { t: 'callout', type: 'good', title: 'Creative use',
        text: 'Gradients are great for hero sections, buttons and subtle text accents. Combine with a fallback <code>background-color</code> for older browsers.' },
      { t: 'quiz', q: 'Gradients are set using which CSS property?', options: ['background-color', 'background-image', 'color', 'gradient'], answer: 1,
        explanation: 'Gradients are applied through <code>background-image</code> (e.g. linear-gradient(...)), not background-color.' }
    ]
  });

})();
