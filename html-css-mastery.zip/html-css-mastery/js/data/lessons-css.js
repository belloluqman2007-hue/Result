/* =========================================================
   HTML & CSS MASTERY — lessons-css.js
   Module 5 (CSS Fundamentals) — Module 6 (Box Model)
   ========================================================= */

(function () {

  /* ============ MODULE 5 — CSS FUNDAMENTALS ============ */

  Curriculum.addLesson({
    id: 'what-is-css',
    module: 'Module 5 — CSS Fundamentals',
    title: 'What Is CSS?',
    summary: 'Understand CSS and the three ways to add it: inline, internal and external.',
    keywords: ['css', 'styles', 'stylesheet', 'link', 'style', 'cascading'],
    objectives: [
      'Define CSS and what it does',
      'Know the three ways to add CSS',
      'Use the external stylesheet (recommended)',
      'Understand why separating style from content is good'
    ],
    blocks: [
      { t: 'lead', text: '<strong>CSS</strong> stands for <strong>Cascading Style Sheets</strong>. It controls how your HTML looks — colours, sizes, spacing, layout and animations.' },
      { t: 'p', text: 'CSS works alongside HTML: HTML gives structure, CSS gives style. With the same HTML, you can create completely different looks just by changing the CSS.' },
      { t: 'h3', text: 'Three ways to add CSS' },
      { t: 'table', head: ['Method', 'Where', 'Best for'], rows: [
        ['Inline', '<code>style</code> attribute on an element', 'Rarely — hard to reuse'],
        ['Internal', '<code>&lt;style&gt;</code> in the <code>&lt;head&gt;</code>', 'Single-page styles'],
        ['External', 'A separate <code>.css</code> file linked with <code>&lt;link&gt;</code>', 'Most websites — recommended']
      ] },
      { t: 'code', lang: 'html', caption: 'Linking an external stylesheet', code: `<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h1>Hello</h1>
  </body>
</html>` },
      { t: 'code', lang: 'html', caption: 'Inline vs internal (avoid these mostly)', code: `<!-- Inline -->
<p style="color: red;">Inline style</p>

<!-- Internal -->
<style>
  p { color: red; }
</style>` },
      { t: 'h3', text: 'Why external stylesheets win' },
      { t: 'list', items: [
        'One file styles your <strong>entire site</strong> — change one place, update everywhere.',
        'Keeps HTML clean and focused on content.',
        'Browsers can cache it, making pages load faster.',
        'Much easier to maintain and reuse.'
      ] },
      { t: 'demo', title: 'Same HTML, different CSS', html: `<div style="font-family:sans-serif;display:grid;grid-template-columns:1fr 1fr;gap:12px">
<div><h3 style="color:#2f5af0;font-size:20px">Styled blue</h3><p style="color:#666">A paragraph.</p></div>
<div style="background:#1c2433;padding:10px;border-radius:8px"><h3 style="color:#21d6a5;font-size:20px;margin:0 0 4px">Styled teal</h3><p style="color:#cdd6e8">A paragraph.</p></div>
</div>` },
      { t: 'quiz', q: 'Which method of adding CSS is recommended for most websites?', options: ['Inline', 'Internal', 'External stylesheet', 'JavaScript'], answer: 2,
        explanation: 'An external .css file linked via <link> is best — it is reusable, cached and keeps HTML clean.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-syntax',
    module: 'Module 5 — CSS Fundamentals',
    title: 'CSS Syntax',
    summary: 'Understand rules, selectors, properties and values.',
    keywords: ['css syntax', 'rule', 'selector', 'property', 'value', 'declaration', 'semicolon'],
    objectives: [
      'Read and write a CSS rule',
      'Understand selectors, properties and values',
      'Know that declarations end with a semicolon',
      'Understand the brace structure'
    ],
    blocks: [
      { t: 'lead', text: 'Every CSS rule follows the same pattern. Learn it once and you can read any CSS.' },
      { t: 'code', lang: 'css', caption: 'A CSS rule', code: `selector {
  property: value;
  property: value;
}` },
      { t: 'code', lang: 'css', caption: 'A real example', code: `h1 {
  color: blue;
  font-size: 32px;
}` },
      { t: 'list', items: [
        '<strong>Selector</strong> — which element(s) to style (<code>h1</code>).',
        '<strong>Property</strong> — the thing to change (<code>color</code>).',
        '<strong>Value</strong> — the new setting (<code>blue</code>).',
        'Each <code>property: value</code> pair is a <strong>declaration</strong>.',
        'Declarations end with a <code>;</code> (semicolon).'
      ] },
      { t: 'h3', text: 'Multiple properties' },
      { t: 'code', lang: 'css', caption: 'Styling a paragraph', code: `p {
  color: #333;
  font-size: 16px;
  line-height: 1.6;
  margin-bottom: 12px;
}` },
      { t: 'demo', title: 'See the effect', html: `<div style="font-family:sans-serif">
<p style="color:#333;font-size:16px;line-height:1.6;margin-bottom:12px">This paragraph is styled with several CSS properties.</p>
<p style="color:#2f5af0;font-weight:bold;font-size:18px">This one is bold and blue.</p>
</div>` },
      { t: 'callout', type: 'warn', title: 'Common mistakes',
        text: 'Forgetting the semicolon after a declaration, using an equals sign <code>color = blue</code> (wrong — use a colon), and forgetting the closing brace <code>}</code> are the most common errors.' },
      { t: 'quiz', q: 'Which part of a CSS rule says WHICH element to style?', options: ['Property', 'Value', 'Selector', 'Semicolon'], answer: 2,
        explanation: 'The selector targets the element(s) to style. The property:value pairs are the declarations that change the look.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-selectors',
    module: 'Module 5 — CSS Fundamentals',
    title: 'CSS Selectors',
    summary: 'Target elements with type, class, id, attribute and combinator selectors.',
    keywords: ['selector', 'class', 'id', 'attribute selector', 'descendant', 'universal', 'css selector'],
    objectives: [
      'Use type, class and id selectors',
      'Combine selectors with combinators',
      'Use attribute selectors',
      'Understand specificity basics'
    ],
    blocks: [
      { t: 'lead', text: 'Selectors are how you choose which elements to style. Mastering them is the key to writing effective CSS.' },
      { t: 'h3', text: 'The three most common selectors' },
      { t: 'code', lang: 'css', caption: 'Type, class and id', code: `/* Type selector — all <p> elements */
p { color: gray; }

/* Class selector — elements with class="intro" */
.intro { font-size: 18px; }

/* ID selector — the element with id="header */
#header { background: black; }` },
      { t: 'callout', type: 'tip', title: 'class vs id selector',
        text: 'Use <code>.class</code> for reusable styles (many elements). Use <code>#id</code> for a single unique element. Overusing IDs makes CSS hard to reuse.' },
      { t: 'h3', text: 'Combinators' },
      { t: 'code', lang: 'css', caption: 'Combining selectors', code: `/* Descendant: any <a> inside a <nav> */
nav a { color: white; }

/* Direct child only */
ul > li { list-style: none; }

/* Adjacent sibling */
h2 + p { font-weight: bold; }` },
      { t: 'h3', text: 'Attribute and universal selectors' },
      { t: 'code', lang: 'css', caption: 'More selectors', code: `/* All elements */
* { box-sizing: border-box; }

/* <input> of type text */
input[type="text"] { border: 1px solid gray; }

/* Links that open in new tab */
a[target="_blank"] { color: orange; }` },
      { t: 'demo', title: 'Selectors in action', html: `<div style="font-family:sans-serif">
<nav style="background:#1c2433;padding:10px 14px;border-radius:8px"><a href="#" style="color:#fff;margin-right:14px">Home</a><a href="#" style="color:#fff;margin-right:14px">About</a><a href="#" style="color:#fff">Contact</a></nav>
<p class="intro" style="color:#2f5af0;font-size:18px;font-weight:600">This paragraph uses class="intro".</p>
<input type="text" value="A text input" style="padding:8px;border:1px solid gray;border-radius:6px">
</div>` },
      { t: 'quiz', q: 'Which selector targets all elements with class="menu"?', options: ['#menu', '.menu', 'menu', '*menu'], answer: 1,
        explanation: 'A dot before the name — .menu — targets all elements with that class. #menu would target the id.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-colors',
    module: 'Module 5 — CSS Fundamentals',
    title: 'Colors',
    summary: 'Color your page with named colors, hex, rgb and rgba.',
    keywords: ['color', 'hex', 'rgb', 'rgba', 'named color', 'background-color', 'opacity'],
    objectives: [
      'Use the color property for text',
      'Understand hex, rgb and named colors',
      'Add transparency with rgba',
      'Use background-color'
    ],
    blocks: [
      { t: 'lead', text: 'Color brings your site to life. CSS supports several ways to write colors — all equally valid, so pick what feels clearest.' },
      { t: 'code', lang: 'css', caption: 'Ways to write colors', code: `.heading {
  color: red;              /* named color */
  color: #ff0000;          /* hex (6 digits) */
  color: #f00;             /* hex shorthand */
  color: rgb(255, 0, 0);   /* red, green, blue */
  color: rgba(255, 0, 0, 0.5); /* + transparency */
  color: hsl(0, 100%, 50%);     /* hue, sat, light */
}` },
      { t: 'h3', text: 'Understanding the formats' },
      { t: 'list', items: [
        '<strong>Named colors</strong> — like <code>red</code>, <code>tomato</code>, <code>royalblue</code>. Easy but limited (~140 names).',
        '<strong>Hex</strong> — <code>#RRGGBB</code>, pairs for red, green, blue. <code>#ffffff</code> is white, <code>#000000</code> is black.',
        '<strong>RGB</strong> — <code>rgb(255, 0, 0)</code>, values 0–255 per channel.',
        '<strong>RGBA</strong> — same as RGB plus alpha (transparency) from 0 to 1.'
      ] },
      { t: 'h3', text: 'Coloring backgrounds' },
      { t: 'code', lang: 'css', caption: 'Background color', code: `.banner {
  background-color: #2f5af0;
  color: white;
  padding: 20px;
}` },
      { t: 'demo', title: 'Color demo', html: `<div style="font-family:sans-serif;display:grid;gap:10px">
<div style="background:#ff0000;color:#fff;padding:12px;border-radius:8px">Named: red</div>
<div style="background:#2f5af0;color:#fff;padding:12px;border-radius:8px">Hex: #2f5af0</div>
<div style="background:rgba(0,179,134,0.6);padding:12px;border-radius:8px">rgba with transparency</div>
</div>` },
      { t: 'callout', type: 'good', title: 'Accessibility',
        text: 'Ensure enough <strong>contrast</strong> between text and background for readability. Dark text on a dark background (or light on light) is a common accessibility failure.' },
      { t: 'quiz', q: 'In hex color #00ff00, which channels are at maximum?', options: ['Red', 'Green', 'Blue', 'None'], answer: 1,
        explanation: '#00ff00 = red 00, green ff (255 = max), blue 00. So the green channel is at maximum — a pure green.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-backgrounds',
    module: 'Module 5 — CSS Fundamentals',
    title: 'Backgrounds',
    summary: 'Use background-color, background-image, background-size and more.',
    keywords: ['background', 'background-image', 'background-size', 'cover', 'background-repeat', 'gradient'],
    objectives: [
      'Set a background image',
      'Control repeat, position and size',
      'Use background-size: cover',
      'Combine properties with background shorthand'
    ],
    blocks: [
      { t: 'lead', text: 'Backgrounds decorate the area behind your content. You can use colours, images, or both.' },
      { t: 'code', lang: 'css', caption: 'Background image', code: `.hero {
  background-image: url("mountains.jpg");
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}` },
      { t: 'h3', text: 'Key background properties' },
      { t: 'table', head: ['Property', 'Purpose'], rows: [
        ['<code>background-color</code>', 'Solid background colour'],
        ['<code>background-image</code>', 'A background image'],
        ['<code>background-repeat</code>', 'no-repeat, repeat-x, repeat-y'],
        ['<code>background-position</code>', 'Where the image sits'],
        ['<code>background-size</code>', 'cover fills, contain fits']
      ] },
      { t: 'h3', text: 'Shorthand' },
      { t: 'code', lang: 'css', caption: 'Combining into one line', code: `.hero {
  background: #2f5af0 url("bg.jpg") center / cover no-repeat;
}` },
      { t: 'demo', title: 'Background demo', html: `<div style="font-family:sans-serif;padding:24px;border-radius:10px;color:#fff;background:linear-gradient(135deg,#2f5af0,#00b386)">
<h3 style="margin:0 0 6px;color:#fff">A gradient background</h3>
<p style="color:#fff;margin:0">background can even be a gradient — no image needed.</p>
</div>` },
      { t: 'callout', type: 'warn', title: 'Performance',
        text: 'Use <code>background-size: cover</code> with a fallback <code>background-color</code> so content stays readable while the image loads — or if it fails.' },
      { t: 'quiz', q: 'Which value makes a background image fill the whole area without distortion?', options: ['cover', 'contain', 'repeat', 'auto'], answer: 0,
        explanation: '<code>background-size: cover</code> scales the image to completely cover the container (may crop). contain fits it entirely but may leave gaps.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-fonts',
    module: 'Module 5 — CSS Fundamentals',
    title: 'Fonts',
    summary: 'Set font-family, size, weight and style, and use web-safe and Google fonts.',
    keywords: ['font', 'font-family', 'font-size', 'font-weight', 'google fonts', 'serif', 'sans-serif', 'line-height'],
    objectives: [
      'Change font family, size and weight',
      'Understand font stacks',
      'Use web-safe fonts',
      'Import fonts from Google Fonts'
    ],
    blocks: [
      { t: 'lead', text: 'Fonts set the personality and readability of your site. You control the family, size, weight and style of text.' },
      { t: 'code', lang: 'css', caption: 'Font properties', code: `body {
  font-family: 'Segoe UI', Tahoma, sans-serif;
  font-size: 16px;
  font-weight: 400;
  line-height: 1.6;
}` },
      { t: 'h3', text: 'Font stacks' },
      { t: 'p', text: 'List several fonts in order. The browser uses the first one available on the user\'s device. Always end with a generic family like <code>sans-serif</code> or <code>serif</code>.' },
      { t: 'code', lang: 'css', caption: 'Generic families', code: `.serif { font-family: Georgia, 'Times New Roman', serif; }
.sans   { font-family: Arial, Helvetica, sans-serif; }
.mono   { font-family: 'Courier New', monospace; }` },
      { t: 'h3', text: 'Google Fonts' },
      { t: 'p', text: 'For custom fonts, add a link in your <code>&lt;head&gt;</code> then use it in CSS.' },
      { t: 'code', lang: 'html', caption: 'Adding a Google Font', code: `<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">` },
      { t: 'code', lang: 'css', caption: 'Using it', code: `body {
  font-family: 'Roboto', sans-serif;
  font-weight: 700; /* bold */
}` },
      { t: 'demo', title: 'Font demo', html: `<div style="font-family:sans-serif;display:grid;gap:8px">
<p style="font-family:Georgia,serif;font-size:20px">Serif font</p>
<p style="font-family:Arial,sans-serif;font-size:20px">Sans-serif font</p>
<p style="font-family:monospace;font-size:20px">Monospace font</p>
</div>` },
      { t: 'callout', type: 'tip', title: 'Readability',
        text: 'For body text use a comfortable <code>font-size</code> (16px is a good baseline) and <code>line-height</code> around 1.5–1.7 for easy reading.' },
      { t: 'quiz', q: 'What is the purpose of a font stack like font-family: Arial, Helvetica, sans-serif?', options: ['To make text bolder', 'To provide fallback fonts', 'To animate text', 'To center text'], answer: 1,
        explanation: 'The browser tries the first font, then falls back through the list until one is available on the device.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-text',
    module: 'Module 5 — CSS Fundamentals',
    title: 'Text Styling',
    summary: 'Align, decorate, transform and space your text with CSS.',
    keywords: ['text-align', 'text-decoration', 'text-transform', 'letter-spacing', 'word-spacing', 'text-shadow', 'white-space'],
    objectives: [
      'Align text left, right, center or justify',
      'Decorate and transform text',
      'Space letters and lines',
      'Add text shadows'
    ],
    blocks: [
      { t: 'lead', text: 'Once your text is the right font, fine-tune its alignment, decoration and spacing to polish the design.' },
      { t: 'code', lang: 'css', caption: 'Text properties', code: `.title {
  text-align: center;        /* left, right, center, justify */
  text-transform: uppercase; /* lowercase, capitalize */
  text-decoration: underline;/* none, line-through */
  letter-spacing: 2px;       /* spacing between letters */
  line-height: 1.6;          /* spacing between lines */
}` },
      { t: 'table', head: ['Property', 'Common values'], rows: [
        ['<code>text-align</code>', 'left, center, right, justify'],
        ['<code>text-decoration</code>', 'none, underline, line-through'],
        ['<code>text-transform</code>', 'uppercase, lowercase, capitalize'],
        ['<code>letter-spacing</code>', 'any length (e.g. 2px)'],
        ['<code>text-shadow</code>', 'offset-x offset-y blur color'],
        ['<code>white-space</code>', 'normal, nowrap, pre']
      ] },
      { t: 'h3', text: 'Text shadow' },
      { t: 'code', lang: 'css', caption: 'Adding a shadow', code: `.title {
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}` },
      { t: 'p', text: 'The values are horizontal offset, vertical offset, blur radius, and colour.' },
      { t: 'demo', title: 'Text styling demo', html: `<div style="font-family:sans-serif;display:grid;gap:10px">
<p style="text-align:center;text-transform:uppercase;letter-spacing:3px;font-weight:700">Centered, uppercase</p>
<p style="text-decoration:underline">Underlined text</p>
<p style="text-shadow:2px 2px 4px rgba(47,90,240,0.5);font-size:22px;font-weight:700">Text with a shadow</p>
</div>` },
      { t: 'callout', type: 'good', title: 'Consistency',
        text: 'Use text-transform and letter-spacing for headings to create a polished, consistent feel without retyping content.' },
      { t: 'quiz', q: 'Which property removes the underline from links?', options: ['text-transform', 'text-decoration', 'text-align', 'white-space'], answer: 1,
        explanation: 'text-decoration: none; removes the underline. It is commonly applied to links to style them as buttons.' }
    ]
  });

  /* ============ MODULE 6 — BOX MODEL ============ */

  Curriculum.addLesson({
    id: 'box-model',
    module: 'Module 6 — Box Model',
    title: 'The Box Model: Content & Total Size',
    summary: 'Every element is a box made of content, padding, border and margin.',
    keywords: ['box model', 'content', 'padding', 'border', 'margin', 'element box'],
    objectives: [
      'Understand that every element is a box',
      'Identify the four layers of the box model',
      'Understand how box model affects layout',
      'Calculate total element size'
    ],
    blocks: [
      { t: 'lead', text: 'The <strong>box model</strong> is the most important idea in CSS layout. Every element on the page is a rectangular box with four layers.' },
      { t: 'p', text: 'From the inside out, a box is made of:' },
      { t: 'table', head: ['Layer', 'What it is'], rows: [
        ['<strong>Content</strong>', 'The actual text or image'],
        ['<strong>Padding</strong>', 'Space between content and border'],
        ['<strong>Border</strong>', 'The edge drawn around the padding'],
        ['<strong>Margin</strong>', 'Space outside the border, pushing other elements away']
      ] },
      { t: 'demo', title: 'Box model visualised', html: `<div style="font-family:sans-serif;background:#f3f4f7;padding:24px;border-radius:10px;text-align:center">
<div style="margin:16px;border:4px dashed #e5484d;padding:16px;background:#fff;border-radius:6px">
<div style="border:2px solid #00b386;padding:16px;background:#e3f6ee;border-radius:6px;text-align:center"><strong>CONTENT</strong></div>
</div>
</div>` },
      { t: 'h3', text: 'How big is the box really?' },
      { t: 'p', text: 'By default, <code>width</code> refers to the <em>content</em> only. The space an element actually takes up adds padding and border too:' },
      { t: 'code', lang: 'css', caption: 'Box with padding and border', code: `.box {
  width: 200px;        /* content width */
  padding: 20px;       /* 20 on every side */
  border: 5px solid black;
  /* real width = 200 + 20+20 + 5+5 = 250px */
}` },
      { t: 'callout', type: 'warn', title: 'Common surprise',
        text: 'A common beginner shock: setting <code>width: 200px</code> but the element looks wider because padding and border are added on top. That is why <code>box-sizing: border-box</code> (next lesson) is so popular.' },
      { t: 'quiz', q: 'Which box-model layer is OUTSIDE the border?', options: ['Content', 'Padding', 'Margin', 'Border'], answer: 2,
        explanation: 'Margin is the outermost layer, creating space between the element and surrounding elements.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-padding',
    module: 'Module 6 — Box Model',
    title: 'Padding',
    summary: 'Add space inside the border with padding and its shorthands.',
    keywords: ['padding', 'padding-top', 'padding shorthand', 'space'],
    objectives: [
      'Add padding with individual sides',
      'Use the padding shorthand',
      'Understand the 1-4 value shorthand rules',
      'Use padding for comfortable spacing'
    ],
    blocks: [
      { t: 'lead', text: 'Padding adds space <em>inside</em> an element, between the content and the border. It makes content less cramped.' },
      { t: 'code', lang: 'css', caption: 'Padding on each side', code: `.box {
  padding-top: 10px;
  padding-right: 20px;
  padding-bottom: 10px;
  padding-left: 20px;
}` },
      { t: 'h3', text: 'The shorthand' },
      { t: 'code', lang: 'css', caption: 'Padding shorthand (1-4 values)', code: `/* 1 value: all sides */
padding: 10px;

/* 2 values: top/bottom, left/right */
padding: 10px 20px;

/* 3 values: top, left/right, bottom */
padding: 10px 20px 5px;

/* 4 values: top, right, bottom, left (clockwise) */
padding: 10px 20px 5px 30px;` },
      { t: 'callout', type: 'tip', title: 'Remember the order',
        text: 'The 4-value order is clockwise starting at the top: <strong>top, right, bottom, left</strong>. A handy mnemonic: "Trouble Right, Be Left."' },
      { t: 'demo', title: 'Padding demo', html: `<div style="font-family:sans-serif;display:grid;gap:12px">
<div style="padding:8px;background:#eef2ff;border:2px solid #2f5af0;border-radius:6px">Small padding (8px)</div>
<div style="padding:32px;background:#eef2ff;border:2px solid #2f5af0;border-radius:6px">Large padding (32px) — more breathing room</div>
</div>` },
      { t: 'quiz', q: 'padding: 10px 20px; sets:', options: ['All sides 10px', 'Top/bottom 10px, left/right 20px', 'Top/right 10px, bottom/left 20px', 'Only top and bottom'], answer: 1,
        explanation: 'Two values apply the first to top and bottom, and the second to left and right.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-border',
    module: 'Module 6 — Box Model',
    title: 'Borders',
    summary: 'Draw borders with style, width, color and radius.',
    keywords: ['border', 'border-radius', 'border-width', 'border-style', 'border-color'],
    objectives: [
      'Set border width, style and color',
      'Use the border shorthand',
      'Round corners with border-radius',
      'Create a circle with border-radius: 50%'
    ],
    blocks: [
      { t: 'lead', text: 'Borders outline an element. They need a <strong>style</strong> to show at all — the default is <code>none</code>.' },
      { t: 'code', lang: 'css', caption: 'Border shorthand', code: `.box {
  border: 2px solid #2f5af0;
}` },
      { t: 'list', items: [
        '<strong>Width</strong> — how thick (e.g. <code>2px</code>).',
        '<strong>Style</strong> — <code>solid</code>, <code>dashed</code>, <code>dotted</code>, <code>none</code>.',
        '<strong>Color</strong> — any colour.'
      ] },
      { t: 'h3', text: 'Rounded corners' },
      { t: 'code', lang: 'css', caption: 'Border radius', code: `.box {
  border-radius: 12px;      /* rounded corners */
}

.avatar {
  border-radius: 50%;       /* perfect circle */
}` },
      { t: 'demo', title: 'Border styles', html: `<div style="font-family:sans-serif;display:flex;gap:12px;flex-wrap:wrap">
<div style="border:3px solid #2f5af0;padding:14px;border-radius:8px">Solid</div>
<div style="border:3px dashed #e5484d;padding:14px;border-radius:8px">Dashed</div>
<div style="border:3px dotted #00b386;padding:14px;border-radius:50%;width:90px;height:90px;display:grid;place-items:center">Circle</div>
</div>` },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'Setting <code>border-color</code> or <code>border-width</code> without a <code>border-style</code> does nothing — no style means no border.' },
      { t: 'quiz', q: 'What happens if you set border-width and border-color but no border-style?', options: ['A solid border', 'No border shows', 'A dashed border', 'The element breaks'], answer: 1,
        explanation: 'Without a border-style (default none), no border is drawn — the width and color are ignored.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-margin',
    module: 'Module 6 — Box Model',
    title: 'Margin',
    summary: 'Space elements apart with margin, and understand margin collapse.',
    keywords: ['margin', 'margin-top', 'margin auto', 'center', 'margin collapse', 'space outside'],
    objectives: [
      'Add space between elements with margin',
      'Use margin auto to center',
      'Understand negative margins',
      'Understand margin collapsing'
    ],
    blocks: [
      { t: 'lead', text: 'Margin adds space <em>outside</em> an element, pushing it away from its neighbours.' },
      { t: 'code', lang: 'css', caption: 'Margin', code: `.box {
  margin: 20px;            /* all sides */
  margin: 20px 0;          /* top/bottom only */
  margin-top: 10px;
  margin-bottom: 30px;
}` },
      { t: 'h3', text: 'Centering with margin auto' },
      { t: 'p', text: 'To center a block element horizontally, give it a width and <code>margin: 0 auto</code>.' },
      { t: 'code', lang: 'css', caption: 'Center a block', code: `.card {
  width: 400px;
  margin: 0 auto;   /* left & right auto = centered */
}` },
      { t: 'h3', text: 'Margin collapsing' },
      { t: 'p', text: 'Vertical margins of adjacent elements can <strong>collapse</strong> — instead of adding, the browser uses the larger of the two. Horizontal margins never collapse.' },
      { t: 'demo', title: 'Margin vs padding', html: `<div style="font-family:sans-serif;display:grid;gap:8px">
<div style="background:#ffe3e4;padding:14px;border-radius:8px"><strong>Margin</strong> — space outside this box</div>
<div style="background:#e3f6ee;padding:14px;border-radius:8px;margin-top:20px"><strong>Gap of 20px</strong> between the boxes from margin</div>
</div>` },
      { t: 'callout', type: 'tip', title: 'margin vs padding',
        text: 'Use <strong>margin</strong> to create space <em>between</em> elements, and <strong>padding</strong> to create space <em>inside</em> an element around its content.' },
      { t: 'quiz', q: 'Which margin setting centers a block element horizontally?', options: ['margin: 0 auto', 'margin: center', 'margin: 50%', 'margin: auto 0'], answer: 0,
        explanation: 'margin: 0 auto; with a defined width centers the element horizontally — the auto values share leftover space equally.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-box-sizing',
    module: 'Module 6 — Box Model',
    title: 'Box Sizing',
    summary: 'Use box-sizing: border-box so width includes padding and border.',
    keywords: ['box-sizing', 'border-box', 'content-box', 'sizing', 'width'],
    objectives: [
      'Understand content-box vs border-box',
      'Use box-sizing: border-box',
      'Apply it globally to all elements',
      'Know why developers use it everywhere'
    ],
    blocks: [
      { t: 'lead', text: 'Remember how padding and border add to the width? <code>box-sizing: border-box</code> fixes that surprise.' },
      { t: 'code', lang: 'css', caption: 'The fix', code: `.box {
  box-sizing: border-box;
  width: 200px;
  padding: 20px;
  border: 5px solid black;
  /* real width = 200px (padding and border included) */
}` },
      { t: 'list', items: [
        '<strong>content-box</strong> (default) — width excludes padding/border.',
        '<strong>border-box</strong> — width includes padding and border.'
      ] },
      { t: 'h3', text: 'Apply it globally' },
      { t: 'p', text: 'It is extremely common to apply <code>border-box</code> to everything so sizing is predictable:' },
      { t: 'code', lang: 'css', caption: 'Global reset', code: `*,
*::before,
*::after {
  box-sizing: border-box;
}` },
      { t: 'demo', title: 'content-box vs border-box', html: `<div style="font-family:sans-serif;display:grid;grid-template-columns:1fr 1fr;gap:12px">
<div style="width:150px;padding:10px;border:5px solid #2f5af0;background:#eef2ff;border-radius:6px;box-sizing:content-box"><strong>content-box</strong><br>total 180px</div>
<div style="width:150px;padding:10px;border:5px solid #00b386;background:#e3f6ee;border-radius:6px;box-sizing:border-box"><strong>border-box</strong><br>total 150px</div>
</div>` },
      { t: 'callout', type: 'good', title: 'Best practice',
        text: 'Add the global border-box reset to every project. It makes layout far more predictable and is used on virtually all real websites.' },
      { t: 'quiz', q: 'With box-sizing: border-box, does the width include padding and border?', options: ['No', 'Yes', 'Only border', 'Only padding'], answer: 1,
        explanation: 'Yes — border-box makes the declared width include both padding and border, so total width matches what you set.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-width-height',
    module: 'Module 6 — Box Model',
    title: 'Width & Height',
    summary: 'Set sizes with width, height, max-width, min-height and auto.',
    keywords: ['width', 'height', 'max-width', 'min-height', 'auto', 'vh', 'vw'],
    objectives: [
      'Set element width and height',
      'Use max-width for responsive layouts',
      'Use min/max constraints',
      'Understand units like %, vw and vh'
    ],
    blocks: [
      { t: 'lead', text: 'Controlling the size of boxes is central to layout. Width and height can be fixed or flexible.' },
      { t: 'code', lang: 'css', caption: 'Setting sizes', code: `.box {
  width: 300px;
  height: 100px;
}

.container {
  max-width: 960px;   /* never wider than 960px */
  width: 100%;        /* but fills smaller screens */
}` },
      { t: 'h3', text: 'Units' },
      { t: 'table', head: ['Unit', 'Meaning'], rows: [
        ['<code>px</code>', 'Pixels — fixed size'],
        ['<code>%</code>', 'Percentage of the parent'],
        ['<code>em</code>', 'Relative to the element\'s font-size'],
        ['<code>rem</code>', 'Relative to the root font-size'],
        ['<code>vw</code>', '1% of the viewport width'],
        ['<code>vh</code>', '1% of the viewport height']
      ] },
      { t: 'h3', text: 'max-width for responsiveness' },
      { t: 'p', text: 'Using <code>max-width</code> with <code>width: 100%</code> lets content fill small screens but stop growing on large ones — a simple responsive technique.' },
      { t: 'demo', title: 'Width demo', html: `<div style="font-family:sans-serif;display:grid;gap:8px">
<div style="max-width:300px;width:100%;background:#eef2ff;border:2px solid #2f5af0;padding:10px;border-radius:6px">max-width 300px — fills up to that</div>
<div style="width:50%;background:#e3f6ee;border:2px solid #00b386;padding:10px;border-radius:6px">width 50% — half the parent</div>
</div>` },
      { t: 'callout', type: 'warn', title: 'Common mistake',
        text: 'Setting a fixed height and stuffing more content inside causes overflow. Prefer <code>min-height</code> when content may grow.' },
      { t: 'quiz', q: '1% of the viewport WIDTH is which unit?', options: ['vh', 'rem', 'vw', 'em'], answer: 2,
        explanation: '<code>vw</code> (viewport width) equals 1% of the viewport width. vh is 1% of viewport height.' }
    ]
  });

})();
