/* =========================================================
   HTML & CSS MASTERY — lessons-practice.js
   Module 10 (CSS Deep Dive) — units, specificity, cascade,
   inheritance, debugging, best practices.
   ========================================================= */

(function () {

  Curriculum.addLesson({
    id: 'css-units',
    module: 'Module 10 — CSS Deep Dive',
    title: 'CSS Units',
    summary: 'Choose the right unit for each job: px, rem, em, %, vw and vh.',
    keywords: ['units', 'px', 'rem', 'em', 'percent', 'vw', 'vh', 'ch', 'relative units'],
    objectives: [
      'Know absolute vs relative units',
      'Use rem for scalable sizing',
      'Understand em vs rem',
      'Use vw, vh and percentages for layout'
    ],
    blocks: [
      { t: 'lead', text: 'CSS values need units. Some are fixed (absolute), others scale with the environment (relative). Choosing well makes your site flexible and accessible.' },
      { t: 'table', head: ['Unit', 'Type', 'Based on'], rows: [
        ['<code>px</code>', 'Absolute', 'A screen pixel — fixed'],
        ['<code>rem</code>', 'Relative', 'Root (html) font-size'],
        ['<code>em</code>', 'Relative', 'The element\'s own font-size'],
        ['<code>%</code>', 'Relative', 'The parent element'],
        ['<code>vw</code>', 'Relative', 'Viewport width'],
        ['<code>vh</code>', 'Relative', 'Viewport height']
      ] },
      { t: 'h3', text: 'rem vs em' },
      { t: 'p', text: '<code>rem</code> is relative to the root <code>&lt;html&gt;</code> font-size (usually 16px), so it is stable everywhere. <code>em</code> is relative to the current element\'s font-size, so it can compound — which often surprises developers.' },
      { t: 'code', lang: 'css', caption: 'Using rem', code: `html { font-size: 16px; }

h1 { font-size: 2rem; }  /* 32px */
p  { font-size: 1rem; }  /* 16px */
.box { padding: 1.5rem; } /* 24px */` },
      { t: 'callout', type: 'good', title: 'Why rem is popular',
        text: 'Because rem scales with the root, if a user increases their browser font size, rem-based designs scale up too — great for accessibility. Many developers use rem for font sizes and px for borders.' },
      { t: 'demo', title: 'Unit sizes', html: `<div style="font-family:sans-serif;font-size:16px">
<p style="font-size:1rem;margin:4px 0">1rem = 16px</p>
<p style="font-size:1.5rem;margin:4px 0">1.5rem = 24px</p>
<p style="font-size:2rem;margin:4px 0">2rem = 32px</p>
</div>` },
      { t: 'quiz', q: 'rem units are relative to:', options: ['The parent element', 'The root html font-size', 'The viewport', 'The current element only'], answer: 1,
        explanation: 'rem is relative to the root <html> font-size, so it is consistent regardless of where the element sits.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-specificity',
    module: 'Module 10 — CSS Deep Dive',
    title: 'Specificity',
    summary: 'Understand which CSS rule wins when several target the same element.',
    keywords: ['specificity', 'cascade', 'id', 'class', 'inline', '!important', 'priority'],
    objectives: [
      'Understand why some rules win over others',
      'Know the specificity ranking',
      'Predict which style applies',
      'Avoid !important'
    ],
    blocks: [
      { t: 'lead', text: 'When two CSS rules target the same element with different values, the browser must pick a winner. It uses <strong>specificity</strong> — a scoring system.' },
      { t: 'p', text: 'Roughly, from lowest to highest priority:' },
      { t: 'table', head: ['Selector type', 'Example', 'Priority'], rows: [
        ['Type selector', '<code>p</code>', 'Low'],
        ['Class / attribute', '<code>.intro</code>, <code>[type="text"]</code>', 'Medium'],
        ['ID selector', '<code>#header</code>', 'High'],
        ['Inline style', '<code>style="color:red"</code>', 'Higher'],
        ['!important', '<code>color:red !important</code>', 'Highest (avoid)']
      ] },
      { t: 'code', lang: 'css', caption: 'Specificity in action', code: `p { color: gray; }        /* type: low */
.text { color: blue; }    /* class: medium */
#main { color: green; }   /* id: high */

/* For <p class="text" id="main">, green wins */` },
      { t: 'callout', type: 'warn', title: 'Avoid !important',
        text: '<code>!important</code> overrides everything and is a code smell — it makes future changes hard. Fix specificity instead of reaching for it.' },
      { t: 'quiz', q: 'Which selector has the HIGHEST specificity?', options: ['p', '.text', '#main', '*'], answer: 2,
        explanation: 'ID selectors (#main) have higher specificity than classes (.text) which beat type selectors (p). The universal selector * has none.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-inheritance',
    module: 'Module 10 — CSS Deep Dive',
    title: 'Inheritance',
    summary: 'Let child elements inherit styles like font and color from parents.',
    keywords: ['inheritance', 'inherit', 'font', 'color', 'child', 'parent', 'inherit value'],
    objectives: [
      'Understand which properties inherit',
      'Use inheritance to style efficiently',
      'Override inherited values',
      'Use the inherit keyword'
    ],
    blocks: [
      { t: 'lead', text: 'Some CSS properties <strong>inherit</strong> — children automatically take their value from their parent. Font and color are the classic examples.' },
      { t: 'code', lang: 'css', caption: 'Inheritance', code: `body {
  font-family: Arial, sans-serif;
  color: #222;
}
/* every child inherits this font and color
   unless it sets its own */` },
      { t: 'h3', text: 'Which properties inherit?' },
      { t: 'list', items: [
        '<strong>Inherit by default:</strong> <code>color</code>, <code>font-family</code>, <code>font-size</code>, <code>line-height</code>, <code>text-align</code>.',
        '<strong>Do NOT inherit:</strong> <code>margin</code>, <code>padding</code>, <code>border</code>, <code>background</code>, <code>width</code>, <code>height</code>.'
      ] },
      { t: 'p', text: 'A good rule: set font styles once on <code>body</code> and let them inherit — far less repetition.' },
      { t: 'code', lang: 'css', caption: 'Forcing inheritance', code: `.child {
  color: inherit;   /* take the parent's color */
}` },
      { t: 'demo', title: 'Inheritance demo', html: `<div style="font-family:Georgia,serif;color:#2f5af0;border:2px solid #ccc;padding:16px;border-radius:8px">
Parent: Georgia, blue.
<p style="margin:8px 0;color:inherit">Child inherits the blue.</p>
<p style="margin:8px 0;color:#e5484d">This child overrides with its own color.</p>
</div>` },
      { t: 'quiz', q: 'Which of these properties INHERITS by default?', options: ['margin', 'border', 'color', 'width'], answer: 2,
        explanation: 'color inherits from parent to child by default. Margin, border and width do not inherit.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-cascade',
    module: 'Module 10 — CSS Deep Dive',
    title: 'The Cascade',
    summary: 'Understand how source order and origin decide the final style.',
    keywords: ['cascade', 'source order', 'order', 'override', 'origin', 'author styles'],
    objectives: [
      'Define the CSS cascade',
      'Understand source order wins on ties',
      'Know that later rules override earlier ones',
      'See how the cascade combines with specificity'
    ],
    blocks: [
      { t: 'lead', text: 'The <strong>cascade</strong> is the whole process the browser uses to decide which style applies — hence "Cascading" Style Sheets. When specificity ties, <strong>source order</strong> decides.' },
      { t: 'code', lang: 'css', caption: 'Source order wins on equal specificity', code: `.box { color: red; }
.box { color: blue; }

/* both are class selectors (same specificity),
   so the LATER one wins → blue */` },
      { t: 'h3', text: 'The resolution order' },
      { t: 'p', text: 'When multiple rules conflict, the browser weighs, in order: importance, origin, specificity, then source order. In practice for your own code, you mainly manage <strong>specificity</strong> and <strong>order</strong>.' },
      { t: 'callout', type: 'tip', title: 'Keep it predictable',
        text: 'Write specific but not over-specific selectors, keep related rules together, and you will rarely be surprised by the cascade.' },
      { t: 'demo', title: 'Cascade demo', html: `<div style="font-family:sans-serif">
<p style="color:#2f5af0">This paragraph has color set by a rule later in the cascade.</p>
</div>` },
      { t: 'quiz', q: 'If two rules have the SAME specificity, which one wins?', options: ['The first one', 'The later one (source order)', 'The one with more properties', 'Neither'], answer: 1,
        explanation: 'On a specificity tie, the rule that appears later in the stylesheet wins — that is source order.' }
    ]
  });

  Curriculum.addLesson({
    id: 'debugging-css',
    module: 'Module 10 — CSS Deep Dive',
    title: 'Debugging HTML & CSS',
    summary: 'Learn to find and fix HTML/CSS errors using the browser DevTools.',
    keywords: ['debug', 'devtools', 'console', 'inspect', 'error', 'inspect element', 'fix'],
    objectives: [
      'Open the browser developer tools',
      'Inspect elements and their styles',
      'Read console errors',
      'Debug layout problems step by step'
    ],
    blocks: [
      { t: 'lead', text: 'Every developer spends time fixing broken code. The browser\'s <strong>Developer Tools</strong> (DevTools) are your best debugging friend.' },
      { t: 'h3', text: 'Opening DevTools' },
      { t: 'p', text: 'Right-click any element and choose <strong>Inspect</strong>, or press <code>F12</code> (Windows) / <code>Cmd+Option+I</code> (Mac).' },
      { t: 'h3', text: 'The Elements panel' },
      { t: 'list', items: [
        'See the live HTML and click elements.',
        'View the <strong>Computed</strong> tab to see the box model (content, padding, border, margin).',
        'Toggle styles on/off by clicking the checkbox next to a property.',
        'Edit styles live to experiment without saving.'
      ] },
      { t: 'h3', text: 'The Console' },
      { t: 'p', text: 'JavaScript errors appear here in red. Read the message and the file/line — it usually tells you exactly what went wrong.' },
      { t: 'callout', type: 'good', title: 'A debugging checklist',
        text: 'Ask yourself: Is the HTML closed properly? Is the file linked (<code>link rel="stylesheet"</code>)? Is the selector spelled right? Is specificity overriding my rule? Is the element hidden by overflow or display:none? Add a bright temporary <code>border</code> to see an element\'s box.' },
      { t: 'code', lang: 'js', caption: 'A helpful trick while learning', code: `// In the console, check for errors:
console.log('Working!');

// Common: link a stylesheet
<link rel="stylesheet" href="style.css">` },
      { t: 'quiz', q: 'Which panel shows you the box model of an element?', options: ['Console', 'Network', 'Computed/Styles', 'Sources'], answer: 2,
        explanation: 'The Styles/Computed panel in the Elements view shows the box model — content, padding, border and margin of the selected element.' }
    ]
  });

  Curriculum.addLesson({
    id: 'css-best-practices',
    module: 'Module 10 — CSS Deep Dive',
    title: 'Best Practices',
    summary: 'Write clean, maintainable HTML and CSS with smart habits.',
    keywords: ['best practices', 'clean code', 'semantic', 'naming', 'organization', 'performance', 'comment'],
    objectives: [
      'Use semantic HTML and good naming',
      'Keep CSS organized with comments',
      'Avoid repetition and !important',
      'Follow performance and accessibility habits'
    ],
    blocks: [
      { t: 'lead', text: 'Clean code is easy to read and change. These habits will save you hours and make your work professional.' },
      { t: 'h3', text: 'HTML habits' },
      { t: 'list', items: [
        'Use <strong>semantic</strong> tags (<code>header</code>, <code>nav</code>, <code>main</code>) instead of <code>div</code> everywhere.',
        'Keep a <strong>single <code>h1</code></strong> per page.',
        'Always add <code>alt</code> to images.',
        'Indent nested elements consistently to show structure.',
        'Use <code>lang="en"</code> on <code>&lt;html&gt;</code>.'
      ] },
      { t: 'h3', text: 'CSS habits' },
      { t: 'list', items: [
        'Use <strong>meaningful class names</strong> like <code>.card</code>, <code>.nav-links</code> — not <code>.a</code> or <code>.red</code>.',
        'Group related rules and add <strong>section comments</strong>.',
        'Apply the <code>border-box</code> reset at the top.',
        'Prefer <code>rem</code> for font sizes.',
        'Avoid <code>!important</code> and inline styles.',
        'Keep selectors simple (avoid deep nesting like <code>.a .b .c</code>).'
      ] },
      { t: 'code', lang: 'css', caption: 'Organized CSS with comments', code: `/* ============ Base ============ */
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; margin: 0; }

/* ============ Layout ============ */
.header { display: flex; justify-content: space-between; }
.cards { display: grid; grid-template-columns: repeat(3, 1fr); }

/* ============ Components ============ */
.btn { padding: 10px 16px; border-radius: 8px; }` },
      { t: 'callout', type: 'tip', title: 'Final rule of thumb',
        text: 'If you find yourself repeating the same style, extract it into a class. If a selector is hard to read, simplify it. Clean code is a skill you build with every project.' },
      { t: 'quiz', q: 'Which is a good, meaningful class name?', options: ['.c1', '.blue', '.nav-links', '.box-1-2'], answer: 2,
        explanation: '.nav-links describes the purpose. Names like .c1, .blue or .box-1-2 are unhelpful and become meaningless as designs change.' }
    ]
  });

})();
