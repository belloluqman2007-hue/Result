/* =========================================================
   HTML & CSS MASTERY — app.js
   Builds the shared shell (header, footer, sidebar, menus),
   routes pages and renders all course content.
   ========================================================= */

const App = (function () {

  const NAV = [
    { label: 'Home', url: 'index.html', page: 'home' },
    { label: 'Course', url: 'course.html', page: 'course' },
    { label: 'Lessons', url: 'lesson.html', page: 'lesson' },
    { label: 'Exercises', url: 'exercises.html', page: 'exercises' },
    { label: 'Quizzes', url: 'quizzes.html', page: 'quizzes' },
    { label: 'Projects', url: 'projects.html', page: 'projects' },
    { label: 'Cheat Sheets', url: 'cheatsheets.html', page: 'cheatsheets' },
    { label: 'Glossary', url: 'glossary.html', page: 'glossary' },
    { label: 'Editor', url: 'editor.html', page: 'editor' }
  ];

  const PAGE = (document.body ? document.body.getAttribute('data-page') : 'home') || 'home';

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  function qs(name) { return new URLSearchParams(location.search).get(name); }

  /* ---------------- Shell ---------------- */

  function buildShell() {
    const firstId = (Curriculum.getFirstLesson() || {}).id;
    const sidebar = document.getElementById('sidebar');

    // Header
    const header = document.getElementById('siteHeader');
    if (header) {
      const navHtml = NAV.map(n => {
        const active = (n.page === PAGE) || (PAGE === 'lesson' && n.page === 'lesson');
        return '<a href="' + n.url.replace('lesson.html', 'lesson.html?id=' + (firstId || '')) + '" class="' + (active ? 'active' : '') + '">' + n.label + '</a>';
      }).join('');

      header.innerHTML =
        '<div class="header-inner">' +
        '<button class="icon-btn mobile-menu-btn" id="mobileMenuBtn" aria-label="Open menu">☰</button>' +
        '<a class="brand" href="index.html"><span class="logo">&lt;/&gt;</span><span>HTML &amp; CSS<br><small>MASTERY</small></span></a>' +
        '<nav class="main-nav" aria-label="Main">' + navHtml + '</nav>' +
        '<div class="header-actions">' +
        (sidebar ? '<button class="icon-btn sidebar-toggle-btn" id="mobileSidebarToggle" aria-label="Course outline">📚</button>' : '') +
        '<button class="icon-btn" id="searchBtn" aria-label="Search" title="Search (/)">🔍</button>' +
        '<button class="icon-btn" id="themeToggle" aria-label="Toggle theme">🌙</button>' +
        '</div></div>';
    }

    // Sidebar
    if (sidebar) sidebar.innerHTML = buildSidebar();

    // Footer
    const footer = document.getElementById('siteFooter');
    if (footer) {
      footer.innerHTML =
        '<div class="container">' +
        '<div class="footer-grid">' +
        '<div><h4>Course</h4>' +
        '<a href="course.html">Dashboard</a><a href="lesson.html?id=' + (firstId || '') + '">Start Lessons</a>' +
        '<a href="exercises.html">Exercises</a><a href="projects.html">Projects</a></div>' +
        '<div><h4>Resources</h4>' +
        '<a href="quizzes.html">Quizzes</a><a href="cheatsheets.html">Cheat Sheets</a>' +
        '<a href="glossary.html">Glossary</a><a href="editor.html">Code Editor</a></div>' +
        '<div><h4>Learn</h4>' +
        '<a href="lesson.html?id=what-is-html">What is HTML?</a><a href="lesson.html?id=what-is-css">What is CSS?</a>' +
        '<a href="lesson.html?id=css-flexbox-1">Flexbox</a><a href="lesson.html?id=css-grid-1">CSS Grid</a></div>' +
        '<div><h4>Progress</h4>' +
        '<a href="progress.html">My Progress</a><a href="progress.html#achievements">Achievements</a>' +
        '<a href="progress.html#reset">Reset Progress</a></div>' +
        '</div>' +
        '<div class="footer-bottom">© 2026 HTML &amp; CSS Mastery — Built with HTML, CSS &amp; JavaScript for learning.</div>' +
        '</div>';
    }

    // Back to top + mobile drawer
    if (!document.getElementById('backTop')) {
      const bt = document.createElement('button');
      bt.id = 'backTop';
      bt.className = 'back-top';
      bt.setAttribute('aria-label', 'Back to top');
      bt.textContent = '↑';
      document.body.appendChild(bt);
    }

    const drawer = document.getElementById('mobileDrawer') || (() => {
      const d = document.createElement('div');
      d.id = 'mobileDrawer';
      d.className = 'mobile-drawer';
      document.body.appendChild(d);
      return d;
    })();
    const drawerNav = NAV.map(n => '<a href="' + n.url.replace('lesson.html', 'lesson.html?id=' + (firstId || '')) + '" class="' + (n.page === PAGE ? 'active' : '') + '">' + n.label + '</a>').join('');
    drawer.innerHTML = '<div class="backdrop" id="mobileBackdrop"></div><div class="drawer">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><a class="brand" href="index.html"><span class="logo">&lt;/&gt;</span> HTML &amp; CSS MASTERY</a></div>' +
      drawerNav +
      '<button class="btn btn-outline btn-block" id="themeToggleMobile" style="margin-top:12px">🌙 Dark Mode</button>' +
      '</div>';
  }

  function buildSidebar() {
    const state = Store.load();
    let html = '<div class="sidebar-head"><h3>📚 Course Outline</h3></div>';
    const modules = Curriculum.getModules();
    modules.forEach((mod, mi) => {
      const lessons = Curriculum.getModuleLessons(mod.name);
      if (!lessons.length) return;
      const prog = Progress.moduleProgress(mod.name);
      const open = mod.name === 'Module 1 — Introduction';
      html += '<div class="sidebar-module ' + (open ? 'open' : '') + '" data-module="' + mi + '">';
      html += '<button class="module-toggle">' + esc(mod.name) + ' <span class="chev">▶</span></button>';
      html += '<div class="module-bar"><span style="width:' + prog.pct + '%"></span></div>';
      html += '<ul class="module-lessons">';
      lessons.forEach((l, li) => {
        const done = state.completedLessons.includes(l.id) ? ' done' : '';
        const active = (PAGE === 'lesson' && qs('id') === l.id) ? ' active' : '';
        html += '<li><a class="' + done + active + '" href="lesson.html?id=' + l.id + '"><span class="num">' + (mi + 1) + '.' + (li + 1) + '</span>' + (done ? '✅ ' : '') + esc(l.title) + '</a></li>';
      });
      html += '</ul></div>';
    });
    return html;
  }

  function bindSidebar() {
    document.querySelectorAll('.sidebar-module .module-toggle').forEach(btn => {
      if (btn.dataset.bound) return;
      btn.dataset.bound = '1';
      btn.addEventListener('click', () => {
        const mod = btn.closest('.sidebar-module');
        mod.classList.toggle('open');
      });
    });
    const collapseBtn = document.getElementById('sidebarToggle');
    if (collapseBtn && !collapseBtn.dataset.bound) {
      collapseBtn.dataset.bound = '1';
      collapseBtn.addEventListener('click', () => {
        const sb = document.getElementById('sidebar');
        sb.classList.toggle('hidden');
      });
    }
  }

  function initShellInteractions() {
    bindSidebar();

    // Mobile sidebar backdrop (lesson/course page on mobile)
    let msb = document.getElementById('mobileSidebarBackdrop');
    if (!msb && document.getElementById('sidebar')) {
      msb = document.createElement('div');
      msb.id = 'mobileSidebarBackdrop';
      msb.className = 'mobile-sidebar-backdrop';
      document.body.appendChild(msb);
    }
    if (msb) msb.addEventListener('click', () => document.body.classList.remove('show-mobile-sidebar'));
    const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
    if (mobileSidebarToggle) {
      mobileSidebarToggle.addEventListener('click', () => document.body.classList.toggle('show-mobile-sidebar'));
    }

    // Mobile menu
    const menuBtn = document.getElementById('mobileMenuBtn');
    const drawer = document.getElementById('mobileDrawer');
    if (menuBtn && drawer) {
      menuBtn.addEventListener('click', () => drawer.style.display = 'block');
      drawer.querySelector('#mobileBackdrop').addEventListener('click', () => drawer.style.display = 'none');
      drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', () => drawer.style.display = 'none'));
    }

    Theme.updateButtons();

    const searchBtn = document.getElementById('searchBtn');
    if (searchBtn) searchBtn.addEventListener('click', () => Search.open());

    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        Search.open();
      }
    });
  }

  /* ---------------- Router ---------------- */

  function route() {
    const main = document.getElementById('mainContent');
    if (!main) return;
    switch (PAGE) {
      case 'home': renderHome(main); break;
      case 'course': renderCourse(main); break;
      case 'lesson': renderLesson(main); break;
      case 'exercises': renderExercises(main); break;
      case 'quizzes': renderQuizzes(main); break;
      case 'projects': renderProjects(main); break;
      case 'glossary': renderGlossary(main); break;
      case 'cheatsheets': renderCheatsheets(main); break;
      case 'editor': renderEditor(main); break;
      case 'progress': renderProgress(main); break;
      default: renderHome(main);
    }
  }

  /* ---------------- Home ---------------- */

  function renderHome(main) {
    const overall = Progress.overallPct();
    const summary = Progress.summary();
    const firstId = (Curriculum.getFirstLesson() || {}).id;
    const modules = Curriculum.getModules();

    let html = '';
    html += '<section class="hero">' +
      '<span class="badge">🎓 Beginner → Advanced</span>' +
      '<h1>Learn HTML &amp; CSS From Zero to Professional</h1>' +
      '<p>A complete interactive course that teaches you how to build modern, responsive websites from scratch.</p>' +
      '<div class="hero-actions">' +
      '<a class="btn btn-primary btn-lg" href="lesson.html?id=' + (firstId || '') + '">Start Learning</a>' +
      '<a class="btn btn-outline btn-lg" href="course.html">Explore Course</a>' +
      '<a class="btn btn-outline btn-lg" href="editor.html">Try Code Editor</a>' +
      '</div>' +
      '<div class="hero-stats">' +
      '<div class="hero-stat"><strong>' + summary.lessonsTotal + '</strong><span>Lessons</span></div>' +
      '<div class="hero-stat"><strong>' + Exercises.getAll().length + '</strong><span>Exercises</span></div>' +
      '<div class="hero-stat"><strong>' + Projects.getAll().length + '</strong><span>Projects</span></div>' +
      '<div class="hero-stat"><strong>' + Quizzes.getAll().reduce((n, q) => n + q.questions.length, 0) + '+</strong><span>Quiz Questions</span></div>' +
      '<div class="hero-stat"><strong>' + Quizzes.getAll().length + '</strong><span>Quizzes</span></div>' +
      '<div class="hero-stat"><strong>HTML</strong><span>Structuring</span></div>' +
      '<div class="hero-stat"><strong>CSS</strong><span>Styling</span></div>' +
      '<div class="hero-stat"><strong>Live</strong><span>Practice</span></div>' +
      '</div></section>';

    if (overall > 0) {
      html += '<div class="card mb-3" style="display:flex;gap:20px;align-items:center;flex-wrap:wrap">' +
        '<div style="flex:1;min-width:200px"><h3 style="margin:0">Course Progress: ' + overall + '%</h3>' +
        '<div class="progress-track mt-1"><div class="progress-fill" style="width:' + overall + '%"></div></div></div>' +
        '<a class="btn btn-accent" href="lesson.html?id=' + (Store.load().currentLesson || firstId) + '">Continue Learning →</a></div>';
    }

    html += '<section class="section"><div class="section-head"><div><div class="eyebrow">Your Journey</div><h2>From Beginner to Project Builder</h2></div></div>' +
      '<ul class="path">' +
      '<li class="' + (overall >= 10 ? 'done' : 'current') + '"><div class="p-dot">1</div><div><h4>Beginner</h4><p>Modules 1–6 · HTML fundamentals, semantic HTML, CSS basics and the box model.</p></div></li>' +
      '<li class="' + (overall >= 30 ? 'done' : overall >= 10 ? 'current' : '') + '"><div class="p-dot">2</div><div><h4>Intermediate</h4><p>Modules 7–8 · Flexbox, Grid, positioning and responsive design.</p></div></li>' +
      '<li class="' + (overall >= 60 ? 'done' : overall >= 30 ? 'current' : '') + '"><div class="p-dot">3</div><div><h4>Advanced</h4><p>Module 9–10 · Effects, animations, specificity and debugging.</p></div></li>' +
      '<li class="' + (overall >= 90 ? 'done' : overall >= 60 ? 'current' : '') + '"><div class="p-dot">4</div><div><h4>Project Builder</h4><p>10 projects including the final responsive school website capstone.</p></div></li>' +
      '</ul></section>';

    html += '<section class="section"><div class="section-head"><div><div class="eyebrow">Curriculum</div><h2>What You Will Learn</h2></div><a class="btn btn-outline btn-sm" href="course.html">View dashboard →</a></div>' +
      '<div class="grid grid-3">';
    modules.forEach(mod => {
      const lessons = Curriculum.getModuleLessons(mod.name);
      if (!lessons.length) return;
      const prog = Progress.moduleProgress(mod.name);
      const num = (mod.name.match(/\d+/) || [''])[0];
      html += '<a class="card card-hover" href="lesson.html?id=' + lessons[0].id + '">' +
        '<div class="chip primary mb-1">' + mod.code.replace(/-/g, ' ') + '</div>' +
        '<h3 style="font-size:1.05rem;margin-bottom:6px">' + esc(mod.name.replace('Module ' + num + ' — ', '')) + '</h3>' +
        '<p class="text-muted text-small" style="margin:0">' + lessons.length + ' lessons</p>' +
        '<div class="progress-track mt-2"><div class="progress-fill" style="width:' + prog.pct + '%"></div></div>' +
        '<div class="text-small text-muted mt-1">' + prog.pct + '% complete</div>' +
        '</a>';
    });
    html += '</div></section>';

    html += '<section class="section"><div class="section-head"><div><div class="eyebrow">Why this course</div><h2>Learn by Doing</h2></div></div>' +
      '<div class="feature-list">' +
      '<div class="feature-item"><div class="f-icon">📖</div><div><h4>Read &amp; Understand</h4><p>Clear, beginner-friendly lessons that explain every concept in simple English.</p></div></div>' +
      '<div class="feature-item"><div class="f-icon">⌨️</div><div><h4>Code &amp; Run</h4><p>Live code playground with instant HTML + CSS preview in your browser.</p></div></div>' +
      '<div class="feature-item"><div class="f-icon">🧠</div><div><h4>Practice &amp; Quiz</h4><p>20+ coding exercises and quizzes with explanations.</p></div></div>' +
      '<div class="feature-item"><div class="f-icon">🏗️</div><div><h4>Build Projects</h4><p>10 progressive projects, ending with a full responsive school website.</p></div></div>' +
      '<div class="feature-item"><div class="f-icon">📊</div><div><h4>Track Progress</h4><p>Your progress is saved automatically so you can continue anytime.</p></div></div>' +
      '<div class="feature-item"><div class="f-icon">🏆</div><div><h4>Earn Achievements</h4><p>Unlock badges as you complete lessons, quizzes and projects.</p></div></div>' +
      '</div></section>';

    html += '<section class="section"><div class="section-head"><div><div class="eyebrow">Resources</div><h2>Quick Access</h2></div></div>' +
      '<div class="grid grid-4">' +
      '<a class="card card-hover text-center" href="cheatsheets.html"><div style="font-size:2rem">📋</div><h3 style="margin:6px 0 0">Cheat Sheets</h3><p class="text-muted text-small">HTML &amp; CSS reference</p></a>' +
      '<a class="card card-hover text-center" href="glossary.html"><div style="font-size:2rem">📚</div><h3 style="margin:6px 0 0">Glossary</h3><p class="text-muted text-small">50+ terms explained</p></a>' +
      '<a class="card card-hover text-center" href="quizzes.html"><div style="font-size:2rem">✅</div><h3 style="margin:6px 0 0">Quizzes</h3><p class="text-muted text-small">Test your knowledge</p></a>' +
      '<a class="card card-hover text-center" href="editor.html"><div style="font-size:2rem">🖥️</div><h3 style="margin:6px 0 0">Code Editor</h3><p class="text-muted text-small">Live playground</p></a>' +
      '</div></section>';

    main.innerHTML = html;
  }

  /* ---------------- Course dashboard ---------------- */

  function ringSVG(pct, size) {
    const r = (size / 2) - 8;
    const c = 2 * Math.PI * r;
    const offset = c - (pct / 100) * c;
    return '<svg class="ring" width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">' +
      '<circle class="ring-track" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke-width="14"></circle>' +
      '<circle class="ring-fill" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke-width="14" stroke-linecap="round" stroke-dasharray="' + c + '" stroke-dashoffset="' + offset + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"></circle>' +
      '<text class="ring-text" x="50%" y="50%" text-anchor="middle" dominant-baseline="central">' + pct + '%</text></svg>';
  }

  function renderCourse(main) {
    const summary = Progress.summary();
    let html = '<h1>Course Dashboard</h1><p class="text-muted">Track your learning journey across all modules.</p>';

    html += '<div class="card mb-3"><div class="big-progress">' + ringSVG(summary.overall, 120) +
      '<div style="flex:1"><h2 style="margin-bottom:4px">Course Progress: ' + summary.overall + '%</h2>' +
      '<p class="text-muted">' + summary.lessonsDone + ' of ' + summary.lessonsTotal + ' lessons completed.</p>' +
      '<div class="progress-track"><div class="progress-fill" style="width:' + summary.overall + '%"></div></div>' +
      '<div class="d-flex mt-2"><a class="btn btn-accent" href="lesson.html?id=' + (Store.load().currentLesson || (Curriculum.getFirstLesson() || {}).id) + '">Continue →</a>' +
      '<a class="btn btn-outline" href="progress.html">Full progress</a></div></div></div></div>';

    html += '<div class="card"><h3 style="margin-top:0">Module Progress</h3>';
    Progress.moduleProgressList().forEach(m => {
      if (m.total === 0) return;
      const num = (m.module.match(/\d+/) || [''])[0];
      html += '<div class="progress-row"><span class="label">' + esc(m.module.replace('Module ' + num + ' — ', '')) + '</span>' +
        '<div class="progress-track"><div class="progress-fill" style="width:' + m.pct + '%"></div></div>' +
        '<span class="pct">' + m.pct + '%</span></div>';
    });
    html += '</div>';

    html += '<div class="stat-cards mt-3">' +
      '<div class="stat-card"><span class="icon">📖</span><strong>' + summary.lessonsTotal + '</strong><span>Lessons</span></div>' +
      '<div class="stat-card"><span class="icon">✅</span><strong>' + summary.lessonsDone + '</strong><span>Completed</span></div>' +
      '<div class="stat-card"><span class="icon">📝</span><strong>' + summary.quizzesDone + '</strong><span>Quizzes</span></div>' +
      '<div class="stat-card"><span class="icon">🏗️</span><strong>' + summary.projectsDone + '</strong><span>Projects</span></div>' +
      '<div class="stat-card"><span class="icon">🏆</span><strong>' + summary.achievements + '</strong><span>Achievements</span></div>' +
      '</div>';

    const next = Store.load().currentLesson ? Curriculum.getNextLesson(Store.load().currentLesson) : Curriculum.getFirstLesson();
    if (next) {
      html += '<div class="card mt-3"><h3 style="margin-top:0">📖 Next up</h3><p><strong>' + esc(next.title) + '</strong><br><span class="text-muted">' + esc(next.module) + '</span></p>' +
        '<a class="btn btn-primary" href="lesson.html?id=' + next.id + '">Go to lesson →</a></div>';
    }

    main.innerHTML = html;
  }

  /* ---------------- Lesson page ---------------- */

  function renderLesson(main) {
    const id = qs('id');
    const lesson = Curriculum.getLesson(id) || Curriculum.getFirstLesson();
    if (!lesson) { main.innerHTML = '<h1>No lesson found.</h1>'; return; }

    Store.visitLesson(lesson.id);

    const idx = Curriculum.getIndex(lesson.id);
    const prev = Curriculum.getPrevLesson(lesson.id);
    const next = Curriculum.getNextLesson(lesson.id);
    const done = Store.isLessonCompleted(lesson.id);

    let html = LessonRenderer.renderLesson(lesson, { prev, next, index: idx });
    html += '<div class="card" style="margin-top:20px;text-align:center">' +
      '<button class="btn ' + (done ? 'btn-outline' : 'btn-accent') + ' btn-lg" id="markComplete">' + (done ? '✅ Completed — click to redo' : 'Mark as Complete ✓') + '</button>' +
      '</div>';
    main.innerHTML = html;

    LessonRenderer.initLessonInteractions(main);
    UI.initCopyButtons(main);

    document.getElementById('markComplete').addEventListener('click', () => {
      const wasDone = Store.isLessonCompleted(lesson.id);
      Store.completeLesson(lesson.id);
      const btn = document.getElementById('markComplete');
      if (!wasDone) {
        btn.textContent = '✅ Completed!';
        btn.classList.remove('btn-accent'); btn.classList.add('btn-outline');
        UI.toast('Lesson completed! 🎉', 'success');
        renderCourseSidebar();
      } else {
        btn.textContent = 'Mark as Complete ✓';
        btn.classList.add('btn-accent'); btn.classList.remove('btn-outline');
      }
    });

    document.getElementById('sidebar').innerHTML = buildSidebar();
    bindSidebar();
  }

  function renderCourseSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) { sidebar.innerHTML = buildSidebar(); bindSidebar(); }
  }

  /* ---------------- Exercises ---------------- */

  function renderExercises(main) {
    const list = Exercises.getAll();
    let html = '<h1>Interactive Exercises</h1><p class="text-muted">Complete the code challenges below. Press <strong>Run Code</strong> to preview and <strong>Check Answer</strong> to validate your solution.</p>';
    html += '<div class="d-flex mb-2"><div class="chip primary">' + list.length + ' challenges</div><div class="chip accent">Your solved: <span id="exSolvedCount">' + Store.load().exercisesSolved.length + '</span></div></div>';

    list.forEach(ex => {
      html += '<div class="challenge-card" id="ex-' + ex.id + '">' +
        '<div class="challenge-head"><h3>' + ex.num + '. ' + esc(ex.title) + '</h3><span class="difficulty ' + (ex.difficulty || '').toLowerCase() + '">' + esc(ex.difficulty) + '</span></div>' +
        '<div class="challenge-body">' +
        '<p>' + ex.prompt + '</p>' +
        '<div class="challenge-req"><h4>Requirements</h4><ul>' + ex.checks.map(c => '<li>' + c.desc + '</li>').join('') + '</ul></div>' +
        '<div class="challenge-editor"><textarea id="code-' + ex.id + '" spellcheck="false" placeholder="Write your code here...">' + esc(ex.starter) + '</textarea></div>' +
        '<div class="challenge-actions">' +
        '<button class="btn btn-primary" data-run="' + ex.id + '">▶ Run Code</button>' +
        '<button class="btn btn-accent" data-check="' + ex.id + '">✓ Check Answer</button>' +
        '<button class="btn btn-outline" data-reset="' + ex.id + '">↺ Reset</button>' +
        '<button class="btn btn-ghost" data-solution="' + ex.id + '">Show Solution</button>' +
        '</div>' +
        '<div class="challenge-preview" id="preview-' + ex.id + '"><span class="text-muted">Preview will appear here after you press Run.</span></div>' +
        '<div class="challenge-result" id="result-' + ex.id + '"></div>' +
        '</div></div>';
    });

    main.innerHTML = html;
    UI.initCopyButtons(main);

    list.forEach(ex => {
      const ta = document.getElementById('code-' + ex.id);

      document.querySelector('[data-run="' + ex.id + '"]').addEventListener('click', () => {
        const preview = document.getElementById('preview-' + ex.id);
        let html = ta.value, css = '';
        if (ex.css) { html = defaultBodyFor(ex); css = ta.value; }
        Editor.renderPreview(preview, html, css);
      });

      document.querySelector('[data-reset="' + ex.id + '"]').addEventListener('click', () => { ta.value = ex.starter; });

      document.querySelector('[data-solution="' + ex.id + '"]').addEventListener('click', () => {
        UI.openModal({ title: 'Solution: ' + ex.title, body: '<pre><code>' + esc(ex.solution) + '</code></pre>', actions: [{ label: 'Copy Solution', cls: 'btn-primary', action: 'copy' }, { label: 'Close', cls: 'btn-outline', action: 'close' }] });
      });

      document.querySelector('[data-check="' + ex.id + '"]').addEventListener('click', async () => {
        const btn = document.querySelector('[data-check="' + ex.id + '"]');
        btn.disabled = true; btn.textContent = 'Checking...';
        const result = await Editor.runExercise(ta.value, ex);
        btn.disabled = false; btn.textContent = '✓ Check Answer';
        const box = document.getElementById('result-' + ex.id);
        box.className = 'challenge-result ' + (result.pass ? 'pass' : 'fail');
        if (result.pass) {
          Store.solveExercise(ex.id);
          document.getElementById('exSolvedCount').textContent = Store.load().exercisesSolved.length;
          box.innerHTML = '<strong>✅ All checks passed!</strong> Nice work.';
          UI.toast('Exercise solved! 🎉', 'success');
        } else {
          const failed = result.results.filter(r => !r.pass);
          box.innerHTML = '<strong>❌ Not quite — ' + failed.length + ' check(s) failing:</strong><ul>' + failed.map(f => '<li>' + f.desc + '</li>').join('') + '</ul><p class="text-small">Review the lesson and try again. Press "Show Solution" if you are stuck.</p>';
        }
        if (box.scrollIntoView) box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      });
    });
  }

  function defaultBodyFor(ex) {
    return '<div class="card"><h2>My Card</h2><p>Card content.</p></div>' +
      '<h1>Title</h1><p>paragraph</p>' +
      '<div class="row"><span>1</span><span>2</span></div>' +
      '<div class="grid"><div>A</div><div>B</div><div>C</div></div>' +
      '<div class="box">box</div><a href="#">link</a>' +
      '<div class="hero">hero</div><nav><a>1</a><a>2</a><a>3</a></nav>' +
      '<div class="sidebar">sidebar</div><button class="btn">btn</button>' +
      '<header>h</header><main>m</main><footer>f</footer>';
  }

  /* ---------------- Quizzes ---------------- */

  function renderQuizzes(main) {
    const id = qs('id');
    if (id) {
      const quiz = Quizzes.get(id);
      if (!quiz) { main.innerHTML = '<h1>Quiz not found</h1>'; return; }
      main.innerHTML = '<div class="quiz-shell"><div class="card">' +
        '<div class="quiz-header"><div><h1 style="margin:0">' + esc(quiz.title) + '</h1><span class="chip mt-1">' + quiz.questions.length + ' questions</span></div>' +
        '<a class="btn btn-outline btn-sm" href="quizzes.html">All quizzes</a></div>' +
        '<p class="text-muted">Answer each question. You will see instant feedback and your score at the end.</p>' +
        '<div id="quizMount"></div></div></div>';
      QuizApp.start(quiz, document.getElementById('quizMount'));
      return;
    }

    let html = '<h1>Quizzes</h1><p class="text-muted">Test your knowledge across every topic. Best scores are saved.</p>';
    const cats = Quizzes.categories();
    const state = Store.load();

    cats.forEach(cat => {
      const quizzes = Quizzes.getAll().filter(q => q.category === cat);
      html += '<h2 style="margin-top:28px">' + esc(cat) + '</h2><div class="grid grid-3">';
      quizzes.forEach(q => {
        const best = state.quizScores[q.id];
        html += '<div class="card card-hover"><h3 style="margin:0 0 6px">' + esc(q.title) + '</h3>' +
          '<p class="text-muted text-small">' + q.questions.length + ' questions</p>' +
          (best ? '<div class="chip accent mb-1">Best: ' + best.pct + '%</div>' : '<div class="chip mb-1">Not attempted</div>') +
          '<div class="mt-1"><a class="btn btn-primary btn-sm" href="quizzes.html?id=' + q.id + '">Start Quiz</a></div></div>';
      });
      html += '</div>';
    });

    main.innerHTML = html;
  }

  /* ---------------- Projects ---------------- */

  function renderProjects(main) {
    const list = Projects.getAll();
    let html = '<h1>Projects</h1><p class="text-muted">Build real-world projects that grow with your skills. The final project is your capstone.</p>';

    html += '<div class="stat-cards mb-3">' +
      '<div class="stat-card"><span class="icon">🏗️</span><strong>' + list.length + '</strong><span>Projects</span></div>' +
      '<div class="stat-card"><span class="icon">✅</span><strong>' + Store.load().projectsCompleted.length + '</strong><span>Completed</span></div>' +
      '</div>';

    html += '<div class="tabs"><button class="active" data-tab="all">All</button><button data-tab="beginner">Beginner</button><button data-tab="intermediate">Intermediate</button><button data-tab="advanced">Advanced</button><button data-tab="capstone">Capstone</button></div>';
    html += '<div id="projectsList"></div>';
    main.innerHTML = html;

    function renderList(filter) {
      const container = document.getElementById('projectsList');
      const filtered = filter === 'all' ? list : list.filter(p => (p.difficulty || '').toLowerCase() === filter);
      let out = '';
      filtered.forEach(p => {
        const done = Store.isProjectCompleted(p.id);
        out += '<div class="card project-card mb-2" id="p-' + p.id + '">' +
          '<div class="d-flex" style="justify-content:space-between;flex-wrap:wrap"><h2 style="margin:0">Project ' + p.num + ': ' + esc(p.title) + '</h2>' +
          (done ? '<span class="chip accent">✅ Completed</span>' : '') + '</div>' +
          '<div class="p-meta"><span class="difficulty ' + (p.difficulty || 'beginner').toLowerCase() + '">' + esc(p.difficulty || 'Beginner') + '</span></div>' +
          '<p class="p-desc">' + esc(p.objective) + '</p>' +
          '<div class="mt-2"><button class="btn btn-primary btn-sm" data-toggle="' + p.id + '">View Details ▾</button>' +
          (done ? '' : '<button class="btn btn-accent btn-sm" data-complete="' + p.id + '" style="margin-left:8px">Mark Complete</button>') + '</div>' +
          '<div class="project-detail" id="detail-' + p.id + '" style="display:none;margin-top:18px;border-top:1px solid var(--border);padding-top:14px">' + projectDetail(p) + '</div>' +
          '</div>';
      });
      container.innerHTML = out || '<p class="text-muted">No projects in this category yet.</p>';

      container.querySelectorAll('[data-toggle]').forEach(b => {
        b.addEventListener('click', () => {
          const id = b.getAttribute('data-toggle');
          const det = document.getElementById('detail-' + id);
          const open = det.style.display !== 'none';
          det.style.display = open ? 'none' : 'block';
          b.textContent = open ? 'View Details ▾' : 'Hide Details ▴';
        });
      });
      container.querySelectorAll('[data-complete]').forEach(b => {
        b.addEventListener('click', () => {
          const id = b.getAttribute('data-complete');
          Store.completeProject(id);
          UI.toast('Project completed! 🏆', 'success');
          renderList(filter);
        });
      });
      UI.initCopyButtons(container);
    }

    document.querySelectorAll('.tabs button').forEach(t => {
      t.addEventListener('click', () => {
        document.querySelectorAll('.tabs button').forEach(x => x.classList.remove('active'));
        t.classList.add('active');
        renderList(t.getAttribute('data-tab'));
      });
    });
    renderList('all');
  }

  function projectDetail(p) {
    let html = '';
    html += '<h3>🎯 Objective</h3><p>' + esc(p.objective) + '</p>';
    html += '<div class="callout callout-good"><strong>Skills needed</strong><p>' + p.skills.map(s => '<span class="skill-pill">' + esc(s) + '</span>').join(' ') + '</p></div>';
    html += '<h3>📋 Requirements</h3><ul>' + p.requirements.map(r => '<li>' + r + '</li>').join('') + '</ul>';
    html += '<h3>📝 Instructions</h3><ol>' + p.instructions.map(i => '<li>' + esc(i) + '</li>').join('') + '</ol>';
    html += '<h3>⚡ Challenges</h3><ul>' + p.challenges.map(c => '<li>' + esc(c) + '</li>').join('') + '</ul>';
    html += '<h3>🚀 Starter Files</h3><div class="codeblock"><button class="copy-code" data-copy="next" data-label="Starter">Copy</button><pre><code>' + esc(p.starter) + '</code></pre></div>';
    html += '<h3>✅ Expected result</h3><p>A complete, well-structured, responsive implementation that meets all requirements above and works on phones, tablets and desktops.</p>';
    html += '<h3>🧠 Review section</h3><p>After finishing, self-review: Is the HTML semantic? Is the CSS organized? Is it fully responsive? Are hover effects and transitions working? Does it pass the W3C validator?</p>';
    return html;
  }

  /* ---------------- Glossary ---------------- */

  function renderGlossary(main) {
    const query = qs('q') || '';
    let html = '<h1>Glossary</h1><p class="text-muted">Searchable definitions of the key terms you will meet in this course.</p>';
    html += '<div class="glossary-search"><input type="text" id="glossaryInput" placeholder="Search terms... (e.g. box model, flexbox)" value="' + esc(query) + '"><button class="btn btn-outline" id="glossaryClear">Clear</button></div>';
    html += '<div class="alpha-nav" id="alphaNav"></div>';
    html += '<div id="glossaryList"></div>';
    main.innerHTML = html;

    const input = document.getElementById('glossaryInput');
    const listEl = document.getElementById('glossaryList');
    const alphaNav = document.getElementById('alphaNav');

    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    alphaNav.innerHTML = '<button data-letter="all" class="active">All</button>' + letters.map(l => '<button data-letter="' + l + '">' + l + '</button>').join('');

    function render() {
      const q = input.value.trim();
      let terms = Glossary.getAll();
      if (q) terms = terms.filter(t => (t.term + ' ' + t.def + ' ' + t.cat).toLowerCase().includes(q.toLowerCase()));
      else {
        const letter = document.querySelector('#alphaNav button.active').getAttribute('data-letter');
        if (letter !== 'all') terms = terms.filter(t => t.term.toUpperCase().startsWith(letter));
      }
      listEl.innerHTML = terms.length ? terms.map(t =>
        '<div class="glossary-term"><span class="term-cat">' + esc(t.cat) + '</span><h3 style="margin:2px 0 4px">' + esc(t.term) + '</h3><p>' + t.def + '</p></div>').join('')
        : '<p class="text-muted">No terms match your search.</p>';
    }

    input.addEventListener('input', render);
    document.getElementById('glossaryClear').addEventListener('click', () => { input.value = ''; render(); });
    alphaNav.querySelectorAll('button').forEach(b => {
      b.addEventListener('click', () => {
        alphaNav.querySelectorAll('button').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        render();
      });
    });
    render();
  }

  /* ---------------- Cheat sheets ---------------- */

  function renderCheatsheets(main) {
    let html = '<h1>Cheat Sheets</h1><p class="text-muted">Quick reference for HTML tags and CSS properties. Press Copy to grab each snippet.</p>';
    html += '<div class="tabs"><button class="active" data-tab="html">HTML Cheat Sheet</button><button data-tab="css">CSS Cheat Sheet</button></div>';
    html += '<div data-panel="html"><h2>HTML Tags</h2>' + renderCheatCat('html') + '</div>';
    html += '<div data-panel="css" style="display:none"><h2>CSS Properties</h2>' + renderCheatCat('css') + '</div>';
    main.innerHTML = html;
    UI.initCopyButtons(main);
    UI.initTabs(main);
  }

  function renderCheatCat(kind) {
    const cats = Cheatsheets.get(kind);
    let html = '';
    cats.forEach(cat => {
      html += '<div class="cheat-cat"><h3>📍 ' + esc(cat.cat) + '</h3>' +
        '<div style="overflow-x:auto"><table class="cheat-table">';
      if (kind === 'html') {
        html += '<thead><tr><th>Tag</th><th>Purpose</th><th>Example</th><th></th></tr></thead><tbody>';
        cat.items.forEach(it => {
          html += '<tr><td><code>' + esc(it.name) + '</code></td><td>' + esc(it.purpose) + '</td>' +
            '<td><code>' + esc(it.example) + '</code></td>' +
            '<td><button class="btn btn-sm btn-ghost" data-copy-text="' + esc(it.example) + '" data-label="Example">📋</button></td></tr>';
        });
      } else {
        html += '<thead><tr><th>Property</th><th>Purpose</th><th>Syntax</th><th>Example</th><th></th></tr></thead><tbody>';
        cat.items.forEach(it => {
          html += '<tr><td><code>' + esc(it.name) + '</code></td><td>' + esc(it.purpose) + '</td>' +
            '<td><code>' + esc(it.syntax) + '</code></td><td><code>' + esc(it.example) + '</code></td>' +
            '<td><button class="btn btn-sm btn-ghost" data-copy-text="' + esc(it.example) + '" data-label="Code">📋</button></td></tr>';
        });
      }
      html += '</tbody></table></div></div>';
    });
    return html;
  }

  /* ---------------- Editor ---------------- */

  function renderEditor(main) {
    main.innerHTML =
      '<div class="d-flex mb-2" style="justify-content:space-between;align-items:center;flex-wrap:wrap">' +
      '<div><h1 style="margin:0">Code Playground</h1><p class="text-muted" style="margin:4px 0 0">Write HTML and CSS, press Run to see the live preview.</p></div>' +
      '<div class="d-flex">' +
      '<select id="templateSelect" aria-label="Template"><option value="hello">Hello World</option><option value="page">Full Page</option><option value="card">Card</option><option value="flex">Flexbox</option><option value="grid">Grid</option><option value="form">Form</option><option value="blank">Blank</option></select>' +
      '<label class="chip" style="cursor:pointer"><input type="checkbox" id="autoPreview"> Auto-preview</label>' +
      '</div></div>' +
      '<div class="editor-app" id="editorApp">' +
      '<div class="editor-toolbar">' +
      '<button class="btn btn-primary btn-sm" id="playgroundRun">▶ Run</button>' +
      '<button class="btn btn-outline btn-sm" id="playgroundReset">Reset</button>' +
      '<button class="btn btn-outline btn-sm" id="playgroundCopy">Copy</button>' +
      '<button class="btn btn-outline btn-sm" id="playgroundClear">Clear</button>' +
      '<span class="spacer"></span>' +
      '<button class="btn btn-ghost btn-sm" id="playgroundFull">⤢</button>' +
      '</div>' +
      '<div class="editor-main">' +
      '<div class="editor-col"><div class="editor-col-head"><span class="dot html"></span> HTML</div>' +
      '<div class="editor-wrap" id="htmlWrap"><div class="gutter" id="htmlGutter"></div><textarea class="code-textarea" id="htmlEditor" spellcheck="false" aria-label="HTML editor"></textarea></div></div>' +
      '<div class="editor-col"><div class="editor-col-head"><span class="dot css"></span> CSS</div>' +
      '<div class="editor-wrap" id="cssWrap"><div class="gutter" id="cssGutter"></div><textarea class="code-textarea" id="cssEditor" spellcheck="false" aria-label="CSS editor"></textarea></div></div>' +
      '</div>' +
      '<div class="editor-preview-bar"><span class="live-dot"></span> Live Preview</div>' +
      '<div class="editor-preview" id="playgroundPreview"></div>' +
      '</div>';
    Editor.initPlayground();
  }

  /* ---------------- Progress page ---------------- */

  function renderProgress(main) {
    const s = Progress.summary();
    const state = Store.load();
    let html = '<h1>My Progress</h1><p class="text-muted">Your learning dashboard — everything is saved in your browser.</p>';

    html += '<div class="card mb-3"><div class="big-progress">' + ringSVG(s.overall, 130) +
      '<div style="flex:1"><h2 style="margin:0 0 4px">Overall Completion: ' + s.overall + '%</h2>' +
      '<p class="text-muted">' + s.lessonsDone + ' / ' + s.lessonsTotal + ' lessons completed</p>' +
      '<div class="d-flex"><span class="chip">🔥 Streak: ' + s.streak + ' day(s)</span><span class="chip primary">📍 Current: ' + esc((Curriculum.getLesson(state.currentLesson) || { title: 'Not started' }).title) + '</span></div></div></div></div>';

    html += '<div class="stat-cards mb-3">' +
      '<div class="stat-card"><span class="icon">📖</span><strong>' + s.lessonsDone + '</strong><span>Lessons done</span></div>' +
      '<div class="stat-card"><span class="icon">📝</span><strong>' + s.quizzesDone + '</strong><span>Quizzes taken</span></div>' +
      '<div class="stat-card"><span class="icon">🏗️</span><strong>' + s.projectsDone + '</strong><span>Projects done</span></div>' +
      '<div class="stat-card"><span class="icon">🏆</span><strong>' + s.achievements + '</strong><span>Achievements</span></div>' +
      '</div>';

    html += '<div class="card mb-3"><h3 style="margin-top:0">📝 Quiz Scores</h3>';
    const quizEntries = Quizzes.getAll();
    const taken = quizEntries.filter(q => state.quizScores[q.id]);
    if (taken.length) {
      html += '<table><thead><tr><th>Quiz</th><th>Score</th><th>Percentage</th></tr></thead><tbody>';
      taken.forEach(q => {
        const sc = state.quizScores[q.id];
        html += '<tr><td>' + esc(q.title) + '</td><td>' + sc.score + ' / ' + sc.total + '</td><td>' +
          '<div class="progress-track" style="width:120px;display:inline-block;vertical-align:middle"><div class="progress-fill" style="width:' + sc.pct + '%"></div></div> ' + sc.pct + '%</td></tr>';
      });
      html += '</tbody></table>';
    } else {
      html += '<p class="text-muted">You have not taken any quizzes yet.</p>';
    }
    html += '</div>';

    html += '<div class="card mb-3"><h3 style="margin-top:0">🏗️ Projects Completed</h3>';
    const doneProjects = Projects.getAll().filter(p => state.projectsCompleted.includes(p.id));
    html += doneProjects.length ? '<ul>' + doneProjects.map(p => '<li>' + esc(p.title) + '</li>').join('') + '</ul>' : '<p class="text-muted">No projects completed yet. Head to the Projects page to start building!</p>';
    html += '</div>';

    html += '<div class="card mb-3" id="achievements"><h3 style="margin-top:0">🏆 Achievements</h3><div class="grid grid-3">';
    Achievements.getUnlocked().forEach(a => {
      html += '<div class="achievement ' + (a.date ? '' : 'locked') + '"><div class="a-emoji">' + a.def.emoji + '</div>' +
        '<div><div class="a-title">' + esc(a.def.title) + '</div><div class="a-desc">' + esc(a.def.desc) + '</div>' +
        (a.date ? '<div class="a-date">Unlocked ' + new Date(a.date).toLocaleDateString() + '</div>' : '<div class="a-date">Locked</div>') + '</div></div>';
    });
    html += '</div></div>';

    html += '<div class="card" id="reset"><h3 style="margin-top:0">⚠️ Reset Progress</h3>' +
      '<p class="text-muted">This clears all your completed lessons, quiz scores, exercises, projects and achievements. This cannot be undone.</p>' +
      '<button class="btn btn-danger" id="resetProgress">Reset All Progress</button></div>';

    main.innerHTML = html;

    document.getElementById('resetProgress').addEventListener('click', () => {
      UI.openModal({
        title: 'Reset All Progress?',
        body: '<p>Are you sure? This will erase all your saved progress and preferences. This cannot be undone.</p>',
        actions: [
          { label: 'Cancel', cls: 'btn-outline', action: 'cancel' },
          { label: 'Yes, reset everything', cls: 'btn-danger', action: 'confirm' }
        ]
      });
    });
  }

  /* ---------------- Init ---------------- */

  function init() {
    Store.load();
    buildShell();
    initShellInteractions();
    route();
    UI.initBackTop();
    UI.initGlobalKeys();
    Theme.init();
    document.dispatchEvent(new CustomEvent('hcm:ready'));
  }

  // Global modal action dispatch for reset
  document.addEventListener('click', (e) => {
    const modal = document.getElementById('modalRoot');
    if (!modal) return;
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.getAttribute('data-action');
    if (action === 'confirm') {
      Store.reset();
      UI.closeModal();
      UI.toast('Progress reset.', 'info');
      route();
      renderCourseSidebar();
    }
  });

  return { init, route, renderCourseSidebar };
})();

document.addEventListener('DOMContentLoaded', App.init);
