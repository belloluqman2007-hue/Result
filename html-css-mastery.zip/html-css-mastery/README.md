# HTML & CSS Mastery

A complete, interactive **HTML & CSS learning textbook** — from absolute beginner to advanced practical level. Built with **vanilla HTML, CSS and JavaScript** (no frameworks).

Learners can **READ → UNDERSTAND → CODE → RUN → PRACTICE → TAKE QUIZZES → COMPLETE PROJECTS → TRACK PROGRESS**.

## Quick start

Open `index.html` in any modern browser. No build step, no dependencies, no backend.

To serve locally:

```bash
# from inside this folder
python3 -m http.server 8080
# then open http://localhost:8080
```

## Features

- **54 lessons** across 10 modules (Introduction → HTML → CSS → Box Model → Layout → Responsive → Effects → Deep Dive)
- **Live code playground** — edit HTML + CSS, see the result instantly in a sandboxed iframe
- **24 interactive exercises** with real DOM/CSS validation
- **15 quizzes** (110 questions) with multiple-choice, true/false, fill-in-the-blank, code-output and error-spotting questions, plus explanations and saved scores
- **10 projects**, including the final **responsive school website capstone**
- **Cheat sheets** for HTML tags and CSS properties with copy buttons
- **Searchable glossary** (49 terms) and **global instant search** across everything
- **Progress tracking** with `localStorage` — completed lessons, quiz scores, exercises, projects, achievements and current lesson all persist across sessions
- **Achievement badges** unlocked as you progress
- **Light / dark mode** (saved), **mobile hamburger menu**, **collapsible course sidebar**, **responsive layout**

## Project structure

```
html-css-mastery/
├── index.html          Home page
├── course.html         Course dashboard
├── lesson.html         Individual lesson viewer
├── exercises.html      Coding challenges
├── quizzes.html        Quiz system
├── projects.html       Progressive projects + capstone
├── glossary.html       Searchable glossary
├── cheatsheets.html    HTML & CSS cheat sheets
├── editor.html         Live code playground
├── progress.html       Progress dashboard
├── css/
│   ├── style.css       Global styles (light + dark themes)
│   └── responsive.css  Responsive / mobile styles
├── js/
│   ├── app.js          Shell, router, page renderers
│   └── core/           store, theme, ui, progress, lessons, editor, quiz, search, achievements
│   └── data/           curriculum, lessons*, exercises, quizzes, projects, glossary, cheatsheets
└── assets/
```

## How progress is stored

All progress lives in `localStorage` under the `hcm.` prefix. There is no backend. Reset your progress on the **Progress** page (with a confirmation dialog).

## Teaching content

Every lesson follows a consistent structure: **Learning Objectives → Explanation → Syntax → Example → Code Explanation → Interactive Example → Try It Yourself → Common Mistakes → Quick Quiz → Practice Exercise → Lesson Summary → Previous/Next + Mark as Complete**.
